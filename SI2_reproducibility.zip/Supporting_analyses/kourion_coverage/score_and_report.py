"""Score locked paths against published reference labels and exhaustive subsets."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
REPEAT = ['KOUR-A', 'KOUR-B', 'KOUR-D', 'KOUR-E']
NAMED = ['KOUR-A', 'KOUR-B', 'KOUR-C', 'KOUR-D', 'KOUR-E', 'CYPR-X']
STRATEGIES = ['Random', 'pXRF proportional', 'Max-min', 'AMG stratified max-min']
CHINESE = {'Random': '随机', 'pXRF proportional': 'pXRF 比例代表',
           'Max-min': 'max-min', 'AMG stratified max-min': 'AMG 分层 max-min'}

def save_json(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def exact_reference(reference, starts):
    ids = reference.fragment_id.tolist()
    index = {v: i for i, v in enumerate(ids)}
    labels = reference.published_group.tolist()
    masks = np.arange(1 << len(ids), dtype=np.uint32)
    cardinality = np.array([int(v).bit_count() for v in masks], dtype=np.uint8)
    counts = {}
    for group in NAMED:
        group_mask = sum(1 << i for i, g in enumerate(labels) if g == group)
        counts[group] = cardinality[masks & group_mask]
    r2 = np.sum([counts[g] >= 2 for g in REPEAT], axis=0)
    r1 = np.sum([counts[g] >= 1 for g in NAMED], axis=0)
    rows, summaries, random_rows = [], [], []
    for initial in starts.itertuples(index=False):
        positions = [index[v] for v in initial.initial_ids.split(';')]
        initial_mask = sum(1 << i for i in positions)
        compatible = (masks & initial_mask) == initial_mask
        assert compatible.sum() == 1 << 15
        initial_counts = Counter(labels[i] for i in positions)
        formula = 3 + sum(max(0, 2-initial_counts[g]) for g in REPEAT)
        minimum = int(cardinality[compatible & (r2 == 4)].min())
        assert formula == minimum
        expected_random_t4 = 3.0
        for budget in range(3, 19):
            pick = compatible & (cardinality == budget)
            nsub = int(pick.sum())
            assert nsub == math.comb(15, budget-3)
            success = float((r2[pick] == 4).mean())
            if budget < 18:
                expected_random_t4 += 1-success
            rows.append({'initial_set': initial.initial_set, 'budget': budget,
                         'compatible_subsets': nsub, 'R2_best': int(r2[pick].max()),
                         'T4_star': minimum})
            random_rows.append({'initial_set': initial.initial_set, 'budget': budget,
                                'R2_exact_mean': float(r2[pick].mean()),
                                'R1_exact_mean': float(r1[pick].mean()),
                                'P_T4_reached_exact': success})
        summaries.append({'initial_set': initial.initial_set, 'T4_star': minimum,
                          'T4_star_formula': formula, 'random_T4_exact_mean': expected_random_t4})
    pd.DataFrame(rows).to_csv(OUT / 'perfect_information_reference.csv', index=False, encoding='utf-8-sig')
    exact = pd.DataFrame(summaries)
    exact.to_csv(OUT / 'perfect_information_minimum_budget.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(random_rows).to_csv(OUT / 'random_exact_diagnostic.csv', index=False, encoding='utf-8-sig')
    save_json('exhaustive_validation.json', {
        'status': 'PASS', 'all_subsets_enumerated': int(len(masks)), 'conditioned_initial_sets': len(starts),
        'compatible_subsets_per_start': 32768, 'formula_matches_all_initial_sets': True,
        'random_exact_expectation_derived_from': 'uniform fixed-budget supersets; expectation from survival probabilities',
    })
    return exact, pd.DataFrame(rows)

def score_paths(paths, reference):
    lookup = dict(zip(reference.fragment_id, reference.published_group))
    all_ids = set(lookup)
    special = reference[reference.published_group.isin(['KOUR-C', 'CYPR-X', 'loner'])]
    metrics, endpoints, rare = [], [], []
    for path_id, path in paths.groupby('path_id', sort=False):
        path = path.sort_values('position')
        assert len(path) == 18 and set(path.fragment_id) == all_ids and path.fragment_id.is_unique
        assert path.position.tolist() == list(range(1, 19))
        assert path.observed_at_budget.tolist() == [3, 3, *range(3, 19)]
        meta = path.iloc[0]
        key = {'path_id': path_id, 'initial_set': meta.initial_set,
               'strategy': meta.strategy, 'random_seed': int(meta.random_seed)}
        counts = Counter()
        t4 = None
        completion = {}
        for position, fid in enumerate(path.fragment_id, 1):
            group = lookup[fid]
            counts[group] += 1
            if group in REPEAT and counts[group] == 2:
                completion[group] = max(3, position)
            if position < 3:
                continue
            r2 = sum(counts[g] >= 2 for g in REPEAT)
            r1 = sum(counts[g] >= 1 for g in NAMED)
            if r2 == 4 and t4 is None:
                t4 = position
            metrics.append({**key, 'budget': position, 'R2': r2, 'R1': r1,
                            'T4_reached': int(r2 == 4), **{f'n_{g}': counts[g] for g in [*NAMED, 'loner']}})
        assert t4 is not None and r2 == 4 and r1 == 6
        bottleneck = ';'.join(g for g in REPEAT if completion[g] == t4)
        endpoints.append({**key, 'T4': t4, 'last_completed_group': bottleneck,
                          **{f'second_{g}': completion[g] for g in REPEAT}})
        budget_lookup = dict(zip(path.fragment_id, path.observed_at_budget))
        for item in special.itertuples(index=False):
            rare.append({**key, 'fragment_id': item.fragment_id, 'naa_id': item.naa_id,
                         'reference_group': item.published_group,
                         'observed_at_budget': int(budget_lookup[item.fragment_id])})
    metrics = pd.DataFrame(metrics)
    endpoints = pd.DataFrame(endpoints)
    metrics.to_csv(OUT / 'budget_metrics.csv', index=False, encoding='utf-8-sig')
    endpoints.to_csv(OUT / 'path_endpoints.csv', index=False, encoding='utf-8-sig')
    rare = pd.DataFrame(rare)
    rare.to_csv(OUT / 'special_object_inclusion.csv', index=False, encoding='utf-8-sig')
    return metrics, endpoints, rare

def main():
    manifest = json.loads((OUT / 'selection_manifest.json').read_text(encoding='utf-8'))
    locked_hash = hashlib.sha256((OUT / 'selection_paths.csv').read_bytes()).hexdigest()
    assert locked_hash == manifest['selection_paths_sha256']
    paths = pd.read_csv(OUT / 'selection_paths.csv', keep_default_na=False)
    reference = pd.read_csv(OUT / 'scoring_reference.csv', keep_default_na=False).sort_values('fragment_id')
    starts = pd.read_csv(OUT / 'initial_sets.csv', keep_default_na=False)
    exact, best_r2 = exact_reference(reference, starts)
    print('Exhaustive subset reference: PASS', flush=True)
    metrics, endpoints, rare = score_paths(paths, reference)
    assert len(endpoints) == 4140
    assert endpoints.groupby('strategy').size().to_dict() == {
        'Random': 3600, 'pXRF proportional': 180, 'Max-min': 180, 'AMG stratified max-min': 180}
    numeric_cols = ['T4', *[f'second_{g}' for g in REPEAT]]
    paired = endpoints.groupby(['strategy', 'initial_set'], as_index=False)[numeric_cols].mean()
    paired = paired.merge(exact, on='initial_set', validate='many_to_one')
    paired['gap_to_perfect_information'] = paired.T4-paired.T4_star
    assert (paired.gap_to_perfect_information >= 0).all()
    paired.to_csv(OUT / 'paired_budget_results.csv', index=False, encoding='utf-8-sig')
    curve_start = metrics.groupby(['strategy', 'initial_set', 'budget'], as_index=False)[['R2', 'R1', 'T4_reached']].mean()
    curve_start.to_csv(OUT / 'initial_set_budget_means.csv', index=False, encoding='utf-8-sig')
    summary = []
    for strategy in STRATEGIES:
        d = paired[paired.strategy.eq(strategy)]
        summary.append({'strategy': strategy, 'mean_T4': float(d.T4.mean()),
                        'median_initial_mean_T4': float(d.T4.median()),
                        'q25_initial_mean_T4': float(d.T4.quantile(.25)),
                        'q75_initial_mean_T4': float(d.T4.quantile(.75)),
                        'mean_gap': float(d.gap_to_perfect_information.mean()),
                        'q25_gap': float(d.gap_to_perfect_information.quantile(.25)),
                        'q75_gap': float(d.gap_to_perfect_information.quantile(.75)),
                        'fraction_starts_gap_at_least_2': float(d.gap_to_perfect_information.ge(2).mean())})
    summary = pd.DataFrame(summary)
    summary.to_csv(OUT / 'strategy_summary.csv', index=False, encoding='utf-8-sig')
    curve_rows = []
    for (strategy, budget), d in curve_start.groupby(['strategy', 'budget']):
        curve_rows.append({'strategy': strategy, 'budget': int(budget), 'mean_R2': float(d.R2.mean()),
                           'q25_R2': float(d.R2.quantile(.25)), 'q75_R2': float(d.R2.quantile(.75)),
                           'mean_R1': float(d.R1.mean()), 'P_T4_reached': float(d.T4_reached.mean())})
    for budget, d in best_r2.groupby('budget'):
        curve_rows.append({'strategy': 'Perfect information', 'budget': int(budget),
                           'mean_R2': float(d.R2_best.mean()), 'q25_R2': float(d.R2_best.quantile(.25)),
                           'q75_R2': float(d.R2_best.quantile(.75)), 'mean_R1': None,
                           'P_T4_reached': float((d.T4_star <= budget).mean())})
    curves = pd.DataFrame(curve_rows)
    curves.to_csv(OUT / 'budget_curve_summary.csv', index=False, encoding='utf-8-sig')
    rare_initial = rare.groupby(['strategy', 'initial_set', 'fragment_id', 'naa_id', 'reference_group'], as_index=False).observed_at_budget.mean()
    rare_initial.to_csv(OUT / 'special_object_initial_means.csv', index=False, encoding='utf-8-sig')
    rare_summary = rare_initial.groupby(['strategy', 'fragment_id', 'naa_id', 'reference_group'], as_index=False).observed_at_budget.mean()
    rare_summary.to_csv(OUT / 'special_object_summary.csv', index=False, encoding='utf-8-sig')
    bottleneck_rows = []
    for strategy, d in endpoints.groupby('strategy'):
        for group in REPEAT:
            p = d.assign(hit=d.last_completed_group.eq(group)).groupby('initial_set').hit.mean().mean()
            bottleneck_rows.append({'strategy': strategy, 'last_completed_group': group, 'fraction': float(p)})
    bottlenecks = pd.DataFrame(bottleneck_rows)
    bottlenecks.to_csv(OUT / 'bottleneck_groups.csv', index=False, encoding='utf-8-sig')
    best = summary.sort_values(['mean_T4', 'strategy']).iloc[0]
    reference_mean = float(exact.T4_star.mean())
    delta = float(best.mean_T4-reference_mean)
    proceed = delta >= 2
    random_mc = float(summary.loc[summary.strategy.eq('Random'), 'mean_T4'].iloc[0])
    random_exact = float(exact.random_T4_exact_mean.mean())
    decision = {'decision': '进入第二阶段的技术设计' if proceed else '停止该目标下的自适应分支',
                'primary_threshold': 2, 'best_baseline': str(best.strategy),
                'best_mean_T4': float(best.mean_T4), 'perfect_information_mean_T4': reference_mean,
                'delta_samples': delta,
                'sensitivity': {str(t): bool(delta >= t) for t in [1, 2, 3]},
                'random_MC_mean_T4': random_mc, 'random_exact_mean_T4': random_exact,
                'random_MC_minus_exact': random_mc-random_exact,
                'adaptive_models_run': False, 'independent_archaeological_replicates': 1,
                'interpretation': 'potential headroom only; does not show feedback can attain perfect information'}
    save_json('decision.json', decision)
    table = '\n'.join(f'| {CHINESE[r.strategy]} | {r.mean_T4:.3f} | {r.mean_gap:.3f} | {r.q25_initial_mean_T4:.2f}–{r.q75_initial_mean_T4:.2f} |'
                      for r in summary.itertuples(index=False))
    checkpoint_lines = []
    for strategy in STRATEGIES:
        c = curves[curves.strategy.eq(strategy)].set_index('budget')
        checkpoint_lines.append('| '+CHINESE[strategy]+' | '+' | '.join(f'{c.loc[k,"mean_R2"]:.3f}' for k in [6,8,10,12,15])+' |')
    bottleneck_best = bottlenecks[bottlenecks.strategy.eq(best.strategy)].sort_values('fraction', ascending=False).iloc[0]

    save_json('scoring_manifest.json', {'locked_selection_paths_sha256': locked_hash,
              'scoring_reference_sha256': hashlib.sha256((OUT / 'scoring_reference.csv').read_bytes()).hexdigest(),
              'budget_metric_rows': len(metrics), 'endpoints': len(endpoints),
              'selection_paths_unchanged_after_scoring': hashlib.sha256((OUT / 'selection_paths.csv').read_bytes()).hexdigest() == locked_hash})
    print(summary.to_string(index=False), flush=True)
    print(json.dumps(decision, ensure_ascii=False, indent=2), flush=True)

if __name__ == '__main__':
    main()
