"""Post-primary source check: merge only the documented uncertain pXRF label."""
from pathlib import Path
import json
import hashlib
import pandas as pd
import select_samples

OUT = Path(__file__).resolve().parent

def main():
    primary_hash = hashlib.sha256((OUT/'selection_paths.csv').read_bytes()).hexdigest()
    selectors = pd.read_csv(OUT/'selector_inputs.csv', keep_default_na=False)
    starts = pd.read_csv(OUT/'initial_sets.csv', keep_default_na=False)
    cfg = json.loads((OUT/'selector_config.json').read_text(encoding='utf-8'))
    changed = selectors.fragment_id.eq('Paphos043')
    assert changed.sum() == 1 and selectors.loc[changed, 'fragment_pxrf_cluster'].item() == 'CYP-F (?)'
    selectors.loc[changed, 'fragment_pxrf_cluster'] = 'CYP-F'
    select_samples.STRATEGIES = ['pXRF proportional']
    variant_paths, _ = select_samples.generate_paths(selectors, starts, cfg)
    variant_paths.to_csv(OUT/'label_sensitivity_paths.csv', index=False, encoding='utf-8-sig')
    reference = pd.read_csv(OUT/'scoring_reference.csv', keep_default_na=False)
    groups = dict(zip(reference.fragment_id, reference.published_group))
    rows = []
    for initial, d in variant_paths.groupby('initial_set'):
        sequence = d.sort_values('position').fragment_id.tolist()
        t4 = max([j+1 for j, i in enumerate(sequence) if groups[i] == g][1]
                 for g in ['KOUR-A', 'KOUR-B', 'KOUR-D', 'KOUR-E'])
        rows.append({'initial_set': initial, 'T4_normalized_pxrf_label': t4})
    compared = pd.DataFrame(rows).merge(
        pd.read_csv(OUT/'paired_budget_results.csv').query('strategy == "pXRF proportional"')
          [['initial_set', 'T4', 'T4_star']], on='initial_set', validate='one_to_one')
    compared['difference_from_primary'] = compared.T4_normalized_pxrf_label-compared.T4
    compared.to_csv(OUT/'label_sensitivity_results.csv', index=False, encoding='utf-8-sig')
    mean = float(compared.T4_normalized_pxrf_label.mean())
    gap = float((compared.T4_normalized_pxrf_label-compared.T4_star).mean())
    result = {'status': 'PASS', 'timing': 'post-primary source-discrepancy sensitivity; not protocol primary',
              'single_change': 'Paphos043 CYP-F (?) -> CYP-F, matching the paper table',
              'method': 'pXRF proportional', 'initial_sets': 180,
              'mean_T4': mean, 'mean_gap': gap, 'gate_at_two_samples': gap >= 2,
              'mean_change_from_primary': float(compared.difference_from_primary.mean()),
              'primary_paths_unchanged': hashlib.sha256((OUT/'selection_paths.csv').read_bytes()).hexdigest() == primary_hash}
    assert result['primary_paths_unchanged']
    (OUT/'label_sensitivity.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
