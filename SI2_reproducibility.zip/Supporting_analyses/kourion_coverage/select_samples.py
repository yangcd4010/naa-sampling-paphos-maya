"""Selection process: reads only the three explicitly allowed input files."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
STRATEGIES = ['Random', 'pXRF proportional', 'Max-min', 'AMG stratified max-min']

def tied_max(candidates, scores, ids, tolerance):
    scores = np.asarray(scores)
    assert np.isfinite(scores).all()
    tied = np.asarray(candidates)[np.isclose(scores, scores.max(), rtol=0, atol=tolerance)]
    return min(tied.tolist(), key=lambda i: ids[i])

def generate_paths(data, starts, cfg):
    ids = data.fragment_id.to_numpy(str)
    xraw = data[cfg['features']].to_numpy(float)
    mean, scale = xraw.mean(axis=0), xraw.std(axis=0, ddof=0)
    x = (xraw - mean) / np.where(scale == 0, 1, scale)
    distances = np.sqrt(((x[:, None, :] - x[None, :, :]) ** 2).sum(axis=2))
    clusters = data.fragment_pxrf_cluster.to_numpy(str)
    layers = data.AMG.to_numpy(str)
    cluster_sizes = Counter(clusters)
    layer_sizes = Counter(layers)
    medoids = {}
    for c in sorted(cluster_sizes):
        pos = np.where(clusters == c)[0]
        # Same first-minimum medoid convention as the existing replay; IDs are sorted.
        medoids[c] = pos[int(np.argmin(distances[np.ix_(pos, pos)].sum(axis=1)))]
    idpos = {v: i for i, v in enumerate(ids)}
    tol = cfg['tie_tolerance']
    rows = []
    for init in starts.itertuples(index=False):
        initial = [idpos[v] for v in init.initial_ids.split(';')]
        for strategy in STRATEGIES:
            seeds = cfg['random_seeds'] if strategy == 'Random' else [0]
            for seed in seeds:
                selected = initial.copy()
                rng = np.random.default_rng(seed)
                path_id = f'{init.initial_set}|{strategy}|{seed}'
                for position, chosen in enumerate(initial, 1):
                    rows.append((path_id, init.initial_set, strategy, seed, position, 3,
                                 True, ids[chosen]))
                while len(selected) < len(ids):
                    remaining = np.array([i for i in range(len(ids)) if i not in selected])
                    if strategy == 'Random':
                        chosen = int(rng.choice(remaining))
                    elif strategy == 'Max-min':
                        chosen = tied_max(remaining, distances[np.ix_(remaining, selected)].min(axis=1), ids, tol)
                    else:
                        strata = clusters if strategy == 'pXRF proportional' else layers
                        sizes = cluster_sizes if strategy == 'pXRF proportional' else layer_sizes
                        counts = Counter(strata[selected])
                        deficits = {h: (len(selected)+1)*sizes[h]/len(ids)-counts[h]
                                    for h in sorted(set(strata[remaining]))}
                        best = max(deficits.values())
                        h = sorted(h for h, v in deficits.items() if math.isclose(
                            v, best, rel_tol=cfg['layer_tie_relative_tolerance'], abs_tol=tol))[0]
                        candidates = remaining[strata[remaining] == h]
                        if strategy == 'pXRF proportional':
                            scores = -distances[candidates, medoids[h]]
                        else:
                            scores = distances[np.ix_(candidates, selected)].min(axis=1)
                        chosen = tied_max(candidates, scores, ids, tol)
                    assert chosen not in selected
                    selected.append(chosen)
                    rows.append((path_id, init.initial_set, strategy, seed, len(selected),
                                 len(selected), False, ids[chosen]))
                assert len(set(selected)) == 18
    frame = pd.DataFrame(rows, columns=['path_id', 'initial_set', 'strategy', 'random_seed',
                                       'position', 'observed_at_budget', 'is_initial', 'fragment_id'])
    geometry = {'means': mean.tolist(), 'scales': scale.tolist(),
                'constant_features': [c for c, s in zip(cfg['features'], scale) if s == 0],
                'pxrf_medoids': {c: ids[p] for c, p in medoids.items()},
                'pxrf_cluster_sizes': dict(cluster_sizes), 'AMG_sizes': dict(layer_sizes)}
    return frame, geometry

def main():
    allowed = [OUT / 'selector_inputs.csv', OUT / 'initial_sets.csv', OUT / 'selector_config.json']
    data = pd.read_csv(allowed[0], keep_default_na=False).sort_values('fragment_id').reset_index(drop=True)
    starts = pd.read_csv(allowed[1], keep_default_na=False)
    cfg = json.loads(allowed[2].read_text(encoding='utf-8'))
    assert list(data.columns) == ['fragment_id', 'AMG', 'fragment_pxrf_cluster', *cfg['features']]
    frame, geometry = generate_paths(data, starts, cfg)
    path = OUT / 'selection_paths.csv'
    frame.to_csv(path, index=False, encoding='utf-8-sig')
    manifest = {'allowed_input_files': [p.name for p in allowed],
                'input_hashes': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in allowed},
                'selection_paths_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                'path_count': int(frame.path_id.nunique()), 'row_count': len(frame),
                'geometry': geometry, 'NAA_values_or_memberships_available_to_selector': False}
    (OUT / 'selection_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: manifest[k] for k in ['path_count', 'row_count', 'selection_paths_sha256']}))

if __name__ == '__main__':
    main()
