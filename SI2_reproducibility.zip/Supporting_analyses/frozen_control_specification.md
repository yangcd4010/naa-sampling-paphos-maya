# Frozen random forest comparison

Status: exploratory extension specified after inspection of the initial acquisition outcomes and before generating the frozen paths. It is not a preregistered experiment. No existing path or target will be changed.

Question: within the same 97-fragment pool and 100 initial sets of 15, does the archived update procedure obtain repeated archaeological evidence earlier than a forest retained from initialisation?

## Selection

1. Reuse the archived 13 standardised Fe-ALR predictors, 31 CLR responses, 300-tree forest parameters, IDs, 100 initial sets (1001–1100), and tie tolerance. Fit only the initial 15 NAA vectors, with random_state = master_seed * 1000 + 15.
2. Freeze both the forest and the coordinate-wise NAA variance denominator used in the uncertainty score. Frozen MU takes the largest fixed uncertainty among remaining candidates.
3. Frozen DWU multiplies this fixed uncertainty by the original mean RBF density among remaining candidates. Retain the original 97-pool bandwidth and recompute density after removal. It receives no new NAA values; the full order is precomputable.
4. Reuse a common initial forest for the two frozen rules within each seed. Generate 200 complete paths, each including 15 initial and 82 subsequent fragments. All objects remain selectable through budget 97.
5. Preserve the archived updated MU and DWU paths. Those paths use budget-dependent forest seeds; comparison with a once-fitted control estimates the benefit of the whole updating procedure, including refitting. It does not isolate new-response information from all stochastic refitting effects. No additional initial-only reseeding control is part of this extension.

## Outcomes

Primary: all six original evidence targets at k = 2, under the existing explicit-associate exclusion rule. Secondary: the same targets at k = 1. Retain the four AEG5 core-membership sensitivities. Never select a membership scenario based on which favours a rule.

For each method and target report mean and median first-attainment budget, attained-by-55 rate, and paired difference updated minus frozen (negative means fewer fragments under updating). Report paired better/equal/worse fractions. Reuse all 100 common initial sets. Use 10,000 paired seed bootstrap draws, generator seed 20261003, for pointwise 95% descriptive intervals. These are conditional initial-set intervals and do not establish performance on other assemblages or family-wise statistical superiority.

The existing three simple rules stay in the comparison. Report every primary target regardless of sign. Do not substitute a more favourable rule or revise model settings after seeing the frozen results. No threshold for claiming universal feedback benefit will be selected from these results.

## Verification

Check all 200 first additions against archived counterparts, fixed score agreement at initialisation, frozen-score reconstruction from exported tree predictions, unique complete paths, correct training denominator, unchanged paths under alteration of all later NAA vectors, and precomputed-versus-stepwise ordering. Independently reconstruct all new acquisition decisions and target endpoints. Keep input and prior-delivery hashes. Do not rerun or overwrite original forests.
