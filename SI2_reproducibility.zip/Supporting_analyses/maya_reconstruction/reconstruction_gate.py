from pathlib import Path
import json
import numpy as np
from scipy.cluster.hierarchy import linkage,cut_tree
from sklearn.metrics import silhouette_score,adjusted_rand_score
ROOT=Path(__file__).resolve().parent
(ROOT/'qa').mkdir(exist_ok=True)
def main():
 a=np.load(ROOT.parent.parent/'Analysis/selector/maya_inputs.npz');ids=a['ids'];raw=np.log10(a['y15raw']);med=np.nanmedian(raw,axis=0);full=np.where(np.isnan(raw),med,raw);full-=full.mean(axis=1,keepdims=True)
 outputs=[]
 for name,method,y in [('average_CLR8','average',a['y8']),('ward_CLR8','ward',a['y8']),('average_CLR15','average',full)]:
  z=linkage(y,method=method);candidates=[];best=None
  for k in range(2,21):
   labels=cut_tree(z,n_clusters=[k]).ravel();s=float(silhouette_score(y,labels));candidates.append({'k':k,'silhouette':s})
   if best is None or s>best['silhouette']+1e-12:best={'procedure':name,'k':k,'silhouette':s,'partition':labels.tolist()}
  best['candidate_cuts']=candidates;outputs.append(best)
 (ROOT/'qa'/'unscored_partitions.json').write_text(json.dumps(outputs,indent=2),encoding='utf8')
 # Reference labels are first loaded here, after partitions have been emitted.
 refs=json.loads((ROOT.parent.parent/'Analysis/inputs/maya/reference_for_evaluation.json').read_text(encoding='utf8'));assert [r['ANID'] for r in refs]==ids.tolist()
 for out in outputs:
  for target in ['main','terminal']:out['ARI_'+target]=float(adjusted_rand_score([r[target] for r in refs],out['partition']))
 gates={target:all(out['silhouette']>=.5 and out['ARI_'+target]>=.8 for out in outputs) for target in ['main','terminal']}
 result={'procedures':outputs,'gate':gates,'thresholds':{'silhouette':.5,'ARI':.8},'interpretation':'Exploratory feasibility conventions, not calibrated confidence. No sequential inference when gate fails.'}
 (ROOT/'reconstruction_gate.json').write_text(json.dumps(result,indent=2),encoding='utf8')
 print(json.dumps({'gate':gates,'results':[{k:v for k,v in out.items() if k not in ['partition','candidate_cuts']} for out in outputs]},indent=2))
if __name__=='__main__':main()
