from pathlib import Path
from datetime import datetime,timezone
import csv,json,hashlib
import numpy as np
import pandas as pd
from judgment_core import PROCEDURES,infer
OUT=Path(__file__).resolve().parent;I=OUT/'inputs';R=OUT/'results'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
    with (R/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
def pair_partition(labels):return np.asarray(labels)[:,None]==np.asarray(labels)[None,:]
def scalar_silhouette(d,labels):
    vals=[]
    for i,g in enumerate(labels):
        own=[j for j,h in enumerate(labels) if h==g and j!=i]
        if not own:vals.append(0.0);continue
        a=sum(float(d[i,j]) for j in own)/len(own)
        others=[]
        for h in set(labels)-{g}:
            js=[j for j,v in enumerate(labels) if v==h];others.append(sum(float(d[i,j]) for j in js)/len(js))
        b=min(others);vals.append((b-a)/max(a,b) if max(a,b)>0 else 0.0)
    return sum(vals)/len(vals)
def main():
    start=dict(created_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=sha(OUT/'analysis_plan.md'),
       code_hashes={n:sha(OUT/n) for n in ['judgment_core.py','run_judgment_gate.py']},procedures=list(PROCEDURES))
    (OUT/'judgment_run_start.json').write_text(json.dumps(start,indent=2),encoding='utf-8')
    measurements=pd.read_csv(OUT.parent/'kourion_feedback/measurement_store.csv');ids=measurements.fragment_id.to_numpy(str)
    cols=[c for c in measurements if c.startswith('log_')];y=measurements[cols].to_numpy(float)
    assert y.shape==(18,29)
    inferred={};parts=[];scores=[];errors=[];invariance=[]
    for procedure in PROCEDURES:
        result=infer(ids,y,procedure);inferred[procedure]=result
        for fid,raw,resolved in zip(result['ids'],result['raw'],result['resolved']):parts.append(dict(procedure=procedure,fragment_id=fid,raw_cluster=int(raw),resolved_cluster=int(resolved)))
        scores.extend(dict(procedure=procedure,**r) for r in result['candidates'])
        direct=scalar_silhouette(result['distance'],result['raw']);errors.append(abs(direct-result['silhouette']))
        assert abs(direct-result['silhouette'])<1e-12
        perm=np.random.default_rng(20261003).permutation(18);again=infer(ids[perm],y[perm],procedure)
        assert np.array_equal(pair_partition(result['raw']),pair_partition(again['raw']))
        assert np.array_equal(result['resolved'],again['resolved']);invariance.append(procedure)
    # Save inference before any reference-label scoring.
    write('kourion_inferred_partitions.csv',parts);write('kourion_candidate_cuts.csv',scores)
    prehash=sha(R/'kourion_inferred_partitions.csv')
    ref=pd.read_csv(OUT.parent/'kourion_coverage/scoring_reference.csv',keep_default_na=False).set_index('fragment_id')
    actual={fid:(r.published_group if r.published_group else 'loner:'+fid) for fid,r in ref.iterrows()}
    # Explicit loner statuses are separate objects even if a raw text marker is present.
    for fid,r in ref.iterrows():
        if r.published_status=='loner' or r.published_group in ['', 'loner']:actual[fid]='loner:'+fid
    target_groups=['KOUR-A','KOUR-B','KOUR-D','KOUR-E'];summary=[];recovery=[];pairrows=[]
    for procedure,result in inferred.items():
        ordered=result['ids'];raw=result['raw'];resolved=result['resolved'];n=len(ordered)
        true=[actual[fid] for fid in ordered];raw_merge=raw_split=correct=merge=split=unresolved=0
        for a in range(n):
            for b in range(a+1,n):
                same=true[a]==true[b];rawsame=raw[a]==raw[b];known=resolved[a]>=0 and resolved[b]>=0
                raw_merge+=int(rawsame and not same);raw_split+=int(not rawsame and same)
                outcome='unresolved' if not known else ('correct' if same==(resolved[a]==resolved[b]) else ('false_merge' if resolved[a]==resolved[b] else 'false_split'))
                correct+=int(outcome=='correct');merge+=int(outcome=='false_merge');split+=int(outcome=='false_split');unresolved+=int(outcome=='unresolved')
                pairrows.append(dict(procedure=procedure,left=ordered[a],right=ordered[b],reference_same=int(same),raw_same=int(rawsame),outcome=outcome))
        clusters={int(label):set(ordered[resolved==label]) for label in set(resolved) if label>=0}
        exact=0
        for g in target_groups:
            members={fid for fid,t in actual.items() if t==g};hit=any(c==members for c in clusters.values());exact+=int(hit)
            raw_clusters={int(label):set(ordered[raw==label]) for label in set(raw)}
            rawhit=any(c==members for c in raw_clusters.values())
            recovery.append(dict(procedure=procedure,reference_group=g,n=len(members),members=';'.join(sorted(members)),exact_recovered=int(hit),raw_exact_recovered=int(rawhit)))
        passed=result['silhouette']>=.5 and exact==4
        summary.append(dict(procedure=procedure,chosen_k=result['k'],silhouette=result['silhouette'],resolved_objects=int(np.sum(resolved>=0)),
            exact_repeated_groups=exact,correct_pairs=correct,false_merge_pairs=merge,false_split_pairs=split,unresolved_pairs=unresolved,
            raw_false_merge_pairs=raw_merge,raw_false_split_pairs=raw_split,total_pairs=n*(n-1)//2,gate_pass=passed))
    write('kourion_full_data_metrics.csv',summary);write('kourion_group_recovery.csv',recovery);write('kourion_pair_audit.csv',pairrows)
    passed=all(r['gate_pass'] for r in summary)
    decision=dict(status='PASS_CONTINUE' if passed else 'STOP_JUDGMENT_BRANCH',all_three_passed=passed,
        criterion='All three procedures: silhouette >= 0.5 and exact uncontaminated recovery of all four repeated groups',
        scope='Feasibility of these declared automatic evaluators only; not proof that all inference models or the archaeological question are impossible',
        inference_saved_before_reference_scoring_sha256=prehash,reference_used_in_inference=False,threshold_calibrated_as_error_probability=False,
        sequential_judgment_run=False,procedures=summary,validation={'direct_silhouette_max_error':max(errors),'row_order_invariance':invariance})
    (OUT/'judgment_decision.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(decision,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
