"""Automatic chemical partition from observed rows only; no reference labels."""
import numpy as np
from scipy.cluster.hierarchy import linkage,cut_tree
from scipy.spatial.distance import pdist,squareform
from sklearn.metrics import silhouette_score

PROCEDURES=('average_Lu','complete_Lu','average_CLR30')

def infer(ids,observed,procedure):
    ids=np.asarray(ids,str);observed=np.asarray(observed,float)
    order=np.argsort(ids);ids=ids[order];y=observed[order]
    assert y.ndim==2 and y.shape[1]==29 and len(ids)==len(y) and np.isfinite(y).all()
    if len(ids)<4:return dict(ids=ids,raw=np.arange(len(ids)),resolved=np.full(len(ids),-1),silhouette=None,k=0,candidates=[],distance=None)
    if procedure=='average_CLR30':
        y=np.column_stack([y,np.zeros(len(y))]);y-=y.mean(axis=1,keepdims=True)
    elif procedure not in ['average_Lu','complete_Lu']:raise ValueError(procedure)
    distances=pdist(y,'euclidean');matrix=squareform(distances)
    tree=linkage(distances,method='complete' if procedure=='complete_Lu' else 'average')
    candidates=[];best=None
    for k in range(2,len(ids)):
        labels=cut_tree(tree,n_clusters=[k]).ravel()
        score=float(silhouette_score(matrix,labels,metric='precomputed'))
        candidates.append(dict(k=k,silhouette=score))
        if best is None or score>best[0]+1e-12:best=score,k,labels
    score,k,labels=best;resolved=labels.copy()
    if score<.5:resolved[:]=-1
    else:
        for label in np.unique(labels):
            if np.sum(labels==label)<2:resolved[labels==label]=-1
    return dict(ids=ids,raw=labels,resolved=resolved,silhouette=score,k=k,candidates=candidates,distance=matrix)
