# Automatic reconstruction specification

## C. Kourion judgment-reconstruction feasibility

The candidate pool is the previously defined 18 objects in the three AMG 29-related categories. Do not select it using NAA labels. The original study describes Euclidean/average-linkage log-ratio clustering with subsequent Mahalanobis filtering and archaeological/reference interpretation, but does not supply a complete executable cutting/filtering rule. Therefore this is an automatic structure-reconstruction feasibility test, not an exact reproduction of the published classification.

The inference function receives only revealed measurement vectors and object IDs, never reference labels or unmeasured rows. Primary geometry is the existing 29 NAA natural log ratios to Lu, excluding As, Ni and Zr. No global response PCA or response feature standardization. Build hierarchical clustering and choose the cut maximizing mean silhouette over k=2,...,n-1; ties within 1e-12 choose fewer clusters. For n<4, return unresolved. Singleton clusters are unresolved objects, not inferred proven sources. A maximum silhouette below 0.5 is recorded as insufficient separation and no resolved grouping is emitted. The 0.5 cutoff is an explicit exploratory separation convention, not a posterior probability or calibrated error guarantee.

Only three procedures are run, with none substituted after inspection:
1. Primary: Euclidean distance on 29 Lu log ratios, average linkage.
2. Sensitivity: the same ratios and distance, complete linkage.
3. Sensitivity: average linkage on the 30-component CLR subcomposition obtained by appending log(Lu/Lu)=0 to the 29 log ratios and centering each row. This checks dependence on the common divisor; it uses no labels.

Before scoring, record all three full-18 partitions and all candidate-k silhouette scores. Then compare against the original reference. For each procedure report pairwise false merging, false splitting, unresolved fraction and exact recovered repeated-group sets. The four repeated reference groups are KOUR-A/B/D/E; KOUR-C, CYPR-X and two distinct loners remain in the pool and cannot be silently removed. Exact recovery means all and only a reference group's members form a resolved cluster, including no contamination by the four other objects.

Continuation gate: all three procedures must (i) emit a resolved partition under the separation convention and (ii) exactly recover all four repeated-group sets. This is a deliberately conservative feasibility requirement for proceeding with this automatic judgment evaluator, not a test that all possible inference models or the archaeological question are impossible. A failure stops the sequential judgment branch: report the failed conditions and partitions, do not retune, change the target or replace the reference to obtain a pass.

If the gate passes, apply the unchanged primary evaluator to existing 18-object paths for the four simple rules and adaptive/frozen ridge at lambda=1, preserving all 180 initial sets. Random repetitions are averaged within initial set first. At budgets 3–18 report reference-consistent pair relations, false merges/splits, unresolved objects/pairs, repeated groups recovered and all-group coverage. The scorer may see the complete reference; the evaluator may not. A first reference-consistent budget is retrospective scoring, not an online stopping rule. Do not infer posterior calibration or geographical provenance. The specified ridge settings are fixed.

