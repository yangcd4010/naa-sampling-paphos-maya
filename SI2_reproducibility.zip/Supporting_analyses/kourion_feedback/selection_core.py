"""Pure numerical acquisition functions; no file reads or reference labels."""
import numpy as np

def design_matrix(frame, feature_columns, categorical_columns):
    raw = frame[feature_columns].to_numpy(float)
    raw_std = raw.std(axis=0, ddof=0)
    numeric = (raw-raw.mean(axis=0))/np.where(raw_std == 0, 1, raw_std)
    blocks, details = [], []
    entries = [('pXRF numeric', numeric, feature_columns)]
    for field in categorical_columns:
        categories = sorted(frame[field].unique())
        block = np.column_stack([(frame[field].to_numpy() == c).astype(float) for c in categories])
        block -= block.mean(axis=0)
        entries.append((field, block, categories))
    for name, block, columns in entries:
        scale = float(np.sqrt(np.mean(np.sum(block**2, axis=1))))
        normalized = block/max(scale, 1e-15)
        blocks.append(normalized)
        details.append({'block': name, 'columns': list(columns), 'normalizer': scale,
                        'mean_squared_row_norm': float(np.mean(np.sum(normalized**2, axis=1)))})
    return np.column_stack(blocks), details

def ridge_predict(x, selected, observed_y, lam):
    """Only observed_y is accepted. No candidate response array or labels."""
    selected = np.asarray(selected, dtype=int)
    assert len(selected) == len(observed_y) and len(selected) >= 3 and lam > 0
    train = x[selected]
    xm, ym = train.mean(axis=0), observed_y.mean(axis=0)
    xc, yc = train-xm, observed_y-ym
    weights = np.linalg.solve(xc@xc.T + len(selected)*lam*np.eye(len(selected)), yc)
    coefficients = xc.T@weights
    return (x-xm)@coefficients + ym

def squared_distances(z):
    return np.mean((z[:, None, :]-z[None, :, :])**2, axis=2)

def acquire(distance, selected, ids, tolerance=1e-12):
    remaining = np.array([i for i in range(len(ids)) if i not in selected])
    closest_two = np.partition(distance[:, selected], 1, axis=1)[:, :2]
    second = closest_two.max(axis=1)
    gains = np.maximum(second[:, None]-distance[:, remaining], 0).mean(axis=0)
    candidates = remaining[np.isclose(gains, gains.max(), atol=tolerance, rtol=0)]
    chosen = min(candidates.tolist(), key=lambda i: ids[i])
    return chosen, float(gains[np.where(remaining == chosen)[0][0]])

def fixed_geometry_path(distance, initial, ids, tolerance):
    selected = list(initial)
    while len(selected) < len(ids):
        chosen, _ = acquire(distance, selected, ids, tolerance)
        selected.append(chosen)
    return selected
