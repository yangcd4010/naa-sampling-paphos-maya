"""Replay controller. The oracle is kept outside the pure selection functions."""
from pathlib import Path
import hashlib
import json
import time
import numpy as np
import pandas as pd
from selection_core import design_matrix, ridge_predict, squared_distances, acquire, fixed_geometry_path

OUT = Path(__file__).resolve().parent

def input_path(name):
    return OUT.parent/'kourion_coverage'/name if name in ['initial_sets.csv','scoring_reference.csv','selector_inputs.csv'] else OUT/name

def array_hash(a):
    return hashlib.sha256(np.ascontiguousarray(a, dtype='<f8').tobytes()).hexdigest()

def main():
    cfg = json.loads((OUT/'config.json').read_text(encoding='utf-8'))
    manifest = json.loads((OUT/'input_manifest.json').read_text(encoding='utf-8'))
    assert all(hashlib.sha256(input_path(name).read_bytes()).hexdigest() == sha for name, sha in manifest.items())
    selectors = pd.read_csv(OUT.parent/'kourion_coverage/selector_inputs.csv', keep_default_na=False)
    starts = pd.read_csv(OUT.parent/'kourion_coverage/initial_sets.csv', keep_default_na=False)
    store = pd.read_csv(OUT/'measurement_store.csv', keep_default_na=False)
    ids = selectors.fragment_id.to_numpy(str)
    assert store.fragment_id.tolist() == ids.tolist()
    x, block_details = design_matrix(selectors, cfg['pxrf_features'], cfg['categorical_features'])
    true_y = store[cfg['response_columns']].to_numpy(float)
    idpos = {fid:i for i,fid in enumerate(ids)}
    variants = []
    for lam in [cfg['primary_lambda'], *cfg['sensitivity_lambdas']]:
        suffix = format(lam, 'g')
        variants += [(f'adaptive_l{suffix}', 'Adaptive ridge', lam, 0),
                     (f'frozen_l{suffix}', 'Frozen ridge', lam, 0)]
    variants += [('x_twocover', 'X two-cover', 0.0, 0),
                 ('complete_naa', 'Complete-NAA diagnostic', 0.0, 0)]
    variants += [('permuted_l1', 'Permuted feedback', 1.0, seed) for seed in cfg['permutation_seeds']]
    rows, permutation_rows = [], []
    started = time.monotonic()
    code_hashes = {name: hashlib.sha256(input_path(name).read_bytes()).hexdigest()
                   for name in ['run_feedback.py', 'selection_core.py']}
    (OUT/'run_start.json').write_text(json.dumps({'config_hash': manifest['config.json'],
            'selector_code_hashes': code_hashes,
            'planned_new_paths': len(starts)*len(variants)}, indent=2), encoding='utf-8')
    for nstart, start in enumerate(starts.itertuples(index=False), 1):
        initial = [idpos[fid] for fid in start.initial_ids.split(';')]
        for condition, method, lam, seed in variants:
            path_id = f'{start.initial_set}|{condition}|{seed}'
            mapping = np.arange(len(ids))
            if method == 'Permuted feedback':
                remaining = [i for i in range(len(ids)) if i not in initial]
                mapping[remaining] = np.random.default_rng(seed).permutation(remaining)
                assert all(mapping[i] == i for i in initial)
                for destination in remaining:
                    permutation_rows.append((start.initial_set, seed, ids[destination], ids[mapping[destination]]))
            selected = initial.copy()
            common = {'path_id': path_id, 'initial_set': start.initial_set, 'condition': condition,
                      'method': method, 'lambda': lam, 'permutation_seed': seed}
            for position, chosen in enumerate(initial, 1):
                rows.append({**common, 'position': position, 'observed_at_budget': 3, 'fragment_id': ids[chosen],
                             'gain': None, 'training_count': 3, 'training_ids': ';'.join(ids[initial]),
                             'observed_response_hash': array_hash(true_y[initial]), 'access_mode': 'initial'})
            fixed_d = None
            if method == 'Frozen ridge':
                fixed_d = squared_distances(ridge_predict(x, initial, true_y[initial], lam))
            elif method == 'X two-cover':
                fixed_d = squared_distances(x)
            elif method == 'Complete-NAA diagnostic':
                fixed_d = squared_distances(true_y)
            precomputed = fixed_geometry_path(fixed_d, initial, ids, cfg['tie_tolerance']) if fixed_d is not None else None
            while len(selected) < len(ids):
                if method in ['Adaptive ridge', 'Permuted feedback']:
                    observed = true_y[mapping[selected]].copy()
                    # Only revealed rows cross this function boundary.
                    d = squared_distances(ridge_predict(x, selected, observed, lam))
                    used_ids = ids[selected]
                    access_mode = 'selected-only' if method == 'Adaptive ridge' else 'selected-only-permuted'
                    count = len(selected)
                else:
                    d = fixed_d
                    if method == 'Frozen ridge':
                        observed, used_ids, count, access_mode = true_y[initial], ids[initial], 3, 'initial-only'
                    elif method == 'X two-cover':
                        observed, used_ids, count, access_mode = np.empty((0,29)), [], 0, 'no-NAA'
                    else:
                        observed, used_ids, count, access_mode = true_y, ids, 18, 'explicit-full-information-diagnostic'
                chosen, gain = acquire(d, selected, ids, cfg['tie_tolerance'])
                if precomputed is not None:
                    assert chosen == precomputed[len(selected)]
                rows.append({**common, 'position': len(selected)+1, 'observed_at_budget': len(selected)+1,
                             'fragment_id': ids[chosen], 'gain': gain, 'training_count': count,
                             'training_ids': ';'.join(used_ids), 'observed_response_hash': array_hash(observed),
                             'access_mode': access_mode})
                selected.append(chosen)
            assert len(set(selected)) == 18
        if nstart % 30 == 0:
            print(f'{nstart}/180 initial sets; {len(rows)//18} complete paths; {time.monotonic()-started:.1f}s', flush=True)
    frame = pd.DataFrame(rows)
    frame.to_csv(OUT/'selection_paths.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(permutation_rows, columns=['initial_set', 'seed', 'selected_id', 'returned_vector_from_id']).to_csv(
        OUT/'permutation_assignments.csv', index=False, encoding='utf-8-sig')
    run = {'status': 'completed', 'new_paths': int(frame.path_id.nunique()), 'rows': len(frame),
           'seconds': time.monotonic()-started, 'input_blocks': block_details,
           'path_sha256_before_scoring': hashlib.sha256((OUT/'selection_paths.csv').read_bytes()).hexdigest(),
           'selector_functions_accept_full_reference_labels': False,
           'fixed_geometry_precomputed_vs_online': 'PASS for all frozen/X/full-information diagnostic paths',
           'code_hashes': code_hashes}
    (OUT/'run_manifest.json').write_text(json.dumps(run, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k:run[k] for k in ['status','new_paths','rows','seconds']}, ensure_ascii=False), flush=True)

if __name__ == '__main__':
    main()
