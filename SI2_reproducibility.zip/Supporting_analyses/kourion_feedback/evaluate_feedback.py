"""Use the unchanged stage-1 evaluator, then compute paired stage-2 effects."""
from pathlib import Path
import hashlib
import importlib.util
import json
import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
STAGE1 = OUT.parent/'kourion_coverage'
DISPLAY = {
    'baseline_proportional': 'pXRF 比例代表', 'baseline_random': '随机（阶段一）',
    'baseline_maxmin': 'max-min（阶段一）', 'baseline_stratified': 'AMG 分层 max-min（阶段一）',
    'adaptive_l1': '自适应岭回归：主设置', 'frozen_l1': '固定初始岭回归：主设置',
    'adaptive_l0.1': '自适应岭回归：λ=0.1', 'frozen_l0.1': '固定初始岭回归：λ=0.1',
    'adaptive_l10': '自适应岭回归：λ=10', 'frozen_l10': '固定初始岭回归：λ=10',
    'x_twocover': 'X 空间双覆盖', 'complete_naa': '完整 NAA 几何诊断（不可部署）',
    'permuted_l1': '置换后续 NAA：主设置',
}

def save(name, value):
    (OUT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def main():
    cfg = json.loads((OUT/'config.json').read_text(encoding='utf-8'))
    manifest = json.loads((OUT/'run_manifest.json').read_text(encoding='utf-8'))
    locked_hash = hashlib.sha256((OUT/'selection_paths.csv').read_bytes()).hexdigest()
    assert locked_hash == manifest['path_sha256_before_scoring']
    original = pd.read_csv(OUT/'selection_paths.csv', keep_default_na=False)
    assert original.path_id.nunique() == 3240
    metadata = original[['path_id', 'condition', 'lambda']].drop_duplicates()
    assert metadata.path_id.is_unique
    compatible = original.rename(columns={'method':'strategy', 'permutation_seed':'random_seed'})
    spec = importlib.util.spec_from_file_location('stage1_common_evaluator', STAGE1/'score_and_report.py')
    evaluator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(evaluator)
    evaluator.OUT = OUT  # Reuse scoring only; all writes stay in stage 2.
    reference = pd.read_csv(OUT.parent/'kourion_coverage/scoring_reference.csv', keep_default_na=False)
    budgets, endpoints, rare = evaluator.score_paths(compatible, reference)
    budgets = budgets.merge(metadata, on='path_id', validate='many_to_one')
    endpoints = endpoints.merge(metadata, on='path_id', validate='one_to_one')
    rare = rare.merge(metadata, on='path_id', validate='many_to_one')
    for name, data in [('budget_metrics.csv', budgets), ('path_endpoints.csv', endpoints), ('special_object_inclusion.csv', rare)]:
        data.to_csv(OUT/name, index=False, encoding='utf-8-sig')
    baseline_codes = {'Random':'baseline_random', 'pXRF proportional':'baseline_proportional',
                      'Max-min':'baseline_maxmin', 'AMG stratified max-min':'baseline_stratified'}
    oldend = pd.read_csv(STAGE1/'path_endpoints.csv', keep_default_na=False)
    oldbudget = pd.read_csv(STAGE1/'budget_metrics.csv', keep_default_na=False)
    for data in [oldend, oldbudget]:
        data['condition'] = data.strategy.map(baseline_codes)
        data['lambda'] = np.nan
    allend = pd.concat([endpoints, oldend], ignore_index=True)
    allbudget = pd.concat([budgets, oldbudget], ignore_index=True)
    initial_end = allend.groupby(['condition', 'initial_set'], as_index=False).T4.mean()
    initial_curve = allbudget.groupby(['condition', 'initial_set', 'budget'], as_index=False)[['R2','R1','T4_reached']].mean()
    initial_end.to_csv(OUT/'initial_mean_endpoints.csv', index=False, encoding='utf-8-sig')
    initial_curve.to_csv(OUT/'initial_mean_budget_metrics.csv', index=False, encoding='utf-8-sig')
    table = initial_end.pivot(index='initial_set', columns='condition', values='T4')
    assert table.shape == (180,13) and not table.isna().any().any()
    paired_rows = []
    comparisons = [('baseline_proportional', 'adaptive_l1'), ('frozen_l1', 'adaptive_l1'),
                   ('x_twocover', 'adaptive_l1'), ('permuted_l1', 'adaptive_l1'),
                   ('baseline_proportional', 'adaptive_l0.1'), ('frozen_l0.1', 'adaptive_l0.1'),
                   ('baseline_proportional', 'adaptive_l10'), ('frozen_l10', 'adaptive_l10')]
    for comparator, adaptive in comparisons:
        for initial in table.index:
            paired_rows.append({'initial_set': initial, 'comparator': comparator, 'candidate': adaptive,
                                'comparator_T4': table.loc[initial, comparator],
                                'candidate_T4': table.loc[initial, adaptive],
                                'saving_samples': table.loc[initial, comparator]-table.loc[initial, adaptive]})
    paired = pd.DataFrame(paired_rows)
    paired.to_csv(OUT/'paired_savings.csv', index=False, encoding='utf-8-sig')
    effects = []
    for (comparator, candidate), d in paired.groupby(['comparator','candidate']):
        effects.append({'comparator':comparator, 'candidate':candidate,
                        'mean_saving': float(d.saving_samples.mean()), 'median_saving':float(d.saving_samples.median()),
                        'q25_saving':float(d.saving_samples.quantile(.25)), 'q75_saving':float(d.saving_samples.quantile(.75)),
                        'fraction_improved':float((d.saving_samples>0).mean()),
                        'fraction_tied':float((d.saving_samples==0).mean()),
                        'fraction_worse':float((d.saving_samples<0).mean())})
    effects = pd.DataFrame(effects)
    effects.to_csv(OUT/'effect_summary.csv', index=False, encoding='utf-8-sig')
    summary_rows = []
    for condition, d in initial_end.groupby('condition'):
        summary_rows.append({'condition':condition, 'display':DISPLAY[condition], 'mean_T4':float(d.T4.mean()),
                             'median_T4':float(d.T4.median()), 'q25_T4':float(d.T4.quantile(.25)),
                             'q75_T4':float(d.T4.quantile(.75))})
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(OUT/'strategy_summary.csv', index=False, encoding='utf-8-sig')
    curve_summary = initial_curve.groupby(['condition','budget'], as_index=False)[['R1','R2','T4_reached']].mean()
    curve_summary.to_csv(OUT/'budget_curve_summary.csv', index=False, encoding='utf-8-sig')
    means = summary.set_index('condition').mean_T4
    gains = {'vs_proportional':float(means['baseline_proportional']-means['adaptive_l1']),
             'vs_frozen':float(means['frozen_l1']-means['adaptive_l1'])}
    coverage = []
    for k in cfg['gate']['R1_budgets']:
        c = curve_summary[curve_summary.budget.eq(k)].set_index('condition')
        loss = float(c.loc['baseline_proportional','R1']-c.loc['adaptive_l1','R1'])
        coverage.append({'budget':k, 'proportional_mean_R1':float(c.loc['baseline_proportional','R1']),
                         'adaptive_mean_R1':float(c.loc['adaptive_l1','R1']), 'R1_loss':loss,
                         'pass':loss<=cfg['gate']['maximum_R1_loss_vs_proportional']})
    conditions = {'saves_one_vs_proportional':gains['vs_proportional']>=1,
                  'saves_one_vs_frozen':gains['vs_frozen']>=1,
                  'coverage_at_8_and_12':all(c['pass'] for c in coverage)}
    proceed = all(conditions.values())
    # Feedback-path comparison is separate from endpoint performance.
    primary = original[original.condition.isin(['adaptive_l1','frozen_l1'])]
    sequences = {(s,c): d.sort_values('position').fragment_id.tolist()
                 for (s,c),d in primary.groupby(['initial_set','condition'])}
    differences = []
    for s in table.index:
        a,f = sequences[s,'adaptive_l1'],sequences[s,'frozen_l1']
        assert a[3] == f[3]
        differences.append({'initial_set':s, 'identical_full_sequence':a==f,
                            'first_difference_budget':next((k+1 for k in range(18) if a[k]!=f[k]), 0)})
    pd.DataFrame(differences).to_csv(OUT/'feedback_path_changes.csv', index=False, encoding='utf-8-sig')
    decision = {'decision':'进入独立判读方法的设计与验证' if proceed else '停止当前岭回归双覆盖分支',
                'primary_lambda':1, 'primary_mean_T4':float(means['adaptive_l1']),
                'proportional_mean_T4':float(means['baseline_proportional']),
                'frozen_mean_T4':float(means['frozen_l1']), 'savings':gains,
                'conditions':conditions, 'coverage_checks':coverage,
                'feedback_changed_full_paths':sum(not d['identical_full_sequence'] for d in differences),
                'n_initial_sets':180, 'new_paths':3240, 'all_phase2_budget_records':len(budgets),
                'sensitivity_does_not_replace_primary':True,
                'scope':'one model/acquisition family on one 18-object pool; reference representation, not independent provenance inference'}
    save('decision.json', decision)
    save('scoring_manifest.json', {'shared_stage1_evaluator_sha256':hashlib.sha256((STAGE1/'score_and_report.py').read_bytes()).hexdigest(),
                                 'selector_paths_sha256':locked_hash, 'new_paths':len(endpoints), 'new_budget_rows':len(budgets),
                                 'paths_unchanged':locked_hash==hashlib.sha256((OUT/'selection_paths.csv').read_bytes()).hexdigest()})
    main_order = ['baseline_proportional','adaptive_l1','frozen_l1','x_twocover','permuted_l1','complete_naa']
    report_table = '\n'.join(f'| {DISPLAY[c]} | {means[c]:.3f} |' for c in main_order)
    sensitivity_table = '\n'.join(f'| {lam:g} | {means[f"adaptive_l{lam:g}"]:.3f} | {means[f"frozen_l{lam:g}"]:.3f} | {means["baseline_proportional"]-means[f"adaptive_l{lam:g}"]:+.3f} |'
                                 for lam in [0.1,1,10])
    effect_lines = []
    for comparator in ['baseline_proportional','frozen_l1','x_twocover','permuted_l1']:
        e = effects[(effects.comparator==comparator)&(effects.candidate=='adaptive_l1')].iloc[0]
        effect_lines.append(f'| {DISPLAY[comparator]} | {e.mean_saving:+.3f} | {e.q25_saving:+.2f}–{e.q75_saving:+.2f} | {e.fraction_improved:.1%} / {e.fraction_tied:.1%} / {e.fraction_worse:.1%} |')
    coverage_lines = '\n'.join(f'| {c["budget"]} | {c["proportional_mean_R1"]:.3f} | {c["adaptive_mean_R1"]:.3f} | {c["R1_loss"]:+.3f} | {"通过" if c["pass"] else "未通过"} |' for c in coverage)
    protocol_gain = gains['vs_proportional']
    direction = f'比比例代表平均少用 {protocol_gain:.3f} 件' if protocol_gain >= 0 else f'比比例代表平均多用 {-protocol_gain:.3f} 件'

    print(summary.to_string(index=False), flush=True)
    print(json.dumps(decision, ensure_ascii=False, indent=2), flush=True)

if __name__ == '__main__':
    main()
