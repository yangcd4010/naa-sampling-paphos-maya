"""Recreate numerical selector inputs from the original-provider mmc2 workbook."""
from pathlib import Path
import argparse,json,hashlib,urllib.request,sys
import numpy as np,openpyxl
try:from scipy.cluster.hierarchy import linkage,cut_tree
except ModuleNotFoundError:
 sys.path.append(str(Path(__file__).resolve().parents[2]/'_analysis_runtime_deps'))
 from scipy.cluster.hierarchy import linkage,cut_tree
ROOT=Path(__file__).resolve().parent
URL='https://ars.els-cdn.com/content/image/1-s2.0-S2352409X21000316-mmc2.xlsx'
EXPECTED='b660c05a18f80292e9216e7f8f083ded89c249d5859e7487e266f4c63b5632a8'
def build(source,destination):
 w=openpyxl.load_workbook(source,read_only=True,data_only=True)
 def sheet(name):
  rows=list(w[name].values);return {r[0]:dict(zip(rows[0],r)) for r in rows[1:] if any(v is not None for v in r)}
 n=sheet('INAA');p=sheet('pXRF_Averaged_Assays');ids=sorted(n);assert len(ids)==183 and set(n)==set(p)
 for id in ids:assert all(n[id][k]==p[id][k] for k in ['INAA ID','Site','Type'])
 xe=['Al','Ca','Ti','Cr','Mn','Fe','Zn','Rb','Sr','Zr','Nb','Mo'];ye=['Sc','Cr','Fe','La','Ce','Lu','Hf','Th'];y15=['Na','K','Ca','Sc','Cr','Fe','Rb','Sb','Cs','Ba','La','Ce','Lu','Hf','Th']
 px=np.array([[p[id][e] for e in xe] for id in ids],float);ly=np.log10(px);ly=np.where(np.isnan(ly),np.nanmedian(ly,axis=0),ly);alr=np.delete(ly-ly[:,[xe.index('Fe')]],xe.index('Fe'),axis=1);x=(alr-alr.mean(axis=0))/alr.std(axis=0,ddof=0)
 raw=np.array([[n[id][e] for e in ye] for id in ids],float);ly=np.log10(raw);clr=ly-ly.mean(axis=1,keepdims=True);raw15=np.array([[n[id][e] for e in y15] for id in ids],float)
 z=linkage(x,method='ward');destination.parent.mkdir(exist_ok=True,parents=True);np.savez_compressed(destination,ids=np.array(ids),x=x,y8=clr,y15raw=raw15,**{f'clusters{k}':cut_tree(z,n_clusters=[k]).ravel() for k in [5,10,20]})
 return dict(source_sha256=hashlib.sha256(Path(source).read_bytes()).hexdigest(),expected_source_sha256=EXPECTED,ids=183,missing_predictor_cells=int(np.isnan(px).sum()))
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--source-xlsx',type=Path);parser.add_argument('--download',action='store_true');parser.add_argument('--output',type=Path,default=ROOT/'selector/maya_inputs.npz');args=parser.parse_args()
 if args.source_xlsx:source=args.source_xlsx
 elif args.download:
  source=ROOT/'local_provider_data/mmc2.xlsx';source.parent.mkdir(exist_ok=True);urllib.request.urlretrieve(URL,source)
 else:parser.error('Provide --source-xlsx from the original provider, or explicitly use --download.')
 result=build(source,args.output);assert result['source_sha256']==EXPECTED,'Provider workbook differs from archived version; inspect before reproducing.';print(json.dumps(result,indent=2))
