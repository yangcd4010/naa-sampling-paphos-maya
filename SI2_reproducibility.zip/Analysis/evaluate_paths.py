"""Read the consolidated acquisition archive and verify reported attainment budgets."""
from pathlib import Path
from functools import lru_cache
from collections import defaultdict
import gzip,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
RENAME={'Model-uncertainty':'Updated MU','Density-weighted uncertainty':'Updated DWU','Conditional max-min':'Max-min','Proportional-representative':'Proportional'}
@lru_cache(None)
def archive():
    with gzip.open(ROOT/'data/acquisition_paths.json.gz','rt',encoding='utf8') as f:return json.load(f)
def expected(case,seed,setting=None):
    setting=setting or ('archived' if case=='Paphos' else 'primary_y8')
    prefix=f'{case}|{setting}|{seed}|'
    return {k[len(prefix):]:v for k,v in archive().items() if k.startswith(prefix)}
def main():
    parent=ROOT.parent;inp=parent/'Revision_Analysis_v5/inputs'
    refs=pd.read_csv(inp/'reference_membership.csv',dtype={'object_id':str,'set_id':str})
    refs=refs[refs.eligible.astype(str).str.lower()=='true']
    units={(c,t):{u:set(g.object_id) for u,g in h.groupby('set_id')} for (c,t),h in refs.groupby(['dataset','target_id'])}
    starts=pd.read_csv(inp/'initial_sets.csv',dtype={'object_id':str})
    starts={(c,int(s)):set(g.object_id) for (c,s),g in starts.groupby(['dataset','replay_id'])}
    meta=pd.read_csv(ROOT/'data/path_metadata.csv',keep_default_na=False).set_index('path_id')
    out=[]
    for pid,seq in archive().items():
        m=meta.loc[pid];case=m.dataset;seed=int(m.replay_id);p=list(map(str,seq));n=97 if case=='Paphos' else 183
        assert len(p)==len(set(p))==n and set(p[:15])==starts[case,seed]
        ranks={x:max(15,i+1) for i,x in enumerate(p)}
        for (c,t),u in units.items():
            if c!=case:continue
            for k in ([1,2] if c=='Paphos' else [1,2,3,5]):
                b=max(sorted(ranks[x] for x in v)[k-1] for v in u.values())
                assert all(len(set(p[:b])&v)>=k for v in u.values())
                if b>15:assert any(len(set(p[:b-1])&v)<k for v in u.values())
                out.append(dict(case=c,order=m.run_set,seed=seed,rule=m.rule,target=t,k=k,budget=b))
    scored=pd.DataFrame(out)
    primary=pd.read_csv(inp/'endpoints.csv')
    cols=['case','order','seed','rule','target','k']
    j=primary.merge(scored,on=cols,suffixes=('_saved','_calculated'),validate='one_to_one')
    assert len(j)==len(primary) and (j.budget_saved==j.budget_calculated).all()
    extra=pd.read_csv(inp/'additional_sensitivity_endpoints_v15.csv').rename(columns={'dataset':'case','run_set':'order'})
    j2=extra.merge(scored,on=cols,suffixes=('_saved','_calculated'),validate='one_to_one')
    assert len(j2)==len(extra) and (j2.budget_saved==j2.budget_calculated).all()
    outdir=ROOT/'recomputed';outdir.mkdir(exist_ok=True)
    scored.to_csv(outdir/'all_endpoints.csv',index=False)
    print(json.dumps({'status':'PASS','paths':len(archive()),'primary_endpoints':len(j),'sensitivity_endpoints':len(j2),'models_fitted':0}))
if __name__=='__main__':main()
