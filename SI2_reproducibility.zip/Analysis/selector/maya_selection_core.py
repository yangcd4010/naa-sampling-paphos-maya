"""Selection API: numeric predictors and revealed responses only; no reference labels."""
import numpy as np
from scipy.spatial.distance import cdist
from sklearn.ensemble import RandomForestRegressor

RULES=('Random','Proportional','PQMM','Max-min','Updated MU','Updated DWU','Frozen MU','Frozen DWU')
def argbest(candidates,scores,ids):
 m=np.max(scores);return min((int(i) for i,s in zip(candidates,scores) if abs(s-m)<=1e-12),key=lambda i:ids[i])
def responses(observed,mode):
 if mode=='y8':return observed,0
 a=np.log10(observed);keep=np.isfinite(a).any(axis=0);a=a[:,keep]
 med=np.nanmedian(a,axis=0);a=np.where(np.isnan(a),med,a);return a-a.mean(axis=1,keepdims=True),int((~keep).sum())
def uncertainty(x_seen,y_seen,x_query,seed,budget,mode,fixed_forest_seed=None):
 y,omitted=responses(y_seen,mode)
 forest=RandomForestRegressor(n_estimators=300,max_features='sqrt',min_samples_leaf=2,bootstrap=True,max_samples=.8,n_jobs=1,random_state=((seed*1000+budget)%(2**32-1) if fixed_forest_seed is None else int(fixed_forest_seed)))
 forest.fit(x_seen,y)
 query32=np.asarray(x_query,dtype=np.float32,order="C")
 predictions=np.stack([t.predict(query32,check_input=False) for t in forest.estimators_])
 scores=np.mean(predictions.var(axis=0,ddof=0)/(y.var(axis=0,ddof=1)+1e-8),axis=1)
 assert np.isfinite(scores).all()
 return scores,omitted
def geometry(x,clusters):
 d=cdist(x,x);h=np.median(d[np.triu_indices(len(x),1)])
 kernel=np.exp(-d*d/(2*h*h));np.fill_diagonal(kernel,0)
 medoids={}
 for c in np.unique(clusters):
  ii=np.flatnonzero(clusters==c);medoids[int(c)]=int(ii[np.argmin(d[np.ix_(ii,ii)].sum(axis=1))])
 return d,kernel,medoids
def static_choice(rule,ids,clusters,selected,remaining,d,medoids,rng):
 if rule=='Random':return int(rng.choice(remaining))
 if rule=='Max-min':return argbest(remaining,d[np.ix_(remaining,selected)].min(axis=1),ids)
 counts=np.bincount(clusters[selected],minlength=int(clusters.max())+1);sizes=np.bincount(clusters)
 available=np.unique(clusters[remaining]);deficits=(len(selected)+1)*sizes/len(ids)-counts
 c=min(int(c) for c in available if abs(deficits[c]-deficits[available].max())<=1e-12)
 candidates=remaining[clusters[remaining]==c]
 if rule=='Proportional' or not np.any(clusters[selected]==c):scores=-d[candidates,medoids[c]]
 else:scores=d[np.ix_(candidates,np.array(selected)[clusters[selected]==c])].min(axis=1)
 return argbest(candidates,scores,ids)
def make_path(rule,ids,x,get_revealed,clusters,initial,seed,mode,precomputed=None,maximum=None,fixed_forest_seed=None):
 n=len(ids);maximum=n if maximum is None else maximum
 d,kernel,medoids=geometry(x,clusters) if precomputed is None else precomputed
 selected=list(map(int,initial));mask=np.ones(n,bool);mask[selected]=False;rng=np.random.default_rng(seed+1000000);omitted_max=0
 frozen=None
 if rule.startswith('Frozen'):
  frozen,omitted=uncertainty(x[selected],get_revealed(selected),x,seed,len(selected),mode,fixed_forest_seed);omitted_max=max(omitted_max,omitted)
 for b in range(len(selected),maximum):
  remaining=np.flatnonzero(mask)
  if rule in RULES[:4]:choice=static_choice(rule,ids,clusters,selected,remaining,d,medoids,rng)
  elif len(remaining)==1:choice=int(remaining[0])
  else:
   if frozen is not None:scores=frozen[remaining].copy()
   else:
    scores,omitted=uncertainty(x[selected],get_revealed(selected),x[remaining],seed,b,mode,fixed_forest_seed);omitted_max=max(omitted_max,omitted)
   if rule.endswith('DWU'):scores*=kernel[np.ix_(remaining,remaining)].sum(axis=1)/max(len(remaining)-1,1)
   choice=argbest(remaining,scores,ids)
  assert mask[choice];selected.append(choice);mask[choice]=False
 return selected,omitted_max
