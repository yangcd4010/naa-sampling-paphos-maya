"""Selectors take pre-NAA information only. Reference labels/measurements are absent."""
from collections import defaultdict
import numpy as np

def cells_from_metadata(amg,clusters):
    cells=defaultdict(list);a_to_c=defaultdict(set);c_to_a=defaultdict(set)
    for i,(a,c) in enumerate(zip(amg,clusters)):
        if a and c.lower()!='loner':
            cells[a,c].append(i);a_to_c[a].add(c);c_to_a[c].add(a)
    return {key:(members,len(a_to_c[key[0]])+len(c_to_a[key[1]])-2)
            for key,members in cells.items() if len(a_to_c[key[0]])>1 or len(c_to_a[key[1]])>1}

def min_tied(indices,values,ids,maximize=False,tol=1e-12):
    best=max(values) if maximize else min(values)
    return min((i for i,v in zip(indices,values) if abs(v-best)<=tol),key=lambda i:ids[i])

def within(members,selected,distance,ids,tol):
    have=[i for i in members if i in selected];rest=[i for i in members if i not in selected]
    if have:
        return min_tied(rest,distance[np.ix_(rest,have)].min(axis=1),ids,True,tol)
    medoid=min_tied(members,distance[np.ix_(members,members)].sum(axis=1),ids,False,tol)
    return min_tied(rest,distance[rest,medoid],ids,False,tol)

def quota_choice(selected,clusters,distance,ids,tol):
    by=defaultdict(list)
    for i,c in enumerate(clusters):by[c].append(i)
    scores={c:(len(selected)+1)*len(members)/len(ids)-sum(i in selected for i in members)
            for c,members in by.items() if any(i not in selected for i in members)}
    best=max(scores.values());c=min(c for c,v in scores.items() if abs(v-best)<=tol)
    return within(by[c],selected,distance,ids,tol),c,'quota'

def choose(selected,clusters,discrepancy_cells,distance,ids,tol,discrepancy=False):
    if discrepancy:
        unfinished=[]
        for key,(members,degree) in discrepancy_cells.items():
            have=sum(i in selected for i in members)
            if have<min(2,len(members)):unfinished.append((have,-degree,key,members))
        if unfinished:
            _,_,key,members=min(unfinished,key=lambda z:z[:3])
            return within(members,selected,distance,ids,tol),'|'.join(key),'discrepancy'
    return quota_choice(selected,clusters,distance,ids,tol)

def complete_order(initial,clusters,discrepancy_cells,distance,ids,tol,discrepancy=False):
    order=list(initial);trace=[]
    while len(order)<len(ids):
        i,key,phase=choose(set(order),clusters,discrepancy_cells,distance,ids,tol,discrepancy)
        order.append(i);trace.append((len(order),i,key,phase))
    return order,trace
