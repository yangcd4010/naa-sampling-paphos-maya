from __future__ import annotations
from pathlib import Path
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
import argparse, json, hashlib, math, os, sys, time
import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent/'ai4s_paphos_replay'
if (OUT/'source_inputs/replay_baseline').is_dir():
    ROOT=OUT/'source_inputs/replay_baseline'
sys.path.append(str(OUT.parent/'_analysis_runtime_deps'))
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler

STRATEGIES=['Random','Proportional-representative','Model-uncertainty','Density-weighted uncertainty','Conditional max-min']
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write_json(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')

def load_inputs():
    paths={'config':ROOT/'config.json','pxrf':ROOT/'derived_data/pxrf_fragment_level.csv',
      'naa':ROOT/'derived_data/naa_oracle_clr.csv','initial_designs':ROOT/'results/full_budget_benchmark.csv',
      'metadata':ROOT/'derived_data/id_crosswalk.csv','plan':OUT/'replay_plan.json'}
    config=json.loads(paths['config'].read_text(encoding='utf-8'))
    xcols=[f'alr_{e}_over_Fe' for e in config['pxrf_alr_features']]
    ycols=[f'clr_{e}' for e in config['naa_target_elements']]
    pxrf=pd.read_csv(paths['pxrf']); naa=pd.read_csv(paths['naa'])
    frame=naa[['fragment_id',*ycols]].merge(pxrf[['fragment_id',*xcols,'fragment_pxrf_cluster']],on='fragment_id',validate='one_to_one').sort_values('fragment_id').reset_index(drop=True)
    assert len(frame)==frame.fragment_id.nunique()==97
    ids=frame.fragment_id.to_numpy(str); rawx=frame[xcols].to_numpy(float); y=frame[ycols].to_numpy(float)
    assert np.isfinite(rawx).all() and np.isfinite(y).all()
    x=StandardScaler().fit_transform(rawx); clusters=frame.fragment_pxrf_cluster.to_numpy(str)
    full=pd.read_csv(paths['initial_designs']); initial={}
    for seed,g in full.groupby('seed'):
        assert g.initial_ids.nunique()==1
        initial[int(seed)]=g.iloc[0].initial_ids.split(';')
        assert len(initial[int(seed)])==len(set(initial[int(seed)]))==15
        assert set(initial[int(seed)])<=set(ids)
    assert set(initial)==set(range(1001,1101))
    manifest={key:{'path':str(p),'sha256':digest(p)} for key,p in paths.items()}
    write_json(OUT/'input_manifest.json',manifest);write_json(OUT/'initial_sets.json',initial)
    return ids,x,y,clusters,initial,config,manifest

def tied_max(candidates,scores,ids,tol):
    assert np.isfinite(scores).all()
    tied=candidates[np.isclose(scores,np.max(scores),rtol=0,atol=tol)]
    return min(tied.tolist(),key=lambda i:ids[i])

def uncertainty_from_observed(x_observed,y_observed,x_candidates,config,seed,budget):
    # This function receives selected NAA rows only. It cannot access candidate NAA.
    params=dict(config['rf_hyperparameters']);params['n_jobs']=1
    model=RandomForestRegressor(random_state=(seed*1000+budget)%(2**32-1),**params)
    model.fit(x_observed,y_observed)
    predictions=np.stack([tree.predict(x_candidates) for tree in model.estimators_],axis=0)
    tree_var=predictions.var(axis=0,ddof=config['numeric_conventions']['tree_prediction_variance_ddof'])
    target_var=y_observed.var(axis=0,ddof=config['numeric_conventions']['labelled_target_variance_ddof'])
    scores=np.mean(tree_var/(target_var+config['numeric_conventions']['uncertainty_epsilon']),axis=1)
    assert np.isfinite(scores).all()
    return scores

def run_one(seed,ids,x,y,clusters,initial,config,seed_dir,maximum=97):
    start=time.monotonic(); idpos={v:i for i,v in enumerate(ids)}
    init=[idpos[v] for v in initial[seed]]; n=len(ids);tol=config['numeric_conventions']['tie_tolerance']
    distances=np.sqrt(((x[:,None,:]-x[None,:,:])**2).sum(axis=2))
    bandwidth=float(np.median(distances[np.triu_indices(n,1)]))
    kernel=np.exp(-(distances**2)/(2*bandwidth**2));np.fill_diagonal(kernel,0)
    cluster_sizes=Counter(clusters.tolist()); medoids={}
    for cluster in sorted(cluster_sizes):
        pos=np.where(clusters==cluster)[0]
        medoids[cluster]=pos[int(np.argmin(distances[np.ix_(pos,pos)].sum(axis=1)))]
    rows=[]
    for strategy in STRATEGIES:
        labelled=list(init); rng=np.random.default_rng(seed+1000000)
        for budget in range(15,maximum):
            remaining=np.array([i for i in range(n) if i not in set(labelled)],dtype=int)
            score=None; unc=None; den=None
            if strategy=='Random': chosen=int(rng.choice(remaining))
            elif strategy=='Conditional max-min':
                scores=distances[np.ix_(remaining,labelled)].min(axis=1)
                chosen=tied_max(remaining,scores,ids,tol);score=float(scores[np.where(remaining==chosen)[0][0]])
            elif strategy=='Proportional-representative':
                counts=Counter(clusters[labelled].tolist())
                available=sorted(set(clusters[remaining]));next_n=budget+1
                deficits={c:next_n*cluster_sizes[c]/n-counts[c] for c in available}
                best=max(deficits.values()); c=sorted(c for c,v in deficits.items() if math.isclose(v,best,abs_tol=tol))[0]
                candidates=remaining[clusters[remaining]==c]
                dd=distances[candidates,medoids[c]]
                chosen=tied_max(candidates,-dd,ids,tol);score=float(deficits[c])
            elif len(remaining)==1:
                chosen=int(remaining[0])
            else:
                observed=np.array(labelled,dtype=int)
                uscores=uncertainty_from_observed(x[observed],y[observed],x[remaining],config,seed,budget)
                dscores=kernel[np.ix_(remaining,remaining)].sum(axis=1)/max(len(remaining)-1,1)
                scores=uscores if strategy=='Model-uncertainty' else uscores*dscores
                chosen=tied_max(remaining,scores,ids,tol)
                j=np.where(remaining==chosen)[0][0];score=float(scores[j]);unc=float(uscores[j]);den=float(dscores[j])
            assert chosen not in labelled
            labelled.append(chosen)
            rows.append({'seed':seed,'strategy':strategy,'acquisition_step':budget-14,'budget':budget+1,'sample_id':ids[chosen],
                'acquisition_score':score,'uncertainty_score':unc,'density_score':den,'NAA_observed_before_selection':budget})
        assert len(labelled)==maximum and len(set(labelled))==maximum
        if maximum==n: assert set(labelled)==set(range(n))
    frame=pd.DataFrame(rows); target=seed_dir/f'seed_{seed}.csv'
    tmp=target.with_suffix('.csv.tmp');frame.to_csv(tmp,index=False,encoding='utf-8-sig');tmp.replace(target)
    result={'seed':seed,'seconds':round(time.monotonic()-start,2),'rows':len(frame),'sha256':digest(target),'status':'PASS'}
    write_json(seed_dir/f'seed_{seed}.json',result)
    return result

def validate_csv(path,initial):
    df=pd.read_csv(path);seed=int(df.seed.iloc[0]);assert set(df.strategy)==set(STRATEGIES)
    for strategy,g in df.groupby('strategy'):
        assert g.budget.tolist()==list(range(16,98))
        assert g.sample_id.nunique()==82 and len(g)==82
        assert not set(g.sample_id)&set(initial[seed])
        assert g.NAA_observed_before_selection.tolist()==list(range(15,97))
    return df

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['pilot','formal','combine'],required=True);p.add_argument('--workers',type=int,default=5)
    a=p.parse_args();ids,x,y,clusters,initial,config,manifest=load_inputs()
    seed_dir=OUT/'seed_results';seed_dir.mkdir(exist_ok=True)
    seeds=list(range(1001,1006)) if a.mode=='pilot' else list(range(1001,1101))
    if a.mode!='combine':
        todo=[s for s in seeds if not (seed_dir/f'seed_{s}.csv').exists()]
        for s in seeds:
            if (seed_dir/f'seed_{s}.csv').exists():validate_csv(seed_dir/f'seed_{s}.csv',initial)
        print(f'{a.mode}: {len(todo)} pending seeds, {a.workers} workers, 97 candidates, budgets 15-97',flush=True)
        with ProcessPoolExecutor(max_workers=a.workers) as executor:
            jobs={executor.submit(run_one,s,ids,x,y,clusters,initial,config,seed_dir):s for s in todo}
            for future in as_completed(jobs):
                r=future.result();validate_csv(seed_dir/f'seed_{r["seed"]}.csv',initial)
                print(json.dumps(r),flush=True)
    frames=[validate_csv(seed_dir/f'seed_{s}.csv',initial) for s in seeds]
    for v in manifest.values():assert digest(Path(v['path']))==v['sha256']
    combined=pd.concat(frames,ignore_index=True)
    name='pilot_trajectories.csv' if a.mode=='pilot' else 'full97_trajectories.csv'
    combined.to_csv(OUT/name,index=False,encoding='utf-8-sig')
    timings=[json.loads((seed_dir/f'seed_{s}.json').read_text(encoding='utf-8'))['seconds'] for s in seeds]
    report={'status':'PASS','mode':a.mode,'seeds':len(seeds),'strategies':5,'candidate_n':97,'initial_n':15,'last_budget':97,
      'trajectory_rows':len(combined),'seed_seconds_median':float(np.median(timings)),
      'seed_seconds_range':[min(timings),max(timings)],'all_initial_plus_acquisitions_cover97':True,'input_hashes_unchanged':True}
    write_json(OUT/(a.mode+'_validation.json'),report);print(json.dumps(report),flush=True)

if __name__=='__main__':main()
