"""Selection functions receive initial NAA only; scoring labels are not inputs."""
import numpy as np
from sklearn.ensemble import RandomForestRegressor

def fit_initial(x_initial,y_initial,x_pool,config,seed):
    params=dict(config['rf_hyperparameters']);params['n_jobs']=1
    model=RandomForestRegressor(random_state=(seed*1000+15)%(2**32-1),**params)
    model.fit(x_initial,y_initial)
    predictions=np.stack([tree.predict(x_pool) for tree in model.estimators_],axis=0)
    denom=y_initial.var(axis=0,ddof=config['numeric_conventions']['labelled_target_variance_ddof'])+config['numeric_conventions']['uncertainty_epsilon']
    scores=(predictions.var(axis=0,ddof=config['numeric_conventions']['tree_prediction_variance_ddof'])/denom).mean(axis=1)
    return scores,predictions,denom

def acquire(ids,selected,uncertainty,kernel,density_weighted,tol):
    remaining=np.array([i for i in range(len(ids)) if i not in set(selected)])
    density=kernel[np.ix_(remaining,remaining)].sum(axis=1)/max(len(remaining)-1,1)
    score=uncertainty[remaining]*density if density_weighted else uncertainty[remaining]
    tied=remaining[np.isclose(score,np.max(score),rtol=0,atol=tol)]
    chosen=min(tied.tolist(),key=lambda i:ids[i])
    j=np.flatnonzero(remaining==chosen)[0]
    return chosen,float(score[j]),float(density[j])

def path(ids,initial,uncertainty,kernel,density_weighted,tol):
    selected=list(initial);rows=[]
    while len(selected)<len(ids):
        chosen,score,density=acquire(ids,selected,uncertainty,kernel,density_weighted,tol)
        selected.append(chosen);rows.append((len(selected),chosen,score,density))
    return rows
