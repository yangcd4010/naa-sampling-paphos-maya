"""Regenerate all primary selectors from archived transformed measurement inputs."""
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import sys,json,time,argparse,platform
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,pandas as pd
try:import sklearn
except ModuleNotFoundError:
 sys.path.append(str(Path(__file__).resolve().parents[2]/'_analysis_runtime_deps'))
 import sklearn
ROOT=Path(__file__).resolve().parent;S=ROOT/'selector';sys.path.insert(0,str(S))
import maya_selection_core as maya
import paphos_full_pool_replay as paphos
import paphos_frozen_selector as frozen
import paphos_allocation_core as allocation
import evaluate_paths as old
def load_paphos():
 g=np.load(S/'paphos_geometry.npz');ids=g['ids'];x=g['x'];clusters=g['clusters'];d=g['distance'];amg=g['amg']
 cfg=json.loads((S/'paphos_config.json').read_text());yy=pd.read_csv(ROOT/'inputs/paphos/naa_oracle_clr.csv').sort_values('fragment_id')
 assert yy.fragment_id.tolist()==ids.tolist();y=yy[['clr_'+e for e in cfg['naa_target_elements']]].to_numpy()
 starts=json.loads((ROOT/'inputs/paphos/initial_sets.json').read_text());index={s:i for i,s in enumerate(ids)}
 return ids,x,y,clusters,d,amg,cfg,starts,index
def task(case,seed):
 start=time.monotonic();out=ROOT/'qa/selector_reproduction'/case;out.mkdir(parents=True,exist_ok=True)
 target=out/f'{seed}.json'
 if target.exists():return json.loads(target.read_text())
 if case=='Maya':
  a=np.load(S/'maya_inputs.npz');ids=a['ids'];x=a['x'];y=a['y8'];clusters=a['clusters10'];init=json.loads((ROOT/'inputs/maya/initial_sets.json').read_text())[str(seed)];geom=maya.geometry(x,clusters)
  generated={rule:maya.make_path(rule,ids,x,lambda ii:y[ii],clusters,init,seed,'y8',geom)[0] for rule in maya.RULES}
  expected=old.expected('Maya',seed)
 else:
  ids,x,y,clusters,d,amg,cfg,starts,index=load_paphos();init=[index[s] for s in starts[str(seed)]]
  paphos.run_one(seed,ids,x,y,clusters,{int(s):v for s,v in starts.items()},cfg,out)
  data=pd.read_csv(out/f'seed_{seed}.csv');generated={old.RENAME.get(rule,rule):starts[str(seed)]+g.sort_values('budget').sample_id.tolist() for rule,g in data.groupby('strategy')}
  h=np.median(d[np.triu_indices(len(ids),1)]);kernel=np.exp(-d*d/(2*h*h));np.fill_diagonal(kernel,0)
  u,_,_=frozen.fit_initial(x[init],y[init],x,cfg,seed)
  for rule,weighted in [('Frozen MU',False),('Frozen DWU',True)]:generated[rule]=[str(ids[i]) for i in init+[j for b,j,sc,de in frozen.path(ids,init,u,kernel,weighted,1e-12)]]
  cells=allocation.cells_from_metadata(amg,clusters)
  for rule,disc in [('PQMM',False),('APDC',True)]:generated[rule]=[str(ids[i]) for i in allocation.complete_order(init,clusters,cells,d,ids,1e-12,disc)[0]]
  # Cross-stratified full eligible cells; published within-cell ordering.
  from collections import defaultdict
  allcells=defaultdict(list)
  for i,(a,c) in enumerate(zip(amg,clusters)):
   if a and c.lower()!='loner':allcells[a,c].append(i)
  selected=list(init)
  while len(selected)<len(ids):
   sel=set(selected);available=[(sum(i in sel for i in m),key,m) for key,m in allcells.items() if sum(i in sel for i in m)<min(2,len(m))]
   if available:_,key,m=min(available,key=lambda z:z[:2]);j=allocation.within(m,sel,d,ids,1e-12)
   else:j=allocation.quota_choice(sel,clusters,d,ids,1e-12)[0]
   selected.append(j)
  generated['Cross-stratified']=[str(ids[i]) for i in selected]
  expected=old.expected('Paphos',seed)
 checks=[]
 for rule,path in generated.items():
  match=path==expected[rule];first=next((i+1 for i,(a,b) in enumerate(zip(path,expected[rule])) if a!=b),None)
  checks.append(dict(rule=rule,path_matches=match,first_mismatch_position=first,length=len(path)))
 result=dict(dataset=case,seed=seed,status='PASS' if all(c['path_matches'] for c in checks) else 'FAIL',checks=checks,seconds=time.monotonic()-start,generated_paths=generated)
 target.write_text(json.dumps(result),encoding='utf8');return {k:v for k,v in result.items() if k!='generated_paths'}
def main():
 p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=10);p.add_argument('--stop',type=int,default=1100);p.add_argument('--case',choices=['Paphos','Maya','both'],default='both');a=p.parse_args();start=time.monotonic();items=[]
 with ProcessPoolExecutor(max_workers=a.workers) as pool:
  fs=[pool.submit(task,case,seed) for case in (['Paphos','Maya'] if a.case=='both' else [a.case]) for seed in range(1001,a.stop+1)]
  for f in as_completed(fs):
   r=f.result();items.append(r);print(json.dumps({k:v for k,v in r.items() if k not in ['checks','generated_paths']}),flush=True)
   if r['status']!='PASS':print(json.dumps(r),flush=True)
 report=dict(status='PASS' if all(r['status']=='PASS' for r in items) else 'FAIL',scope='Primary selectors for the requested cases and start range; additional sensitivities retain archived paths.',initial_set_pairs=len(items),paths=sum(len(r['checks']) for r in items),seconds=time.monotonic()-start,workers=a.workers,versions={'python':platform.python_version(),'numpy':np.__version__,'sklearn':sklearn.__version__},results=[{k:v for k,v in r.items() if k!='generated_paths'} for r in items])
 (ROOT/'qa/selector_reproduction.json').write_text(json.dumps(report,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in report.items() if k!='results'}),flush=True)
if __name__=='__main__':main()
