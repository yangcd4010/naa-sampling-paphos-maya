"""Post-hoc oracle bounds and descriptive geometry on unchanged archived paths."""
from pathlib import Path
from itertools import permutations
import json, hashlib, argparse
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--geometry-input',type=Path,default=ROOT.parent/'Analysis/selector/maya_inputs.npz',help='Local standardized Maya predictor NPZ produced by the source adapter; not redistributed')
parser.add_argument('--oracle-only',action='store_true',help='Recalculate oracle bounds without Maya predictor coordinates')
args=parser.parse_args()
IN=ROOT.parent/'Revision_Analysis_v5/inputs'; OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
protocol=json.loads((ROOT/'REVISION_ANALYSIS_PROTOCOL.json').read_text(encoding='utf-8'))
def save(df,name): df.to_csv(OUT/name,index=False,encoding='utf-8-sig',float_format='%.12g')
def dump(name,x): (OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
refs=pd.read_csv(IN/'reference_membership.csv',dtype={'object_id':str,'set_id':str})
refs=refs[refs.eligible.astype(str).str.lower()=='true']
starts=pd.read_csv(IN/'initial_sets.csv',dtype={'object_id':str})
initial={(case,int(seed)):set(g.object_id) for (case,seed),g in starts.groupby(['dataset','replay_id'])}
assert len(initial)==200 and all(len(s)==15 for s in initial.values())
sets={}
for (case,target),g in refs.groupby(['dataset','target_id']):
    units={u:set(f.object_id) for u,f in g.groupby('set_id')}
    union=set()
    for members in units.values():
        assert not union.intersection(members),(case,target,'overlap')
        union.update(members)
    sets[case,target]=units

rows=[]
for (case,target),units in sets.items():
    ks=protocol['oracle']['primary_Paphos_k'] if case=='Paphos' else protocol['oracle']['Maya_k']
    for seed in range(1001,1101):
        a=initial[case,seed]
        for k in ks:
            counts={u:len(a&m) for u,m in units.items()}
            assert all(len(m)>=k for m in units.values())
            # Independent form: count absent required members after capped initial counts.
            lower=15+sum(max(0,k-v) for v in counts.values())
            alternate=15+len(units)*k-sum(min(k,v) for v in counts.values())
            assert lower==alternate
            rows.append({'case':case,'seed':seed,'target':target,'k':k,'oracle_budget':lower,
                'required_sets':len(units),'initial_counts_json':json.dumps(counts,sort_keys=True),
                'minimum_set_size':min(map(len,units.values()))})
oracle=pd.DataFrame(rows);assert len(oracle)==2000
save(oracle,'oracle_lower_bound_by_start.csv')
summary=oracle.groupby(['case','target','k']).oracle_budget.agg(['mean','min','max']).reset_index()
save(summary,'oracle_lower_bound_summary.csv')
ends=pd.read_csv(IN/'endpoints.csv')
maya_endpoints={(int(r.seed),r.rule,r.target,int(r.k)):int(r.budget) for r in ends[ends['case']=='Maya'].itertuples()}
gaps=ends.merge(oracle[['case','seed','target','k','oracle_budget']],on=['case','seed','target','k'],validate='many_to_one')
assert len(gaps)==len(ends)==66400
gaps['budget_gap']=gaps.budget-gaps.oracle_budget
assert gaps.budget_gap.ge(0).all()
save(gaps,'oracle_budget_gap_by_path.csv')
# A balanced crossed start/order collection gives each start equal weight.
fabric=gaps.rule.isin(['APDC','Cross-stratified'])
primary=gaps[(gaps['case']=='Maya') | ((~fabric)&(gaps.order=='archived')) | (fabric&gaps.order.str.startswith('random_'))]
gap_summary=primary.groupby(['case','target','k','rule']).agg(mean_budget=('budget','mean'),
 mean_oracle=('oracle_budget','mean'),mean_gap=('budget_gap','mean'),min_gap=('budget_gap','min'),
 max_gap=('budget_gap','max'),path_configurations=('budget_gap','size')).reset_index()
save(gap_summary,'oracle_budget_gap_summary.csv')
sens=pd.read_csv(IN/'AEG5_sensitivity_endpoints.csv')
sens_oracle=[]
units=sets['Paphos','Aegean_six_unlocated_patterns']
for excluded in protocol['oracle']['AEG5_exclusions']:
    assert excluded in units['AEG5']
    altered={u:(m-{excluded}) for u,m in units.items()}
    for seed in range(1001,1101):
        for k in [1,2]:
            lower=15+sum(max(0,k-len(initial['Paphos',seed]&m)) for m in altered.values())
            sens_oracle.append({'seed':seed,'excluded':excluded,'k':k,'oracle_budget':lower})
sens_oracle=pd.DataFrame(sens_oracle);assert len(sens_oracle)==800
save(sens_oracle,'oracle_AEG5_sensitivity_by_start.csv')
sg=sens[sens.excluded!='none'].merge(sens_oracle,on=['seed','excluded','k'],validate='many_to_one')
sg['budget_gap']=sg.budget-sg.oracle_budget;assert sg.budget_gap.ge(0).all()
sg_primary=sg[(~sg.rule.isin(['APDC','Cross-stratified']) & (sg.order=='archived')) | (sg.rule.isin(['APDC','Cross-stratified']) & sg.order.str.startswith('random_'))]
save(sg_primary.groupby(['excluded','k','rule']).agg(mean_budget=('budget','mean'),mean_oracle=('oracle_budget','mean'),mean_gap=('budget_gap','mean')).reset_index(),'oracle_AEG5_sensitivity_summary.csv')

# Meaningful independent validation: exhaust all possible orders of a small disjoint pool.
small_checks=[]
pool=list(range(7)); smallsets=[{0,1,2},{3,4},{5,6}]
for start in [{0},{0,3},{0,3,5}]:
    for k in [1,2]:
        theoretical=len(start)+sum(max(0,k-len(start&m)) for m in smallsets)
        budgets=[]
        for perm in permutations([i for i in pool if i not in start]):
            seen=set(start);budget=len(seen)
            if not all(len(seen&m)>=k for m in smallsets):
                for i in perm:
                    seen.add(i);budget+=1
                    if all(len(seen&m)>=k for m in smallsets):break
            budgets.append(budget)
        assert min(budgets)==theoretical
        small_checks.append({'start':sorted(start),'k':k,'formula':theoretical,'exhaustive_minimum':min(budgets),'orders':len(budgets)})

dump('oracle_validation.json',{'status':'PASS','primary_bounds':2000,'AEG5_bounds':800,'budget_gap_records':66400,'sets_disjoint':True,'all_budget_gaps_nonnegative':True,'small_pool_exhaustive_checks':small_checks})
if args.oracle_only:
    print('Oracle-only recalculation PASS: 2000 primary bounds and 800 AEG5 bounds.');raise SystemExit(0)
if not args.geometry_input.exists():
    raise FileNotFoundError('Standardized Maya predictor coordinates are intentionally not redistributed. Supply --geometry-input with the locally obtained source-adapter NPZ, or use --oracle-only.')
with np.load(args.geometry_input,allow_pickle=False) as a:ids=a['ids'];x=a['x']
assert x.shape==(183,11) and ids.shape==(183,) and np.isfinite(x).all(),'Unexpected predictor dimensions or nonfinite values'
source_manifest=json.loads((ROOT/'SOURCE_INPUT_MANIFEST.json').read_text(encoding='utf-8'))
assert hashlib.sha256(x.tobytes()).hexdigest()==source_manifest['maya_pxrf_geometry.npz']['x_raw_bytes_sha256'],'Predictor coordinate hash differs from the analysed version'
gm=pd.read_csv(IN/'maya_group_map.csv',dtype={'object_id':str,'broad_group':str,'terminal_category':str})
assert ids.tolist()==gm.object_id.tolist() and gm.object_index.tolist()==list(range(183))
assert np.allclose(x.mean(axis=0),0,atol=1e-10) and np.allclose(x.std(axis=0,ddof=0),1,atol=1e-10)
labels={'main':gm.broad_group.to_numpy(),'terminal':gm.terminal_category.to_numpy()}
D=np.sqrt(np.sum((x[:,None,:]-x[None,:,:])**2,axis=2))
paths=pd.read_csv(IN/'maya_geometry_paths.csv',dtype={'object_id':str})
geom=[];positions=[];checked_maxmin=0;checked_random=0;attainment_checks=0
for pathid,g in paths.groupby('path_id',sort=False):
    _,run,seed,rule=pathid.split('|');seed=int(seed)
    g=g.sort_values('position');seq=g.object_id.astype(int).to_numpy()
    assert len(seq)==len(set(seq))==183 and set(seq)==set(range(183))
    assert set(map(str,seq[:15]))==initial['Maya',seed]
    rng=np.random.default_rng(seed+1000000)
    for b in range(15,183):
        selected=seq[:b];rem=np.array(sorted(set(range(183))-set(selected)))
        scores=D[np.ix_(rem,selected)].min(axis=1)
        if rule=='Max-min':
            chosen=min((int(i) for i,s in zip(rem,scores) if abs(s-scores.max())<=1e-12),key=lambda i:ids[i])
            assert chosen==seq[b],(pathid,b,chosen,seq[b]);checked_maxmin+=1
            if b in [15,20,30,45,60]:
                # Independent scalar-distance implementation at all fixed nodes.
                scalar=np.array([min(np.sqrt(np.sum((x[i]-x[j])**2)) for j in selected) for i in rem])
                assert np.allclose(scores,scalar,rtol=1e-12,atol=1e-12)
        else:
            assert int(rng.choice(rem))==seq[b],(pathid,b,'random mismatch');checked_random+=1
    for resolution,labs in labels.items():
        categories=sorted(set(labs))
        for category in categories:
            member=np.flatnonzero(labs==category)
            ranks=np.array([int(np.flatnonzero(seq==i)[0])+1 for i in member])
            for i,r in zip(member,ranks):positions.append({'seed':seed,'rule':rule,'resolution':resolution,'category':category,'object_index':int(i),'object_id':ids[i],'position':int(r)})
        for k in [1,2,3,5]:
            budgets=[max(15,int(np.sort([int(np.flatnonzero(seq==i)[0])+1 for i in np.flatnonzero(labs==c)])[k-1])) for c in categories]
            reported=maya_endpoints[seed,rule,resolution,k]
            assert max(budgets)==reported;attainment_checks+=1
        for b in protocol['geometry']['budgets']:
            selected=seq[:b];rem=np.array(sorted(set(range(183))-set(selected)))
            scores=D[np.ix_(rem,selected)].min(axis=1)
            # Midrank percentile, computed directly without a statistical-library dependency.
            pct=np.array([(np.sum(scores<v)+.5*np.sum(scores==v))/len(rem)*100 for v in scores])
            for c in categories:
                member=np.flatnonzero(labs==c);mask=labs[rem]==c
                nselected=int(np.sum(labs[selected]==c));nleft=int(mask.sum())
                geom.append({'seed':seed,'rule':rule,'budget':b,'resolution':resolution,'category':c,
                    'category_size':len(member),'selected_members':nselected,'remaining_members':nleft,
                    'complete_k2':nselected>=2,'mean_score_percentile':float(pct[mask].mean()) if nleft else np.nan,
                    'median_score_percentile':float(np.median(pct[mask])) if nleft else np.nan,
                    'mean_min_distance':float(scores[mask].mean()) if nleft else np.nan})
geom=pd.DataFrame(geom);assert len(geom)==16000
save(geom,'maya_geometry_by_start_budget.csv');save(pd.DataFrame(positions),'maya_member_positions.csv')
draws=np.random.default_rng(protocol['geometry']['bootstrap_seed']).integers(0,100,(10000,100))
summary=[]
for keys,g in geom.groupby(['rule','budget','resolution','category'],sort=False):
    g=g.sort_values('seed');a=g.mean_score_percentile.to_numpy();valid=np.isfinite(a)
    sampled=a[draws];den=np.isfinite(sampled).sum(axis=1);tot=np.nansum(sampled,axis=1)
    means=np.divide(tot,den,out=np.full(len(den),np.nan),where=den>0);good=means[np.isfinite(means)]
    summary.append(dict(zip(['rule','budget','resolution','category'],keys))|{'available_starts':int(valid.sum()),
      'mean_score_percentile':float(a[valid].mean()) if valid.any() else np.nan,
      'mean_lo':float(np.quantile(good,.025)) if len(good) else np.nan,'mean_hi':float(np.quantile(good,.975)) if len(good) else np.nan,
      'mean_remaining_members':float(g.remaining_members.mean()),'complete_k2_fraction':float(g.complete_k2.mean())})
gs=pd.DataFrame(summary);save(gs,'maya_geometry_summary.csv')
start_scores=geom[(geom.rule=='Max-min') & (geom.budget==15) & (geom.resolution=='terminal')].pivot(index='seed',columns='category',values='mean_score_percentile')
key_contrasts=[]
for c in ['3-4','3-6']:
    delta=(start_scores['4']-start_scores[c]).to_numpy();boot=delta[draws].mean(axis=1)
    key_contrasts.append({'comparison':'4 minus '+c,'mean':float(delta.mean()),'low':float(np.quantile(boot,.025)),'high':float(np.quantile(boot,.975))})
dump('geometry_key_paired_contrasts.json',key_contrasts)
pos=pd.DataFrame(positions).groupby(['rule','resolution','category','seed']).position.mean().reset_index()
save(pos.groupby(['rule','resolution','category']).position.agg(['mean','min','max']).reset_index(),'maya_position_summary.csv')
validation={'status':'PASS','oracle_primary_rows':len(oracle),'oracle_AEG5_rows':len(sens_oracle),
 'budget_gap_records':len(gaps),'all_path_budgets_at_least_oracle':True,'within_target_sets_disjoint':True,
 'small_pool_exhaustive_checks':small_checks,'geometry_rows':len(geom),'geometry_paths':200,
 'maxmin_decisions_matched':checked_maxmin,'random_decisions_matched':checked_random,
 'full_target_endpoints_matched':attainment_checks,'independent_scalar_scores_at_nodes':True,
 'all_broad_and_terminal_categories_retained':True,'new_model_fits':0,'new_acquisition_paths':0}
dump('analysis_validation.json',validation)
print(summary if False else 'Analysis PASS')
print(oracle.groupby(['case','target','k']).oracle_budget.agg(['mean','min','max']).to_string())
print(gs[(gs.rule=='Max-min') & (gs.resolution=='terminal') & gs.category.isin(['4','3-4','3-6'])].to_string(index=False))
