"""Single-panel descriptive figure: remaining candidate scores across all terminal categories."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],
 'font.size':7,'svg.fonttype':'none','pdf.fonttype':42,'axes.linewidth':.6})
data=pd.read_csv(ROOT/'results/maya_geometry_summary.csv',dtype={'category':str})
data=data[(data.rule=='Max-min')&(data.resolution=='terminal')]
categories=['1','2-1','2-2','2-3','3-1','3-2','3-3','3-4','3-5','3-6','3-7','4']
budgets=[15,20,30,45,60]
assert set(data.category)==set(categories) and len(data)==60
values=data.pivot(index='category',columns='budget',values='mean_score_percentile').loc[categories,budgets]
assert np.isfinite(values.to_numpy()).all()
fig,ax=plt.subplots(figsize=(5.5,3.7))
fig.subplots_adjust(left=.16,right=.86,bottom=.15,top=.96)
im=ax.imshow(values.to_numpy(),aspect='auto',cmap='Blues',vmin=0,vmax=100)
ax.set_xticks(range(5),[str(b) for b in budgets]);ax.set_yticks(range(12),categories)
ax.set_xlabel('Acquired objects');ax.set_ylabel('Published terminal category')
ax.tick_params(length=0,pad=4)
for tick in ax.get_yticklabels():
    if tick.get_text() in ['3-4','3-6','4']:tick.set_fontweight('bold')
for i in range(12):
    for j in range(5):
        v=values.iloc[i,j];ax.text(j,i,f'{v:.1f}',ha='center',va='center',fontsize=6.5,color='white' if v>=63 else '#17263B')
cax=fig.add_axes([.89,.20,.022,.69]);cb=fig.colorbar(im,cax=cax)
cb.set_label('Mean score percentile',labelpad=5);cb.set_ticks([0,25,50,75,100]);cb.ax.tick_params(length=2,width=.6,labelsize=6.5)
fig.savefig(OUT/'Figure_S2_geometry_v4.pdf')
fig.savefig(OUT/'Figure_S2_geometry_v4.svg')
fig.savefig(OUT/'Figure_S2_geometry_v4.png',dpi=600)
fig.savefig(OUT/'Figure_S2_geometry_v4.tif',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
plt.close(fig)
values.reset_index().to_csv(OUT/'Figure_S2_source.csv',index=False,encoding='utf-8-sig')
contract={'core_question':'Do the delayed Maya categories have low actual max-min scores at fixed acquisition nodes?',
 'archetype':'single quantitative heatmap','backend':'Python/matplotlib','n_starts':100,'all_terminal_categories':12,
 'nodes':budgets,'center':'mean of per-start category mean percentiles among remaining candidates',
 'uncertainty':'pointwise start-bootstrap intervals in Table S51 and geometry summary CSV; figure displays means',
 'no_category_exclusions':True,'alignment':'NOT APPLICABLE: one data panel plus colorbar',
 'width_mm':139.7,'height_mm':93.98,'raster_dpi':600,'minimum_font_pt':6.5,'no_causal_claim':True}
(OUT/'Figure_S2_contract.json').write_text(json.dumps(contract,indent=2),encoding='utf-8')
print('Exported Figure S2 with all 12 categories and five fixed nodes.')
