"""Render comparison-member acquisition from the supplied, unchanged summaries."""
from pathlib import Path
import argparse
import json
import sys
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.transforms import ScaledTranslation

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'Revision_Analysis_v5' / 'tools'))
from audit_panel_alignment import require_matplotlib_panel_alignment

TARGETS = ['Paphian_AMG48_vs_AMG21B', 'Kourion_five_patterns',
           'IMPA_Koan_Thassian_subdivision', 'CYPB_Paphian_Kourion_separation',
           'Sicily_cross_cluster_correction', 'Aegean_six_unlocated_patterns']
TARGET_LABELS = ['Paphian', 'Five\nKourion', 'Koan–\nThassian', 'CYP-B', 'Sicilian', 'Six\nAegean']
RULES = ['Random', 'Proportional', 'PQMM', 'Max-min', 'Frozen MU', 'Updated MU',
         'Frozen DWU', 'Updated DWU', 'Cross-stratified', 'APDC']
RULE_LABELS = ['Exact random', 'Proportional-medoid', 'PQMM', 'Max-min', 'Frozen MU',
               'Updated MU', 'Frozen DWU', 'Updated DWU', 'Cross-stratified', 'APDC']
CURVE_RULES = ['Random', 'PQMM', 'Updated DWU', 'APDC', 'Cross-stratified']
COLORS = {'Random': '#555555', 'PQMM': '#397B60', 'Updated DWU': '#985475',
          'APDC': '#BB703B', 'Cross-stratified': '#326AA5'}
mpl.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'DejaVu Sans'],
                     'font.size': 7, 'axes.labelsize': 7, 'axes.titlesize': 8,
                     'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5,
                     'legend.fontsize': 6.5, 'pdf.fonttype': 42, 'svg.fonttype': 'none',
                     'axes.linewidth': .65, 'axes.spines.top': False,
                     'axes.spines.right': False, 'savefig.dpi': 600})

def label(ax, name):
    ax.set_label(name)
    ax.text(0, 1, name, transform=ax.transAxes + ScaledTranslation(-17/72, 7/72, ax.figure.dpi_scale_trans),
            fontsize=9, fontweight='bold', va='bottom', ha='left')

def percent_label(value):
    assert 0 <= value <= 1
    if value == 0:
        return '0.0'
    if value == 1:
        return '100.0'
    shown = f'{100 * value:.1f}'
    if shown == '0.0':
        return '<0.1'
    if shown == '100.0':
        return '>99.9'
    return shown

def source_objects():
    meta = pd.read_csv(ROOT/'Analysis/inputs/paphos/pre_naa_metadata.csv', keep_default_na=False).set_index('fragment_id')
    refs = pd.read_csv(ROOT/'Revision_Analysis_v5/inputs/paphos_reference_labels.csv', keep_default_na=False).set_index('sample_id')
    naa = pd.read_csv(ROOT/'Analysis/inputs/paphos/naa_oracle_clr.csv', keep_default_na=False).set_index('fragment_id')
    cols = [c for c in naa if c.startswith('clr_') and c not in ['clr_As', 'clr_Lu']]
    assert len(cols) == 29
    coords = naa[cols].subtract(naa.clr_Lu, axis=0)
    ids = [refs[refs.published_2021_group == 'SICILY'].sort_values('naa_id').index.tolist(),
           refs[refs.published_2021_pxrf_cluster == 'CYP-B'].sort_values('naa_id').index.tolist()]
    assert list(map(len, ids)) == [5, 8]
    return meta, refs, coords, ids

def save_figure(fig, prefix, axes, qa_dir, exemptions=()):
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig, axes=axes, json_out=qa_dir/(prefix+'.alignment.json'),
                                      overlay_svg=qa_dir/(prefix+'.alignment.svg'), tolerance_pt=1.5,
                                      gutter_tolerance_pt=1.5, strict=True, exemptions=exemptions)
    fig.savefig(qa_dir/(prefix+'.pdf'))
    fig.savefig(qa_dir/(prefix+'.svg'))
    fig.savefig(qa_dir/(prefix+'.png'), dpi=300)
    fig.savefig(qa_dir/(prefix+'.tif'), dpi=600, pil_kwargs={'compression': 'tiff_lzw'})
    plt.close(fig)

def main(output):
    output.mkdir(parents=True, exist_ok=True)
    snapshot = pd.read_csv(ROOT/'Targeted_Analyses/results/fixed_budget_evidence_snapshot.csv')
    data = snapshot[(snapshot.k == 2) & (snapshot.total_budget == 55) & (snapshot.rule != 'Archived random')].copy()
    assert len(snapshot) == 198 and len(data) == 60
    assert not data.duplicated(['target', 'rule']).any()
    assert set(data.target) == set(TARGETS) and set(data.rule) == set(RULES)
    values = data.pivot(index='rule', columns='target', values='completion_fraction').loc[RULES, TARGETS]
    assert np.isfinite(values.to_numpy()).all() and ((values >= 0) & (values <= 1)).all().all()
    curves = pd.read_csv(ROOT/'Revision_Analysis_v5/results/Paphos_random_order_curves_v5.csv')
    meta, refs, coords, ids = source_objects()
    mapping = {'targets': dict(zip(TARGETS, TARGET_LABELS)), 'rules': dict(zip(RULES, RULE_LABELS)),
               'source': 'Targeted_Analyses/results/fixed_budget_evidence_snapshot.csv',
               'filters': {'k': 2, 'total_budget': 55, 'exclude': 'Archived random'},
               'color_scale_percent': [0, 100], 'precision': 'one decimal, guarded endpoints'}
    (output/'display_mapping.json').write_text(json.dumps(mapping, ensure_ascii=False, indent=2), encoding='utf8')
    checks = []
    for rule in RULES:
        for target in TARGETS:
            value = float(values.loc[rule, target])
            checks.append({'rule': rule, 'target': target, 'completion_fraction': value,
                           'display_percent': percent_label(value)})
    (output/'display_check.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding='utf8')
    # Source tables show all objects, including those outside the two required sets.
    fig = plt.figure(figsize=(180/25.4, 210/25.4))
    gs = fig.add_gridspec(3, 2, height_ratios=[.85, 1.45, .95])
    axs = [fig.add_subplot(gs[0, 0]), fig.add_subplot(gs[0, 1]), fig.add_subplot(gs[1, :]),
           fig.add_subplot(gs[2, 0]), fig.add_subplot(gs[2, 1])]
    fig.subplots_adjust(left=.19, right=.94, bottom=.11, top=.94, wspace=.31, hspace=.49)
    titles = ['Sicilian cross-cluster comparison', 'Subdivision within CYP-B']
    for j, objids in enumerate(ids):
        ax = axs[j]; ax.set_axis_off(); label(ax, 'ab'[j]); ax.set_title(titles[j], pad=11)
        headers = ['Paph17/', 'AMG', 'pXRF', 'NAA']
        xs = [0, .23, .44, .72]
        for x, h in zip(xs, headers):
            ax.text(x, .98, h, transform=ax.transAxes, fontweight='bold', fontsize=6.5, va='top')
        for row, sid in enumerate(objids):
            r = refs.loc[sid]; m = meta.loc[sid]
            eligible = (j == 0) or r.published_2021_group in ['PAPH-C', 'KOUR-B']
            suffix = '' if eligible else ' †'
            texts = [r.naa_id.split('/')[1], m.amg_key or '—', r.published_2021_pxrf_cluster,
                     (r.published_2021_group or 'loner') + suffix]
            for x, t in zip(xs, texts):
                ax.text(x, .86-row*.083, str(t), transform=ax.transAxes, fontsize=6.5, va='top')
        requirement = 'Require: 2 in IMP-G/G2 + both in IMP-D/J' if j == 0 else 'Require: both PAPH-C + 2 of 4 KOUR-B'
        ax.text(0, .105, requirement, transform=ax.transAxes, fontsize=6.3, va='top', color='#333333')
    ax = axs[2]; label(ax, 'c'); ax.set_title('Comparison completion at 55 specimens (%)', pad=12)
    im = ax.pcolormesh(np.arange(7)-.5, np.arange(11)-.5, values.to_numpy()*100,
                       cmap='Blues', vmin=0, vmax=100, shading='flat',
                       edgecolors='white', linewidth=.5, rasterized=False)
    ax.set_xlim(-.5, 5.5); ax.set_ylim(9.5, -.5)
    ax.set_xticks(range(6), TARGET_LABELS); ax.set_yticks(range(10), RULE_LABELS)
    ax.tick_params(length=0, pad=3)
    for i in range(10):
        for j in range(6):
            v = values.iloc[i, j]
            ax.text(j, i, percent_label(v), ha='center', va='center', fontsize=6.5,
                    color='white' if v >= .64 else '#172532')
    cax = fig.add_axes([.956, ax.get_position().y0, .012, ax.get_position().height])
    cb = fig.colorbar(im, cax=cax, ticks=[0, 50, 100]); cb.ax.tick_params(labelsize=6, length=2)
    cb.outline.set_linewidth(.5)
    for j, target in enumerate([TARGETS[4], TARGETS[3]]):
        ax = axs[3+j]; label(ax, 'de'[j]); ax.set_title('Sicilian' if j == 0 else 'CYP-B', pad=11)
        for rule in CURVE_RULES:
            d = curves[(curves.target == target) & (curves.rule == rule)].sort_values('budget')
            assert len(d) == 83 and d.budget.is_unique and np.all(np.diff(d.budget) > 0)
            assert np.all(d.low <= d['mean']+1e-12) and np.all(d.high+1e-12 >= d['mean'])
            assert np.all(np.diff(d['mean']) >= -1e-12)
            at55 = d[d.budget == 55].iloc[0]
            assert abs(float(at55['mean'])-float(values.loc[rule, target])) < 1e-10
            ax.plot(d.budget, d['mean'], color=COLORS[rule], linestyle='--' if rule == 'Random' else '-',
                    linewidth=1.2, label='Exact random' if rule == 'Random' else rule)
            ax.fill_between(d.budget, d.low, d.high, color=COLORS[rule], alpha=.09, linewidth=0)
        ax.axvline(55, color='#666666', linestyle=':', linewidth=.8, zorder=1)
        ax.set_xlim(15, 97); ax.set_ylim(-.025, 1.025); ax.set_xticks([15, 35, 55, 75, 97])
        ax.set_yticks([0, .5, 1]); ax.set_xlabel('Total NAA specimens'); ax.set_ylabel('Completion fraction')
        ax.grid(axis='y', alpha=.12)
    h, names = axs[3].get_legend_handles_labels()
    fig.legend(h, names, loc='lower center', bbox_to_anchor=(.56, .013), ncol=3,
               frameon=False, columnspacing=1.2, handlelength=2)
    save_figure(fig, 'Fig2', axs, output, exemptions=[{'panels': ['c'], 'checks': ['vertical-gutter'],
                'reason': 'The full-width heatmap separates the source-object row from the attainment-curve row.'}])
    # Retain the original NAA transformation and common distance scale.
    allids = ids[0] + ids[1]
    arr = coords.loc[allids].to_numpy()
    vmax = np.sqrt(((arr[:, None]-arr[None, :])**2).sum(axis=2)).max()
    fig, axes = plt.subplots(1, 2, figsize=(180/25.4, 90/25.4))
    fig.subplots_adjust(left=.09, right=.89, bottom=.19, top=.86, wspace=.30)
    pairvalues = []
    for j, objids in enumerate(ids):
        ax = axes[j]; label(ax, 'fg'[j]); a = coords.loc[objids].to_numpy()
        dist = np.sqrt(((a[:, None]-a[None, :])**2).sum(axis=2))
        edges = np.arange(len(objids)+1)-.5
        im = ax.pcolormesh(edges, edges, dist, cmap='Blues', vmin=0, vmax=vmax,
                          shading='flat', rasterized=False)
        ax.set_xlim(-.5, len(objids)-.5); ax.set_ylim(len(objids)-.5, -.5)
        labs = [refs.loc[s].naa_id.split('/')[1] for s in objids]
        ax.set_xticks(range(len(objids)), labs); ax.set_yticks(range(len(objids)), labs)
        ax.tick_params(length=0); ax.set_xlabel('Paph17/'); ax.set_ylabel('Paph17/')
        ax.set_title('Sicilian NAA distances' if j == 0 else 'CYP-B NAA distances', pad=11)
        for i, s in enumerate(objids):
            for k, t in enumerate(objids):
                pairvalues.append({'sample_a': s, 'sample_b': t, 'distance': float(dist[i, k])})
    cax = fig.add_axes([.925, .19, .014, .67]); cb = fig.colorbar(im, cax=cax)
    cb.set_label('Euclidean distance', fontsize=7); cb.ax.tick_params(labelsize=6.5)
    save_figure(fig, 'Figure_S4_continued', list(axes), output)
    (output/'distance_check.json').write_text(json.dumps({'elements': 29, 'common_vmax': float(vmax),
          'transform': 'Natural log ratios to Lu; exclude As,Ni,Zr; no feature standardization or dimension reduction',
          'pairvalues': pairvalues}, indent=2), encoding='utf8')
    print('PASS: 60 completion values; unchanged curves and 29-element NAA distances; aligned five-panel figure')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent/'figures')
    args = parser.parse_args()
    main(args.output)
