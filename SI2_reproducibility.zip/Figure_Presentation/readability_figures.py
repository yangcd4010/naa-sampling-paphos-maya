"""Presentation-only redraw. Reads archived summaries; never fits or scores paths."""
from pathlib import Path
import argparse, json, sys
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from matplotlib.patches import FancyBboxPatch
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'Revision_Analysis_v5/tools'))
from audit_panel_alignment import require_matplotlib_panel_alignment
R = ROOT/'Revision_Analysis_v5/results'
TARGETS = ['Paphian_AMG48_vs_AMG21B','Kourion_five_patterns','IMPA_Koan_Thassian_subdivision','CYPB_Paphian_Kourion_separation','Sicily_cross_cluster_correction','Aegean_six_unlocated_patterns']
SHORT = ['Paphian','Five\nKourion','Koan–\nThassian','CYP-B','Sicilian','Six\nAegean']
RULES = ['Random','Proportional','PQMM','Max-min','Frozen MU','Updated MU','Frozen DWU','Updated DWU','Cross-stratified','APDC']
NAMES = {'Random':'Exact random expectation','Proportional':'Cluster quotas: central members','PQMM':'Cluster quotas: spread members','Max-min':'Global spread (max-min)','Frozen MU':'Model uncertainty (initial model)','Updated MU':'Model uncertainty (updated model)','Frozen DWU':'Density-weighted uncertainty (initial model)','Updated DWU':'Density-weighted uncertainty (updated model)','Cross-stratified':'Fabric–cluster coverage','APDC':'Fabric–cluster mismatch first'}
WRAP = {r:NAMES[r] for r in RULES}
for r in ['Frozen MU','Updated MU','Frozen DWU','Updated DWU']:
    WRAP[r] = NAMES[r].replace(' (','\n(')
for r in ['Proportional','PQMM']:
    WRAP[r] = NAMES[r].replace(': ',':\n')
COLORS = {'Random':'#555555','Proportional':'#888888','PQMM':'#397B60','Max-min':'#326AA5','Updated MU':'#BB703B','Updated DWU':'#985475','Frozen MU':'#C99F7D','Frozen DWU':'#BFA0B8','APDC':'#BB703B','Cross-stratified':'#326AA5'}
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':7,'axes.labelsize':7,'axes.titlesize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'pdf.fonttype':42,'svg.fonttype':'none','axes.linewidth':.6,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':600})

def label(ax, s):
    ax.set_label(s)
    ax.annotate(s, (0,1), xycoords='axes fraction', xytext=(-17,8), textcoords='offset points', weight='bold', fontsize=9, va='bottom')

def pct(v):
    if v == 0: return '0.0'
    if v == 1: return '100.0'
    s = f'{v*100:.1f}'
    return '<0.1' if s=='0.0' else '>99.9' if s=='100.0' else s

def save(fig, name, axes, out, exemptions=()):
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig, axes=axes, json_out=out/(name+'.alignment.json'), overlay_svg=out/(name+'.alignment.svg'), tolerance_pt=1.5, gutter_tolerance_pt=1.5, strict=True, exemptions=exemptions)
    fig.savefig(out/(name+'.pdf'))
    fig.savefig(out/(name+'.svg'))
    fig.savefig(out/(name+'.png'), dpi=300)
    fig.savefig(out/(name+'.tif'), dpi=600, pil_kwargs={'compression':'tiff_lzw'})
    plt.close(fig)

def figure1(out):
    snapshot = pd.read_csv(ROOT/'Targeted_Analyses/results/fixed_budget_evidence_snapshot.csv')
    s = snapshot.query('k==2 and total_budget==55').loc[lambda x:x.rule!='Archived random']
    assert len(s)==60 and not s.duplicated(['target','rule']).any()
    values = s.pivot(index='rule',columns='target',values='completion_fraction').loc[RULES,TARGETS]
    assert np.isfinite(values.to_numpy()).all() and ((values>=0)&(values<=1)).all().all()
    curves = pd.read_csv(R/'Paphos_random_order_curves_v5.csv')
    refs = pd.read_csv(ROOT/'Revision_Analysis_v5/inputs/paphos_reference_labels.csv',keep_default_na=False).set_index('naa_id')
    meta = pd.read_csv(ROOT/'Analysis/inputs/paphos/pre_naa_metadata.csv',keep_default_na=False).set_index('fragment_id')
    fig = plt.figure(figsize=(7.086614173,9.251968504))
    gs = fig.add_gridspec(3,2, height_ratios=[1,1.3,1],left=.10,right=.94,bottom=.14,top=.94,wspace=.25,hspace=.53)
    axes = [fig.add_subplot(gs[0,0]),fig.add_subplot(gs[0,1]),fig.add_subplot(gs[1,:]),fig.add_subplot(gs[2,0]),fig.add_subplot(gs[2,1])]
    # Leave room for descriptive rule names while retaining a full-width hero row.
    pos = axes[2].get_position(); axes[2].set_position([.39,pos.y0,.53,pos.height])
    a,b,c,d,e = axes
    for ax,l,t in [(a,'a','One NAA pattern across screening clusters'),(b,'b','Different NAA patterns within CYP-B')]:
        ax.set_xlim(0,1); ax.set_ylim(0,1); ax.set_axis_off(); label(ax,l);ax.set_title(t, fontsize=7.5, pad=14)
    a.text(.5,.97,'SICILY pattern · fabric AMG 10',ha='center',va='top',color='#397B60',fontsize=7)
    clusters=[('IMP-G',['84','86'],.025,.48),('IMP-G2',['87'],.53,.48),('IMP-D',['85'],.025,.18),('IMP-J',['88'],.53,.18)]
    object_check=[]
    for cluster,ids,x,y in clusters:
        a.add_patch(FancyBboxPatch((x,y),.43,.24,boxstyle='round,pad=0.01',edgecolor='#60676B',facecolor='#F4F7F9',lw=.7))
        a.text(x+.225,y+.21,cluster,ha='center',va='top',weight='bold',fontsize=7)
        for z,suffix in enumerate(ids):
            sid='Paph17/'+suffix; row=refs.loc[sid]
            assert row.published_2021_group=='SICILY' and row.published_2021_pxrf_cluster==cluster
            a.text(x+.225,y+.12-z*.085,sid,ha='center',va='center',fontsize=7,color='#397B60')
            object_check.append({'object':sid,'screening':cluster,'pattern':'SICILY','eligible':True})
    a.text(.5,-.02,'Need 2 of 3 in IMP-G/G2\n+ both in IMP-D/J',ha='center',va='top',fontsize=7)
    b.add_patch(FancyBboxPatch((.01,.16),.97,.68,boxstyle='round,pad=0.012',facecolor='#F4F7F9',edgecolor='#60676B',lw=.7))
    b.text(.50,.94,'CYP-B · object ID / fabric AMG',ha='center',va='top',weight='bold',fontsize=7)
    cards=[('33','PAPH-C'),('35','PAPH-C'),('08','KOUR-B'),('14','KOUR-B'),('16','KOUR-B'),('92','KOUR-B'),('01','loner'),('32','KOUR-C')]
    for i,(suffix,pattern) in enumerate(cards):
        sid='Paph17/'+suffix; row=refs.loc[sid]; actual=row.published_2021_group or 'loner'; eligible=pattern in ['PAPH-C','KOUR-B']
        assert actual==pattern and row.published_2021_pxrf_cluster=='CYP-B'
        # Obtain AMG by the crosswalk's sample_id, never infer fabric from NAA.
        raw = pd.read_csv(ROOT/'Revision_Analysis_v5/inputs/paphos_reference_labels.csv',keep_default_na=False)
        sample = raw.loc[raw.naa_id==sid,'sample_id'].iloc[0]
        amg = meta.loc[sample,'amg_key'] or '—'
        x=.055+(i%2)*.47;y=.78-(i//2)*.15
        color = '#BB703B' if pattern=='PAPH-C' else '#326AA5' if pattern=='KOUR-B' else '#777777'
        b.text(x,y,f'{sid} · {amg}',fontsize=7,va='top',color=color)
        b.text(x,y-.062,pattern+(' †' if not eligible else ''),fontsize=7,va='top',color=color,weight='bold')
        object_check.append({'object':sid,'screening':'CYP-B','pattern':pattern,'AMG':amg,'eligible':eligible})
    b.text(.5,-.02,'Need both PAPH-C\n+ 2 of 4 KOUR-B',ha='center',va='top',fontsize=7)
    label(c,'c'); c.set_title('Comparisons completed at 55 NAA specimens (%)',pad=26,fontsize=8)
    im=c.pcolormesh(np.arange(7)-.5,np.arange(11)-.5,values.to_numpy()*100,cmap='Blues',vmin=0,vmax=100,shading='flat',edgecolors='white',linewidth=.6)
    c.set_xlim(-.5,5.5);c.set_ylim(9.5,-.5);c.set_xticks(range(6),SHORT);c.set_yticks(range(10),['Random sampling\n(exact reference)' if r=='Random' else WRAP[r] for r in RULES]);c.tick_params(length=0,pad=4)
    for i in range(10):
        for j in range(6):
            v=values.iloc[i,j];c.text(j,i,pct(v),ha='center',va='center',fontsize=7,color='white' if v>=.64 else '#172532')
    cbax=fig.add_axes([.937,c.get_position().y0,.011,c.get_position().height]);cb=fig.colorbar(im,cax=cbax,ticks=[0,50,100]);cb.ax.tick_params(labelsize=7,length=2)
    for ax,l,t in [(d,'d',TARGETS[4]),(e,'e',TARGETS[3])]:
        label(ax,l);ax.set_title('Sicilian' if t==TARGETS[4] else 'CYP-B',pad=12)
        for rule in ['Random','PQMM','Updated DWU','APDC','Cross-stratified']:
            v=curves[(curves.target==t)&(curves.rule==rule)].sort_values('budget')
            assert len(v)==83 and abs(v.loc[v.budget==55,'mean'].iloc[0]-values.loc[rule,t])<1e-10
            ax.plot(v.budget,v['mean'],color=COLORS[rule],lw=1.2,ls='--' if rule=='Random' else '-',label=NAMES[rule])
            ax.fill_between(v.budget,v.low,v.high,color=COLORS[rule],alpha=.09,lw=0)
        ax.axvline(55,color='#666666',ls=':',lw=.8);ax.set_xlim(15,97);ax.set_ylim(-.025,1.025);ax.set_xticks([15,35,55,75,97]);ax.set_yticks([0,.5,1]);ax.set_xlabel('Cumulative NAA specimens');ax.set_ylabel('Completion fraction');ax.grid(axis='y',alpha=.12)
    h,n = d.get_legend_handles_labels();n=[x.replace('Exact random expectation','Exact random reference') for x in n]
    fig.legend(h,n,loc='lower center',bbox_to_anchor=(.52,.015),ncol=2,frameon=False,fontsize=7,columnspacing=1)
    save(fig,'Fig1',axes,out,exemptions=[{'panels':['c'],'checks':['vertical-gutter','column','panel-label'],'reason':'The full-width heatmap separates the member-schematic row and the curve row; its independent left column accommodates descriptive rule names. Paired panels retain equal dimensions and aligned edges.'}])
    (out/'Fig1_display_check.json').write_text(json.dumps({'objects':object_check,'values':[{'rule':r,'target':t,'value':float(values.loc[r,t]),'label':pct(values.loc[r,t])} for r in RULES for t in TARGETS]},indent=2),encoding='utf8')

def figure2(out):
    d=pd.read_csv(R/'rule_minus_exact_random.csv').query("case=='Paphos' and excluded=='none' and k==2")
    p=pd.read_csv(R/'paired_rule_comparisons.csv').query("case=='Paphos' and excluded=='none' and k==2")
    means=pd.read_csv(R/'primary_budget_summary.csv').query("case=='Paphos' and excluded=='none' and k==2 and rule=='Random'").set_index('target')
    rr=['Proportional','PQMM','Max-min','Updated MU','Updated DWU','Cross-stratified','APDC'];pr=[('Updated MU','Frozen MU'),('Updated DWU','Frozen DWU')]
    a=d.pivot(index='rule',columns='target',values='mean_delta').loc[rr,TARGETS].to_numpy(); b=np.stack([p[(p.rule_A==r)&(p.rule_B==s)].set_index('target').loc[TARGETS].mean_delta.to_numpy() for r,s in pr]);lim=np.ceil(max(abs(a).max(),abs(b).max())/5)*5
    fig,axs=plt.subplots(2,1,figsize=(7.086614173,8.267716535),gridspec_kw={'height_ratios':[7,2]});fig.subplots_adjust(left=.37,right=.96,bottom=.19,top=.88,hspace=.55)
    for ax,l,mat,rows in [(axs[0],'a',a,rr),(axs[1],'b',b,['Model uncertainty','Density-weighted uncertainty'])]:
        label(ax,l);im=ax.imshow(mat,aspect='auto',cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-lim,vcenter=0,vmax=lim));ax.set_xticks(range(6),[s+(' †' if i in [2,5] else '') for i,s in enumerate(SHORT)]);ax.set_yticks(range(len(rows)),[WRAP[r] for r in rows] if l=='a' else ['Model\nuncertainty','Density-weighted\nuncertainty']);ax.tick_params(length=0,pad=4)
        for y in range(len(rows)):
            for x,t in enumerate(TARGETS):
                row=d[(d.rule==rr[y])&(d.target==t)].iloc[0] if l=='a' else p[(p.rule_A==pr[y][0])&(p.rule_B==pr[y][1])&(p.target==t)].iloc[0]
                color='white' if abs(mat[y,x])>lim*.6 else '#142235'
                ax.text(x,y-.15,f'{row.mean_delta:+.2f}',ha='center',va='center',fontsize=7,color=color);ax.text(x,y+.21,f'[{row.CI_low:.1f}, {row.CI_high:.1f}]',ha='center',va='center',fontsize=7,color=color)
        for spine in ax.spines.values():spine.set_visible(False)
    axs[0].set_title('Rule − exact random expectation',pad=34)
    for j,t in enumerate(TARGETS):axs[0].text(j,1.017,f'Random\n{means.loc[t,"mean_budget"]:.1f}',transform=axs[0].get_xaxis_transform(),ha='center',va='bottom',fontsize=7)
    axs[1].set_title('Updated model − initial model',pad=16)
    cbax=fig.add_axes([.37,.074,.59,.018]);cb=fig.colorbar(im,cax=cbax,orientation='horizontal');cb.set_label('Additional / fewer NAA specimens; negative = earlier',fontsize=7);cb.ax.tick_params(labelsize=7)
    save(fig,'Fig2',list(axs),out)

def figure3(out):
    d=pd.read_csv(R/'primary_budget_summary.csv').query("case=='Maya' and excluded=='none'"); c=pd.read_csv(R/'rule_minus_exact_random.csv').query("case=='Maya' and excluded=='none' and rule=='Max-min'");p=pd.read_csv(R/'paired_rule_comparisons.csv').query("case=='Maya' and excluded=='none'")
    rules=['Random','Proportional','PQMM','Max-min','Updated MU','Updated DWU','Frozen MU','Frozen DWU']
    fig,axs=plt.subplots(2,2,figsize=(7.086614173,8.661417323));fig.subplots_adjust(left=.13,right=.96,bottom=.24,top=.94,wspace=.36,hspace=.48)
    for j,t in enumerate(['main','terminal']):
        ax=axs[0,j];label(ax,'ab'[j]);ax.set_title('Four broad groups' if j==0 else 'Twelve finer categories',pad=12)
        for r in rules:
            v=d[(d.target==t)&d.k.isin([2,3,5])&(d.rule==r)].sort_values('k');x=np.arange(3)+(rules.index(r)-3.5)*.018
            ax.errorbar(x,v.mean_budget,yerr=[v.mean_budget-v.CI_low,v.CI_high-v.mean_budget],fmt='o--' if r=='Random' else 'o-',color=COLORS[r],ms=2.7,lw=1,capsize=1.7,label=NAMES[r])
        ax.set_xticks(range(3),['2','3','5']);ax.set_xlabel('Members required per set');ax.set_ylabel('Mean cumulative NAA specimens');ax.grid(axis='y',alpha=.14)
    ax=axs[1,0];label(ax,'c');ax.set_title('Global spread − exact random',pad=12);ax.axhline(0,color='#999999',lw=.7)
    for j,t in enumerate(['main','terminal']):
        v=c[(c.target==t)&c.k.isin([2,3,5])].sort_values('k');x=np.arange(3)+(j-.5)*.05
        ax.errorbar(x,v.mean_delta,yerr=[v.mean_delta-v.CI_low,v.CI_high-v.mean_delta],fmt='o-' if j==0 else 's-',color=['#326AA5','#397B60'][j],ms=3,capsize=2,label=['Four broad groups','Twelve finer categories'][j])
    ax.set_xticks(range(3),['2','3','5']);ax.set_xlabel('Members required per set');ax.set_ylabel('Additional / fewer NAA specimens');ax.legend(loc='lower left',fontsize=7);ax.grid(axis='y',alpha=.14)
    ax=axs[1,1];label(ax,'d');ax.set_title('Updated − initial model',pad=12);ax.axhline(0,color='#999999',lw=.7)
    for j,(r,t) in enumerate([('Updated MU','main'),('Updated MU','terminal'),('Updated DWU','main'),('Updated DWU','terminal')]):
        v=p[(p.rule_A==r)&(p.target==t)&p.k.isin([2,3,5])].sort_values('k');x=np.arange(3)+(j-1.5)*.035
        ax.errorbar(x,v.mean_delta,yerr=[v.mean_delta-v.CI_low,v.CI_high-v.mean_delta],fmt='o-' if t=='main' else 's--',color=COLORS[r],ms=3,capsize=2)
    ax.set_xticks(range(3),['2','3','5']);ax.set_xlabel('Members required per set');ax.set_ylabel('Additional / fewer NAA specimens');ax.grid(axis='y',alpha=.14)
    fig.text(.57,.172,'Orange: model uncertainty\nPurple: density-weighted uncertainty\n● broad groups  /  ■ finer categories',fontsize=7,va='top')
    h,n=axs[0,0].get_legend_handles_labels();fig.legend(h,n,loc='lower center',bbox_to_anchor=(.54,.018),ncol=2,frameon=False,fontsize=7,columnspacing=1)
    save(fig,'Fig3',list(axs.ravel()),out)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    (args.output/'figure_contract.json').write_text(json.dumps({'backend':'Python matplotlib','width_mm':180,'font_floor_pt':7,'claim':'Equal budgets yield different comparison members; advantages change with target system.','figure_order':['actual reference relations and equal-budget completion','Paphos paired budget contrasts','Maya target-system contrasts'],'sources':'existing archived CSVs and object maps','scientific_changes':False,'schematic_geometry':'layout only, not chemical distance','uncertainty':'original pointwise intervals unchanged'},indent=2),encoding='utf8')
    (Path(__file__).parent/'readability_names.json').write_text(json.dumps(NAMES,ensure_ascii=False,indent=2),encoding='utf8')
    figure1(args.output);figure2(args.output);figure3(args.output)
    print('PASS: three presentation-only figures; 60 heatmap values and 13 object relationships verified')
