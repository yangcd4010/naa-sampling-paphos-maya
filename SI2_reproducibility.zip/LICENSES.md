# Licensing and source attribution

## Scope

Author-created data, derived numerical results and general documentation in this package are licensed under Creative Commons Attribution 4.0 International (CC BY 4.0), https://creativecommons.org/licenses/by/4.0/ (legal code: https://creativecommons.org/licenses/by/4.0/legalcode). This includes the author-created content in PRIMARY_RESULTS_k2.csv, archived acquisition paths, computed summaries and analysis outputs. Reusers must give appropriate credit, link to the licence and indicate changes. Commercial reuse is permitted under the licence.

Author-created software code, including Python analysis and reproduction scripts and their associated software documentation, is licensed under the MIT License reproduced below. General data descriptions and result documentation remain under CC BY 4.0. These grants extend only to rights held by the package contributors, not to third-party data, software dependencies, or third-party material embedded in derived files.

## Third-party sources

Paphos source measurements: Hein, A., Dobosz, A., and Kilikoglou, V. (2021), Mendeley Data, version 1, https://doi.org/10.17632/ydgs3z4g76.1, Creative Commons Attribution 4.0. Assignment source: https://doi.org/10.1016/j.jas.2021.105436. Retain the original source attribution when reusing measurements or derived files containing them.

Maya source: LeMoine, J.-B., and Halperin, C. T. (2021), https://doi.org/10.1016/j.jasrep.2021.102819. The original provider workbook and full raw or standardized concentration matrices are excluded; obtain the provider supplement under its terms. The adapter and source identifiers are supplied. The licences granted here do not authorize redistribution of excluded source materials or override rights in third-party content.

Third-party notices and software dependency licences retain their scope. This package does not license the manuscript text or unrelated project files.

## Author-created software

MIT License

Copyright (c) 2026 NAA sampling package contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
