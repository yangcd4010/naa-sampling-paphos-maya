# Source attribution and rights

Paphos source measurements: Hein, A., Dobosz, A., and Kilikoglou, V. (2021), Mendeley Data, version 1, https://doi.org/10.17632/ydgs3z4g76.1, Creative Commons Attribution 4.0. Assignment source: https://doi.org/10.1016/j.jas.2021.105436.

Maya source: LeMoine, J.-B., and Halperin, C. T. (2021), https://doi.org/10.1016/j.jasrep.2021.102819. The original provider workbook and full raw or standardized concentration matrices are excluded; obtain the provider supplement under its terms. The adapter and source identifiers are supplied.

Third-party notices retain their scope. This file grants no additional licence over third-party material and does not assign a reuse licence to author-created code or derived data.
