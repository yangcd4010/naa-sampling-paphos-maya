"""Draw Figure 1 with high-budget target markers from the supplied numerical inputs."""
"""Python figure exports from finite analyses and frozen source summaries."""
from pathlib import Path
import sys,json,shutil,importlib.util

sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'Revision_Analysis_v5/tools'))
import numpy as np,pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from audit_panel_alignment import require_matplotlib_panel_alignment
ROOT=Path(__file__).resolve().parent;R=ROOT.parent/'Revision_Analysis_v5/results';I=ROOT.parent/'Revision_Analysis_v5/inputs';F=ROOT/'figures';F.mkdir(exist_ok=True)
TARGETS=['Paphian_AMG48_vs_AMG21B','Kourion_five_patterns','IMPA_Koan_Thassian_subdivision','CYPB_Paphian_Kourion_separation','Sicily_cross_cluster_correction','Aegean_six_unlocated_patterns']
SHORT=['Paphian','Five\nKourion','Koan–\nThassian †','CYP-B','Sicilian','Six\nAegean †']
RULES=['Random','Proportional','PQMM','Max-min','Updated MU','Updated DWU','Frozen MU','Frozen DWU']
colors={'Random':'#555555','Proportional':'#999999','PQMM':'#397B60','Max-min':'#326AA5','Updated MU':'#BB703B','Updated DWU':'#985475','Frozen MU':'#C99F7D','Frozen DWU':'#BFA0B8'}
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':7,'axes.titlesize':8,'axes.labelsize':7,'xtick.labelsize':6.5,'ytick.labelsize':6.5,'legend.fontsize':6.5,'pdf.fonttype':42,'svg.fonttype':'none','axes.linewidth':.65,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':600})
def rd(n,**kw):return pd.read_csv(R/n,**kw)
def label(ax,c):ax.set_label(c);ax.annotate(c,xy=(0,1),xycoords='axes fraction',xytext=(-16,8),textcoords='offset points',weight='bold',fontsize=9,va='bottom')
def contract(n,claim,panels,uncertainty,**extra):
    d={'claim':claim,'backend':'Python matplotlib','archetype':'multipanel evidence','panels':panels,'final_width_mm':180.1,'font_floor_pt':5.4,'uncertainty':uncertainty,'sources':'Revision_Presentation_v6/inputs (unchanged v5 summaries)','no_classifier_or_causal_claim':True};d.update(extra);(F/(n+'.contract.json')).write_text(json.dumps(d,indent=2),encoding='utf8')
def export(fig,n,axes=None,**options):
    fig.canvas.draw();require_matplotlib_panel_alignment(fig,axes=axes,json_out=F/(n+'.alignment.json'),overlay_svg=F/(n+'.alignment.svg'),tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True,**options)
    fig.savefig(F/(n+'.pdf'));fig.savefig(F/(n+'.svg'));fig.savefig(F/(n+'.png'),dpi=300);fig.savefig(F/(n+'.tif'),dpi=600,pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
def fig1():
    contract('Fig1','Acquisition advantage depends on the Paphos target, and updating is a separate contrast',['seven nonrandom rules minus exact random','two updated-minus-frozen contrasts'],'pointwise paired 95% 10000-start bootstrap; material rules jointly resample20orders')
    d=rd('rule_minus_exact_random.csv').query("case=='Paphos' and excluded=='none' and k==2");p=rd('paired_rule_comparisons.csv').query("case=='Paphos' and excluded=='none' and k==2");means=rd('primary_budget_summary.csv').query("case=='Paphos' and excluded=='none' and k==2 and rule=='Random'")
    rr=['Proportional','PQMM','Max-min','Updated MU','Updated DWU','Cross-stratified','APDC'];pr=[('Updated MU','Frozen MU'),('Updated DWU','Frozen DWU')]
    a=d.pivot(index='rule',columns='target',values='mean_delta').loc[rr,TARGETS].to_numpy();b=np.stack([p[(p.rule_A==r)&(p.rule_B==s)].set_index('target').loc[TARGETS].mean_delta.to_numpy() for r,s in pr]);limit=np.ceil(max(np.abs(a).max(),np.abs(b).max())/5)*5
    fig,axs=plt.subplots(2,1,figsize=(7.09,5.9),gridspec_kw={'height_ratios':[7,2]});fig.subplots_adjust(left=.22,right=.94,bottom=.19,top=.87,hspace=.49)
    for ax,c,mat,rows in [(axs[0],'a',a,rr),(axs[1],'b',b,['Updated MU − frozen','Updated DWU − frozen'])]:
        im=ax.imshow(mat,aspect='auto',cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-limit,vcenter=0,vmax=limit));label(ax,c);ax.set_xticks(range(6),SHORT);ax.set_yticks(range(len(rows)),[('proportional-medoid' if r=='Proportional' else r) for r in rows]);ax.tick_params(length=0,pad=5)
        for y in range(len(rows)):
            for x,t in enumerate(TARGETS):
                row=(d[(d.rule==rr[y])&(d.target==t)].iloc[0] if c=='a' else p[(p.rule_A==pr[y][0])&(p.rule_B==pr[y][1])&(p.target==t)].iloc[0]);color='white' if abs(mat[y,x])>limit*.6 else '#142235'
                ax.text(x,y-.12,f'{row.mean_delta:+.2f}',ha='center',va='center',fontsize=7,color=color);ax.text(x,y+.23,f'[{row.CI_low:.1f}, {row.CI_high:.1f}]',ha='center',va='center',fontsize=5.5,color=color)
        for s in ax.spines.values():s.set_visible(False)
    random=means.set_index('target').loc[TARGETS].mean_budget.to_numpy()
    axs[0].set_title('Rule − exact conditional random expectation',pad=33)
    for j,value in enumerate(random):axs[0].text(j,1.018,f'Random {value:.2f}',transform=axs[0].get_xaxis_transform(),ha='center',va='bottom',fontsize=6)
    axs[1].set_title('Updated − frozen workflow',pad=12)
    cax=fig.add_axes([.28,.074,.60,.021]);cb=fig.colorbar(im,cax=cax,orientation='horizontal');cb.set_label('Budget difference in fragments; negative = earlier',fontsize=7);cb.ax.tick_params(labelsize=6)
    export(fig,'Fig1',axes=list(axs))
    d.to_csv(F/'Fig1_random_contrasts.csv',index=False);p.to_csv(F/'Fig1_update_contrasts.csv',index=False)
if __name__=="__main__":fig1()
