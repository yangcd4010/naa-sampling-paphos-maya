"""Python figure exports from finite analyses and frozen source summaries."""
from pathlib import Path
import sys,json,shutil,importlib.util

sys.path.insert(0,str(Path(__file__).resolve().parent/'tools'))
import numpy as np,pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from audit_panel_alignment import require_matplotlib_panel_alignment
ROOT=Path(__file__).resolve().parent;R=ROOT/'results';I=ROOT/'inputs';F=ROOT/'figures';F.mkdir(exist_ok=True)
TARGETS=['Paphian_AMG48_vs_AMG21B','Kourion_five_patterns','IMPA_Koan_Thassian_subdivision','CYPB_Paphian_Kourion_separation','Sicily_cross_cluster_correction','Aegean_six_unlocated_patterns']
SHORT=['Paphian','Five\nKourion','Koan–\nThassian','CYP-B','Sicilian','Six\nAegean']
RULES=['Random','Proportional','PQMM','Max-min','Updated MU','Updated DWU','Frozen MU','Frozen DWU']
colors={'Random':'#555555','Proportional':'#999999','PQMM':'#397B60','Max-min':'#326AA5','Updated MU':'#BB703B','Updated DWU':'#985475','Frozen MU':'#C99F7D','Frozen DWU':'#BFA0B8'}
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':7,'axes.titlesize':8,'axes.labelsize':7,'xtick.labelsize':6.5,'ytick.labelsize':6.5,'legend.fontsize':6.5,'pdf.fonttype':42,'svg.fonttype':'none','axes.linewidth':.65,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':600})
def rd(n,**kw):return pd.read_csv(R/n,**kw)
def label(ax,c):ax.set_label(c);ax.annotate(c,xy=(0,1),xycoords='axes fraction',xytext=(-16,8),textcoords='offset points',weight='bold',fontsize=9,va='bottom')
def contract(n,claim,panels,uncertainty,**extra):
    d={'claim':claim,'backend':'Python matplotlib','archetype':'multipanel evidence','panels':panels,'final_width_mm':180.1,'font_floor_pt':5.4,'uncertainty':uncertainty,'sources':'Revision_Analysis_v5/results','no_classifier_or_causal_claim':True};d.update(extra);(F/(n+'.contract.json')).write_text(json.dumps(d,indent=2),encoding='utf8')
def export(fig,n,axes=None,**options):
    fig.canvas.draw();require_matplotlib_panel_alignment(fig,axes=axes,json_out=F/(n+'.alignment.json'),overlay_svg=F/(n+'.alignment.svg'),tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True,**options)
    fig.savefig(F/(n+'.pdf'));fig.savefig(F/(n+'.svg'));fig.savefig(F/(n+'.png'),dpi=300);fig.savefig(F/(n+'.tif'),dpi=600,pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
def fig2():
    contract('Fig2','Fabric allocation supports a cross-cluster link and an internal subdivision differently',['source metadata','NAA distances','conditional target completion'],'pointwise bootstrap bands; exact-random curves integrate continuation then resample archived starts')
    source=rd('Paphos_random_order_curves.csv')
    # Preserve all nonrandom curves; replace only random curves by mean exact CDF.
    exact=pd.read_csv(R/'conditional_random_cdf_by_start.csv.gz');b=np.load(I/'bootstrap_indices.npz')['initial_sets'];rows=[]
    for t in TARGETS:
        g=exact[(exact.case=='Paphos')&(exact.target==t)&(exact.excluded=='none')&(exact.k==2)];a=g.pivot(index='seed',columns='budget',values='completion_probability').sort_index();boot=a.to_numpy()[b].mean(axis=1);lo,hi=np.quantile(boot,[.025,.975],axis=0)
        rows.extend(dict(target=t,rule='Random',budget=budget,mean=a[budget].mean(),low=l,high=h) for budget,l,h in zip(a.columns,lo,hi))
    source=pd.concat([source[source.rule!='Random'],pd.DataFrame(rows)],ignore_index=True);source.to_csv(R/'Paphos_random_order_curves_v5.csv',index=False)
    spec=importlib.util.spec_from_file_location('legacy',ROOT/'legacy_figure2.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    orig=m.read
    def reader(p):return orig(R/'Paphos_random_order_curves_v5.csv') if p.name=='Paphos_random_order_curves.csv' else orig(p)
    m.read=reader;m.fig2()
    for suffix in ['pdf','svg','png','tiff']:
        src=F/f'Figure2.{suffix}';dst=F/f'Fig2.{"tif" if suffix=="tiff" else suffix}';src.replace(dst)
    (F/'Figure2.alignment.json').replace(F/'Fig2.alignment.json')
def fig3():
    contract('Fig3','Max-min advantage over exact random reverses with the Maya target resolution',['broad mean budgets','terminal mean budgets','max-min minus exact random','updated minus frozen'],'pointwise paired 95%10000 start-bootstrap intervals')
    d=rd('primary_budget_summary.csv').query("case=='Maya' and excluded=='none'");c=rd('rule_minus_exact_random.csv').query("case=='Maya' and excluded=='none' and rule=='Max-min'");p=rd('paired_rule_comparisons.csv').query("case=='Maya' and excluded=='none'")
    fig,axs=plt.subplots(2,2,figsize=(7.09,6.15));fig.subplots_adjust(left=.12,right=.97,bottom=.16,top=.94,wspace=.35,hspace=.47)
    for j,t in enumerate(['main','terminal']):
        ax=axs[0,j];label(ax,'ab'[j]);ax.set_title('Four broad groups' if j==0 else 'Twelve terminal categories',pad=11)
        for r in RULES:
            a=d[(d.target==t)&d.k.isin([2,3,5])&(d.rule==r)].sort_values('k');shift=(RULES.index(r)-3.5)*.018;x=np.arange(3)+shift
            ax.errorbar(x,a.mean_budget,yerr=np.array([a.mean_budget-a.CI_low,a.CI_high-a.mean_budget]),fmt='o--' if r=='Random' else 'o-',color=colors[r],markersize=2.7,lw=1,capsize=1.7,label='Exact random' if r=='Random' else ('proportional-medoid' if r=='Proportional' else r))
        ax.set_xticks(range(3),['2','3','5']);ax.set_xlabel('Members required per set');ax.set_ylabel('Mean NAA budget');ax.grid(axis='y',alpha=.14)
    ax=axs[1,0];label(ax,'c');ax.set_title('Max-min − exact random',pad=11);ax.axhline(0,color='#999999',lw=.7)
    for j,t in enumerate(['main','terminal']):
        a=c[(c.target==t)&c.k.isin([2,3,5])].sort_values('k');x=np.arange(3)+(j-.5)*.05;ax.errorbar(x,a.mean_delta,yerr=np.array([a.mean_delta-a.CI_low,a.CI_high-a.mean_delta]),fmt='o-' if j==0 else 's-',color=['#326AA5','#397B60'][j],markersize=3,capsize=2,label=['Four groups','Twelve categories'][j])
    ax.set_xticks(range(3),['2','3','5']);ax.set_xlabel('Members required per set');ax.set_ylabel('Paired budget difference');ax.legend(fontsize=6,loc='lower left');ax.grid(axis='y',alpha=.14)
    ax=axs[1,1];label(ax,'d');ax.set_title('Updated − frozen workflow',pad=11);ax.axhline(0,color='#999999',lw=.7)
    for j,(r,t) in enumerate([('Updated MU','main'),('Updated MU','terminal'),('Updated DWU','main'),('Updated DWU','terminal')]):
        a=p[(p.rule_A==r)&(p.target==t)&p.k.isin([2,3,5])].sort_values('k');x=np.arange(3)+(j-1.5)*.035;ax.errorbar(x,a.mean_delta,yerr=np.array([a.mean_delta-a.CI_low,a.CI_high-a.mean_delta]),fmt='o-' if t=='main' else 's--',color=colors[r],markersize=3,capsize=2,label=f'{r.split()[-1]} / {"four" if t=="main" else "twelve"}')
    ax.set_xticks(range(3),['2','3','5']);ax.set_xlabel('Members required per set');ax.set_ylabel('Paired budget difference');ax.grid(axis='y',alpha=.14)
    h,l=axs[0,0].get_legend_handles_labels();fig.legend(h,l,loc='lower center',bbox_to_anchor=(.53,.015),ncol=3,frameon=False)
    d.to_csv(F/'Figure3_primary_means.csv',index=False)
    c.to_csv(F/'Figure3_exact_random_contrasts.csv',index=False)
    p.to_csv(F/'Figure3_updated_frozen_contrasts.csv',index=False)
    export(fig,'Fig3',axes=list(axs.ravel()))
def s3():
    contract('Figure_S3','Features and complete-space neighbours describe the Maya categories associated with acquisition delays',['all11 feature distributions','unlabelled PCA all12categories','5NN composition and category-size baseline'],'descriptive fixed-pool distributions; no sampling CI required; inferential acquisition scores remainS51',distribution_whiskers='5th and95th percentiles')
    d=rd('maya_all_feature_distributions.csv');pc=rd('maya_pca_scores.csv',dtype={'terminal_category':str});mix=rd('maya_neighbour_mixing.csv',dtype={'focal_category':str,'neighbour_category':str});val=json.loads((R/'maya_feature_neighbour_validation.json').read_text());features=d.feature.drop_duplicates().tolist();cats=['1','2-1','2-2','2-3','3-1','3-2','3-3','3-4','3-5','3-6','3-7','4']
    fig=plt.figure(figsize=(7.09,6.65));gs=fig.add_gridspec(2,2,height_ratios=[.9,1.25]);ax=fig.add_subplot(gs[0,:]);a2=fig.add_subplot(gs[1,0]);a3=fig.add_subplot(gs[1,1]);fig.subplots_adjust(left=.10,right=.90,bottom=.13,top=.92,wspace=.37,hspace=.56)
    for shift,group,color in [(-.17,'Group 4','#326AA5'),(.17,'Other objects','#999999')]:
        a=d[d.group==group].set_index('feature').loc[features];stats=[dict(med=r['median'],q1=r.q25,q3=r.q75,whislo=r.q05,whishi=r.q95) for _,r in a.iterrows()];bb=ax.bxp(stats,positions=np.arange(11)+shift,widths=.27,showfliers=False,patch_artist=True,manage_ticks=False)
        for box in bb['boxes']:box.set_facecolor(color);box.set_alpha(.62)
        for med in bb['medians']:med.set_color('#111111')
    label(ax,'a');ax.set_xticks(range(11),features);ax.set_ylabel('Standardized log ratio to Fe');ax.set_title('All pXRF features: Group 4 (13) and other objects (170)',pad=13);ax.axhline(0,color='#bbbbbb',lw=.5,zorder=-1);ax.plot([],[],color='#326AA5',lw=6,label='Group 4');ax.plot([],[],color='#999999',lw=6,label='Others');ax.legend(loc='upper right',ncol=2,frameon=False)
    pal=['#326AA5','#B36A31','#DB9D54','#905122','#9075B3','#B3A1CE','#625183','#AA7F99','#7A6578','#665D78','#A69CAB','#397B60'];markers=['o','o','s','^','o','s','^','D','v','P','X','o']
    for c,color,mark in zip(cats,pal,markers):
        g=pc[pc.terminal_category==c];a2.scatter(g.PC1,g.PC2,s=15 if c not in ['3-4','3-6','4'] else 22,color=color,marker=mark,alpha=.75,label=c,linewidths=.4,edgecolors='#ffffff')
    label(a2,'b');a2.set_title('Unlabelled PCA of eleven features',pad=13);a2.set_xlabel(f'PC1 ({val["PC1_ratio"]*100:.1f}%)');a2.set_ylabel(f'PC2 ({val["PC2_ratio"]*100:.1f}%)');a2.axhline(0,color='#dddddd',lw=.5,zorder=-1);a2.axvline(0,color='#dddddd',lw=.5,zorder=-1)
    m=mix[mix.neighbours==5].pivot(index='focal_category',columns='neighbour_category',values='observed_fraction').loc[cats,cats].to_numpy()*100;ex=mix[mix.neighbours==5].pivot(index='focal_category',columns='neighbour_category',values='excess_percentage_points').loc[cats,cats].to_numpy()
    im=a3.imshow(ex,aspect='auto',cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-55,vcenter=0,vmax=55));label(a3,'c');a3.set_title('Five-neighbour composition (%)',pad=13);a3.set_xticks(range(12),cats,rotation=90,rotation_mode='anchor',ha='right',va='center');a3.set_yticks(range(12),cats);a3.tick_params(length=0,pad=2,labelsize=6);a3.set_xlabel('Neighbour category');a3.set_ylabel('Focal category')
    for i in range(12):
        for j in range(12):a3.text(j,i,f'{m[i,j]:.0f}',ha='center',va='center',fontsize=6,color='white' if abs(ex[i,j])>32 else '#182532')
    cax=fig.add_axes([.92,.145,.012,.28]);cb=fig.colorbar(im,cax=cax);cb.set_label('Excess over size baseline (pp)',fontsize=6);cb.ax.tick_params(labelsize=6)
    h,l=a2.get_legend_handles_labels();fig.legend(h,l,loc='lower center',bbox_to_anchor=(.29,.01),ncol=6,fontsize=6,frameon=False,columnspacing=.8)
    export(fig,'Figure_S3',axes=[ax,a2,a3],exemptions=[{'panels':['a'],'checks':['panel-width','column','horizontal-gutter','vertical-gutter','row'],'reason':'Feature panel intentionally spans both columns; two bottom panels have matched dimensions.'}])
def s4():
    contract('Figure_S4','The preselected Paphos pool has measurable screening coverage and local IMP-A relationships',['screening distribution','fabric distribution','97fit PCA with190projections','nearest measured distances','IMP-A full13dim distance matrix'],'descriptive fixed-inventory distributions, no inferential interval; all unmeasured NAA labels unknown')
    counts=rd('paphos_coverage_metadata_distribution.csv',dtype={'category':str});pc=rd('paphos_coverage_projection.csv');nr=rd('paphos_nearest_measured_distances.csv');imp=rd('paphos_IMPA_objects.csv');pairs=rd('paphos_IMPA_pair_distances.csv');val=json.loads((R/'paphos_coverage_validation.json').read_text());fig=plt.figure(figsize=(7.09,9.0));gs=fig.add_gridspec(3,2,height_ratios=[1.2,1,1.05]);axs=[fig.add_subplot(gs[0,0]),fig.add_subplot(gs[0,1]),fig.add_subplot(gs[1,0]),fig.add_subplot(gs[1,1]),fig.add_subplot(gs[2,:])];fig.subplots_adjust(left=.11,right=.90,bottom=.10,top=.95,wspace=.35,hspace=.47)
    for ax,typ,c in [(axs[0],'screening','a'),(axs[1],'fabric','b')]:
        a=counts[counts.metadata==typ];categories=list(dict.fromkeys(a.category));cats=categories if typ=='screening' else sorted(categories,key=lambda s:(s=='Unnumbered',int(''.join(i for i in s if i.isdigit()) or 0),s))
        for shift,status,color in [(-.18,'Measured (97)','#326AA5'),(.18,'Unmeasured (190)','#BBBBBB')]:
            v=a[a.NAA_status==status].set_index('category').loc[cats].fraction.to_numpy()*100;ax.barh(np.arange(len(cats))+shift,v,height=.34,color=color,label=status)
        label(ax,c);ax.set_yticks(range(len(cats)),[s.replace('IMP-','I-').replace('CYP-','C-') if typ=='screening' else s for s in cats]);ax.invert_yaxis();ax.tick_params(axis='y',labelsize=6,length=0);ax.set_xlabel('Objects in each pool (%)');ax.set_title('Screening codes' if typ=='screening' else 'Numbered AMG fabrics',pad=13);ax.grid(axis='x',alpha=.12)
    ax=axs[2];label(ax,'c')
    for status,color,marker in [('Unmeasured (190)','#BBBBBB','o'),('Measured (97)','#326AA5','^')]:
        a=pc[pc.NAA_status==status];ax.scatter(a.PC1,a.PC2,s=13,color=color,marker=marker,alpha=.75,linewidths=.25,edgecolors='white',label=status)
    ax.set_title('PCA fitted on measured objects',pad=13);ax.set_xlabel(f'PC1 ({100*val["PC1_ratio"]:.1f}%)');ax.set_ylabel(f'PC2 ({100*val["PC2_ratio"]:.1f}%)')
    ax=axs[3];label(ax,'d')
    for status,color in [('Measured (97)','#326AA5'),('Unmeasured (190)','#999999')]:
        v=np.sort(nr[nr.NAA_status==status].distance);ax.step(v,np.arange(1,len(v)+1)/len(v),where='post',color=color,label=status)
    ax.set_xlabel('Nearest measured distance (13 features)');ax.set_ylabel('Cumulative fraction');ax.set_title('Nearest measured object, excluding self',pad=13);ax.set_ylim(0,1.02);ax.set_xlim(left=0);ax.grid(alpha=.1)
    ax=axs[4];label(ax,'e');ids=imp.sample_id.tolist();mat=pairs.pivot(index='object_A',columns='object_B',values='distance').loc[ids,ids].to_numpy();im=ax.imshow(mat,aspect='auto',cmap='Blues');labs=[r.naa_id.replace('Paph17/','/')+' '+r.display_group+(' †' if not r.target_eligible else '') for r in imp.itertuples()];ax.set_xticks(range(len(ids)),[r.naa_id.replace('Paph17/','/') for r in imp.itertuples()]);ax.set_yticks(range(len(ids)),labs);ax.tick_params(length=0,labelsize=6);ax.set_xlabel('Measured IMP-A or mixed IMP-A object');ax.set_title('IMP-A internal distances in the original thirteen features',pad=13)
    cax=fig.add_axes([.92,.108,.012,.19]);cb=fig.colorbar(im,cax=cax);cb.set_label('pXRF distance',fontsize=6);cb.set_ticks([0,1,2,3,4]);cb.ax.tick_params(labelsize=6)
    h,l=axs[0].get_legend_handles_labels();fig.legend(h,l,loc='lower center',bbox_to_anchor=(.51,.012),ncol=2,frameon=False,fontsize=6)
    export(fig,'Figure_S4',axes=axs,exemptions=[{'panels':['e'],'checks':['panel-width','column','horizontal-gutter','vertical-gutter','row'],'reason':'Distance matrix intentionally spans both metadata/projection columns; top and middle panels align.'}])
if __name__=='__main__':fig2();fig3();s3();s4()
