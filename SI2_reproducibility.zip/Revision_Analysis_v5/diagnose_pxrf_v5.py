"""Predefined descriptive diagnostics in archived pXRF feature spaces; no classifiers."""
from pathlib import Path
import json,sys,re,argparse,hashlib

import numpy as np,pandas as pd,openpyxl
ROOT=Path(__file__).resolve().parent;I=ROOT/'inputs';R=ROOT/'results'
parser=argparse.ArgumentParser();parser.add_argument('--maya-input',type=Path,required=True);args=parser.parse_args()
def save(n,x):pd.DataFrame(x).to_csv(R/n,index=False,encoding='utf-8-sig',float_format='%.12g')
def dump(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False),encoding='utf8')
def pca(x):
    mean=x.mean(axis=0);u,s,vt=np.linalg.svd(x-mean,full_matrices=False)
    # Deterministic component signs: largest loading is positive.
    for j in range(len(vt)):
        if vt[j,np.argmax(np.abs(vt[j]))]<0:vt[j]*=-1;u[:,j]*=-1
    return (x-mean)@vt.T,vt,(s*s)/(s*s).sum(),mean
gm=pd.read_csv(I/'maya_group_map.csv',dtype={'object_id':str,'broad_group':str,'terminal_category':str})
with np.load(args.maya_input,allow_pickle=False) as a:ids=a['ids'];x=a['x']
assert ids.tolist()==gm.object_id.tolist() and x.shape==(183,11) and np.isfinite(x).all()
assert np.allclose(x.mean(axis=0),0,atol=1e-10) and np.allclose(x.std(axis=0),1,atol=1e-10)
assert hashlib.sha256(x.tobytes()).hexdigest()=='06adb471b2309745dfa6bf1f4d9e46c32c89680e1d3790b0a59fb74c33d12107'
features=['Al','Ca','Ti','Cr','Mn','Zn','Rb','Sr','Zr','Nb','Mo'];g4=gm.broad_group.to_numpy()=='4';stats=[]
for j,f in enumerate(features):
    for group,mask in [('Group 4',g4),('Other objects',~g4)]:
        v=x[mask,j];q=np.quantile(v,[0,.05,.25,.5,.75,.95,1]);stats.append(dict(feature=f,denominator='Fe',group=group,n=len(v),minimum=q[0],q05=q[1],q25=q[2],median=q[3],q75=q[4],q95=q[5],maximum=q[6],mean=v.mean(),sd=v.std(ddof=1)))
save('maya_all_feature_distributions.csv',stats)
pc,load,ratio,centre=pca(x);pd.concat([gm,pd.DataFrame({'PC1':pc[:,0],'PC2':pc[:,1]})],axis=1).to_csv(R/'maya_pca_scores.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
save('maya_pca_loadings.csv',[dict(feature=f,component=k+1,loading=load[k,j],explained_ratio=ratio[k]) for k in range(11) for j,f in enumerate(features)])
cats=['1','2-1','2-2','2-3','3-1','3-2','3-3','3-4','3-5','3-6','3-7','4'];y=gm.terminal_category.to_numpy();n={c:int((y==c).sum()) for c in cats}
D=np.linalg.norm(x[:,None]-x[None,:],axis=2);np.fill_diagonal(D,np.inf);order=np.argsort(D,axis=1,kind='stable');mix=[];edges=[]
for nn in [3,5,10]:
    nearest=order[:,:nn];assert all(i not in row for i,row in enumerate(nearest))
    for c in cats:
        mask=y==c;neighbours=y[nearest[mask]].ravel()
        for c2 in cats:
            observed=np.mean(neighbours==c2);base=(n[c2]-(c==c2))/182
            mix.append(dict(neighbours=nn,focal_category=c,neighbour_category=c2,focal_objects=n[c],neighbour_objects=n[c2],neighbour_slots=n[c]*nn,observed_fraction=observed,size_baseline=base,excess_percentage_points=100*(observed-base)))
    for i in range(183):
        for rank,j in enumerate(nearest[i]):edges.append(dict(neighbours=nn,object_id=ids[i],category=y[i],rank=rank+1,neighbour_id=ids[j],neighbour_category=y[j],distance=D[i,j]))
save('maya_neighbour_mixing.csv',mix);save('maya_neighbour_edges.csv',edges)
dump('maya_feature_neighbour_validation.json',{'status':'PASS','objects':183,'features':features,'PCA_unlabelled':True,'PC1_ratio':float(ratio[0]),'PC2_ratio':float(ratio[1]),'neighbours':[3,5,10],'self_excluded':True,'all_terminal_categories':cats,'standardized_source_sha256':hashlib.sha256(x.tobytes()).hexdigest(),'source_matrices_redistributed':False})

px=pd.read_csv(I/'paphos_pxrf.csv');w=openpyxl.load_workbook(ROOT.parent/'Analysis/source_measurements/paphos/Paphos Amphorae List of pXRF samples.xlsx',data_only=True,read_only=True);rows=list(w.active.values)[1:]
inv=pd.DataFrame(rows,columns=['fragment_id','inventory_number','macroscopic_fabric','sampled_part','source_pxrf_cluster','aux1','aux2','site','naa_id']);assert len(inv)==291 and inv.fragment_id.is_unique
roof=['Paphos028','Paphos029','Paphos030','Paphos031'];tile=inv[inv.fragment_id.isin(roof)]
assert len(tile)==4 and tile.sampled_part.astype(str).str.contains('tile',case=False).all(),tile.to_dict('records')
save('paphos_excluded_roof_tiles.csv',tile[['fragment_id','inventory_number','macroscopic_fabric','sampled_part']])
labels=pd.read_csv(I/'paphos_reference_labels.csv',keep_default_na=False);known=set(labels.sample_id)
inv=inv[~inv.fragment_id.isin(roof)].copy();assert len(inv)==287
meta=px.merge(inv,on='fragment_id',validate='one_to_one');assert len(meta)==287
meta['NAA_status']=np.where(meta.fragment_id.isin(known),'Measured (97)','Unmeasured (190)')
meta['NAA_identity_known']=meta.fragment_id.isin(known)
def amg(t):
    m=re.search(r'AMG\s*(\d+)\s*([A-Z]?)',str(t));return m.group(1)+m.group(2) if m else 'Unnumbered'
meta['AMG']=meta.macroscopic_fabric.map(amg);measured=meta.fragment_id.isin(known).to_numpy();assert measured.sum()==97 and (~measured).sum()==190
# Source inventory NAA field is independently cross-checked, including absence among190.
assert set(meta.loc[meta.naa_id.notna(),'fragment_id'])==known
cols=[f'alr_{f}_over_Fe' for f in ['Ca','Cr','Cu','K','Mn','Ni','Pb','Rb','Sr','Ti','V','Zn','Zr']];raw=meta[cols].to_numpy(float);mu=raw[measured].mean(axis=0);sd=raw[measured].std(axis=0,ddof=0);z=(raw-mu)/sd
assert np.isfinite(z).all() and np.allclose(z[measured].mean(axis=0),0,atol=1e-12) and np.allclose(z[measured].std(axis=0),1)
pc97,loading,ratio97,ctr=pca(z[measured]);projection=(z-ctr)@loading.T
base=meta[['fragment_id','NAA_status','NAA_identity_known','fragment_pxrf_cluster','macroscopic_fabric','AMG','site']].copy();base['PC1']=projection[:,0];base['PC2']=projection[:,1];save('paphos_coverage_projection.csv',base)
save('paphos_standardization_PCA.csv',[dict(feature=f,mean97=mu[j],sd97=sd[j],component=k+1,loading=loading[k,j],explained_ratio=ratio97[k]) for k in range(13) for j,f in enumerate(cols)])
counts=[]
for typ,col in [('screening','fragment_pxrf_cluster'),('fabric','AMG'),('original_fabric','macroscopic_fabric')]:
    values=sorted(meta[col].unique(),key=str)
    for status,size in [('Measured (97)',97),('Unmeasured (190)',190)]:
        s=meta[meta.NAA_status==status][col].value_counts()
        for value in values:counts.append(dict(metadata=typ,category=value,NAA_status=status,n=int(s.get(value,0)),total=size,fraction=int(s.get(value,0))/size))
save('paphos_coverage_metadata_distribution.csv',counts)
allD=np.linalg.norm(z[:,None]-z[None,:],axis=2);target_idx=np.flatnonzero(measured);dm=allD[:,target_idx].copy()
for j,i in enumerate(target_idx):dm[i,j]=np.inf
near=dm.argmin(axis=1);dist=dm.min(axis=1);nr=base[['fragment_id','NAA_status']].copy();nr['nearest_measured_id']=meta.fragment_id.to_numpy()[target_idx[near]];nr['distance']=dist;nr['self_excluded']=True;save('paphos_nearest_measured_distances.csv',nr)
nd=[]
for status,g in nr.groupby('NAA_status'):
    v=g.distance.to_numpy();nd.append(dict(NAA_status=status,n=len(v),mean=v.mean(),median=np.median(v),q05=np.quantile(v,.05),q25=np.quantile(v,.25),q75=np.quantile(v,.75),q95=np.quantile(v,.95),maximum=v.max()))
save('paphos_nearest_distance_summary.csv',nd)
positions={s:i for i,s in enumerate(meta.fragment_id)};imp=labels[labels.published_2021_pxrf_cluster.str.contains('IMP-A')].copy()
imp['display_group']=imp.published_2021_group.where(imp.published_2021_group.isin(['KOS-A','KOS-D','THASSOS']),'Other')
imp['group_order']=imp.display_group.map({'KOS-A':0,'KOS-D':1,'THASSOS':2,'Other':3});imp=imp.sort_values(['group_order','naa_id']);impids=imp.sample_id.tolist();impz=z[[positions[s] for s in impids]];idd=np.linalg.norm(impz[:,None]-impz[None,:],axis=2)
targetrefs=pd.read_csv(I/'reference_membership.csv');targetcore=set(targetrefs[targetrefs.target_id=='IMPA_Koan_Thassian_subdivision'].object_id)
imp['target_eligible']=imp.sample_id.isin(targetcore);save('paphos_IMPA_objects.csv',imp.drop(columns='group_order'))
save('paphos_IMPA_pair_distances.csv',[dict(object_A=a,object_B=b,group_A=imp.display_group.iloc[i],group_B=imp.display_group.iloc[j],distance=idd[i,j],dimensions=13) for i,a in enumerate(impids) for j,b in enumerate(impids)])
impnear=[]
for i,s in enumerate(impids):
    dd=idd[i].copy();dd[i]=np.inf;j=dd.argmin();impnear.append(dict(object_id=s,group=imp.display_group.iloc[i],target_eligible=bool(imp.target_eligible.iloc[i]),nearest_id=impids[j],nearest_group=imp.display_group.iloc[j],distance=dd[j],same_group=imp.display_group.iloc[i]==imp.display_group.iloc[j]))
save('paphos_IMPA_nearest_relations.csv',impnear)
dump('paphos_coverage_validation.json',{'status':'PASS','original_objects':291,'roof_tiles':roof,'amphorae':287,'measured':97,'unmeasured_NAA_unknown':190,'PCA_fit_objects':97,'PC1_ratio':float(ratio97[0]),'PC2_ratio':float(ratio97[1]),'IMPA_objects':len(impids),'IMPA_core_objects':int(imp.target_eligible.sum()),'identity_not_assigned_to_unmeasured':True,'standardization_ddof':0,'nearest_excludes_self':True,'no_new_transform':True})
print('Maya PCA:',ratio[:2],'; Paphos PCA:',ratio97[:2]);print(pd.DataFrame(nd).to_string(index=False));print(pd.DataFrame(impnear).to_string(index=False));print(pd.DataFrame(mix).query("neighbours==5 and focal_category in ['3-4','3-6','4'] and observed_fraction>0").round(4).to_string(index=False))
