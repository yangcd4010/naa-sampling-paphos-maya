"""Exact conditional random references and paired archived-path sensitivity; no model fitting."""
from pathlib import Path
from functools import lru_cache
from itertools import permutations
from math import comb
import json,hashlib,sys
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;I=ROOT/'inputs';R=ROOT/'results';R.mkdir(exist_ok=True)
RULES=['Random','Proportional','PQMM','Max-min','Updated MU','Updated DWU','Frozen MU','Frozen DWU']
FABRIC=['Cross-stratified','APDC'];SEEDS=list(range(1001,1101))
def save(n,x):pd.DataFrame(x).to_csv(R/n,index=False,encoding='utf-8-sig',float_format='%.12g')
def dump(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False),encoding='utf8')
def read(n,**kw):return pd.read_csv(I/n,**kw)
@lru_cache(None)
def exact(remaining,deficits,b0=15):
    assert len(remaining)==len(deficits) and all(0<=d<=n for n,d in zip(remaining,deficits))
    M=sum(remaining);poly=[1]
    for n,d in zip(remaining,deficits):
        poly=np.convolve(np.array(poly,dtype=object),np.array([comb(n,j) if j>=d else 0 for j in range(n+1)],dtype=object)).tolist()
    cdf=np.array([int(poly[q])/comb(M,q) for q in range(M+1)])
    assert np.isfinite(cdf).all() and np.diff(cdf).min()>=-1e-12 and cdf.min()>=0 and cdf.max()<=1 and cdf[-1]==1
    survival=1-cdf[:-1];mu=b0+survival.sum();second=b0*b0+np.dot(2*(b0+np.arange(M))+1,survival);var=max(0,second-mu*mu)
    if not any(deficits):assert mu==b0 and var==0 and np.all(cdf==1)
    return float(mu),float(var),cdf
def exhaustive_tests():
    rows=[]
    for sizes,initial,need in [((2,2,3),(0,0,1),(1,1,0)),((3,2,2),(1,0,0),(1,1,0)),((2,2,2),(1,1,0),(0,0,0)),((3,2,2),(0,0,1),(2,2,0)),((2,2,2),(1,0,0),(1,2,0))]:
        rem=tuple(n-a for n,a in zip(sizes,initial));labels=[g for g,n in enumerate(rem) for _ in range(n)];b0=sum(initial);values=[]
        for p in permutations(range(len(labels))):
            seen=[0]*len(rem);b=b0
            if any(need):
                for idx in p:
                    seen[labels[idx]]+=1;b+=1
                    if all(a>=d for a,d in zip(seen,need)):break
            values.append(b)
        mu,var,cdf=exact(rem,need,b0)
        empirical=np.array([np.mean(np.array(values)<=b0+q) for q in range(sum(rem)+1)])
        assert np.allclose(cdf,empirical,atol=1e-12) and abs(mu-np.mean(values))<1e-10 and abs(var-np.var(values))<1e-10
        rows.append(dict(sizes=sizes,initial=initial,deficits=need,orders=len(values),mean=mu,variance=var,includes_outside=True,status='PASS'))
    mu,var,cdf=exact((2,3,7),(0,0,0),15);assert mu==15 and var==0
    dump('exact_random_exhaustive_tests.json',{'status':'PASS','small_pool_checks':rows,'initially_complete_budget15':'PASS'})
refs=read('reference_membership.csv',dtype={'object_id':str,'set_id':str});refs=refs[refs.eligible.astype(str).str.lower()=='true']
starts=read('initial_sets.csv',dtype={'object_id':str});initial={(c,int(s)):set(g.object_id) for (c,s),g in starts.groupby(['dataset','replay_id'])}
labels=read('paphos_reference_labels.csv');pools={'Paphos':set(labels.sample_id),'Maya':set(map(str,range(183)))}
units={(c,t):{u:set(h.object_id) for u,h in g.groupby('set_id')} for (c,t),g in refs.groupby(['dataset','target_id'])}
assert len(pools['Paphos'])==97 and len(initial)==200 and all(len(a)==15 for a in initial.values())
for (c,t),u in units.items():assert sum(map(len,u.values()))==len(set().union(*u.values())) and set().union(*u.values())<=pools[c]
ev=read('endpoints.csv');sens=read('AEG5_sensitivity_endpoints.csv');bi=np.load(I/'bootstrap_indices.npz');idx=bi['initial_sets'];oi=bi['orders']
assert idx.shape==(10000,100) and oi.shape==(10000,20)
S=np.stack([np.bincount(row,minlength=100) for row in idx])/100
O=np.stack([np.bincount(row,minlength=20) for row in oi])/20
exclusions=json.loads((ROOT/'REVISION_ANALYSIS_PROTOCOL.json').read_text())['random']['AEG5_exclusions'] if (ROOT/'REVISION_ANALYSIS_PROTOCOL.json').exists() else ['Paphos110','Paphos125','Paphos165','Paphos201']
def calculate():
    rows=[];curves=[]
    cases=[(c,t,'none',u) for (c,t),u in units.items()]
    u=units['Paphos','Aegean_six_unlocated_patterns']
    cases += [('Paphos','Aegean_six_unlocated_patterns',x,{k:v-{x} for k,v in u.items()}) for x in exclusions]
    for c,t,x,u in cases:
        target_union=set().union(*u.values());outside=pools[c]-target_union
        for seed in SEEDS:
            a=initial[c,seed];sizes=[len(m) for m in u.values()]+[len(outside)];counts=[len(a&m) for m in u.values()]+[len(a&outside)]
            assert sum(sizes)==len(pools[c]) and sum(counts)==15
            for k in ([1,2] if c=='Paphos' else [1,2,3,5]):
                remaining=tuple(n-v for n,v in zip(sizes,counts));need=tuple(max(k-v,0) for v in counts[:-1])+(0,)
                mu,var,cdf=exact(remaining,need)
                source=(ev[(ev.case==c)&(ev.target==t)] if x=='none' else sens[sens.excluded==x])
                r=source[(source.seed==seed)&(source.k==k)&(source.rule=='Random')];assert len(r)==1
                archived=int(r.budget.iloc[0]);rows.append(dict(case=c,target=t,excluded=x,k=k,seed=seed,expected_random_budget=mu,conditional_variance=var,conditional_sd=var**.5,archived_random_budget=archived,continuation_residual=archived-mu,initial_complete=not any(need),outside_target_objects=len(outside),outside_initial=counts[-1],remaining_counts=json.dumps(remaining),deficits=json.dumps(need),oracle_budget=15+sum(need)))
                curves.extend(dict(case=c,target=t,excluded=x,k=k,seed=seed,budget=15+q,completion_probability=p) for q,p in enumerate(cdf))
        print('Exact reference:',c,t,x,flush=True)
    d=pd.DataFrame(rows);save('conditional_random_by_start.csv',d);cf=pd.DataFrame(curves);cf.to_csv(R/'conditional_random_cdf_by_start.csv.gz',index=False,encoding='utf-8-sig',compression={'method':'gzip','mtime':0},float_format='%.12g')
    save('conditional_random_mean_cdf.csv',cf.groupby(['case','target','excluded','k','budget']).completion_probability.mean().reset_index())
    v=[]
    for (c,t,x,k),g in d.groupby(['case','target','excluded','k']):
        se=np.sqrt(g.conditional_variance.sum())/100;res=g.continuation_residual.mean();boot=S@g.sort_values('seed').expected_random_budget.to_numpy();lo,hi=np.quantile(boot,[.025,.975])
        v.append(dict(case=c,target=t,excluded=x,k=k,archived_mean=g.archived_random_budget.mean(),conditional_mean=g.expected_random_budget.mean(),CI_low=lo,CI_high=hi,residual_mean=res,conditional_MCSE=se,residual_in_MCSE=res/se if se else 0,initial_complete=int(g.initial_complete.sum()),oracle_mean=g.oracle_budget.mean()))
    save('random_continuation_validation.csv',v)
    old=read('maya_random_conditional_expectation.csv');new=d[(d.case=='Maya')&(d.excluded=='none')].rename(columns={'seed':'replay_id','target':'resolution'}).merge(old,on=['replay_id','resolution','k'],validate='one_to_one')
    err=np.max(np.abs(new.expected_random_budget-new.expected_random_budget_conditional));errv=np.max(np.abs(new.conditional_sd_x-new.conditional_sd_y))
    # Input CSVs have 12 significant digits, so compare at their precision.
    assert len(new)==800 and err<1e-8 and errv<1e-8
    dump('maya_reference_reproduction.json',{'status':'PASS','rows':800,'max_mean_error':float(err),'max_sd_error':float(errv),'models_fitted':0})
    return d
def array_for(source,t,k,rule):
    g=source[(source.k==k)&(source.rule==rule)]
    if 'target' in g:g=g[g.target==t]
    if rule in FABRIC:
        g=g[g.order.str.startswith('random_')];a=g.pivot(index='order',columns='seed',values='budget').reindex(index=[f'random_{i:02d}' for i in range(1,21)],columns=SEEDS).to_numpy(float);assert a.shape==(20,100) and np.isfinite(a).all();return a
    return g.sort_values('seed').budget.to_numpy(float)
def boot_mean(a):
    if a.ndim==1:assert len(a)==100;return S@a
    return np.einsum('bs,bs->b',O@a,S)
def analyse(d):
    summaries=[];contrasts=[];paired=[];regrets=[];rcontr=[];perstart=[];compact=[]
    scenarios=[(c,'none',ev[ev.case==c]) for c in ['Paphos','Maya']]+[('Paphos',x,sens[sens.excluded==x]) for x in exclusions]
    for c,x,source in scenarios:
        ts=list(dict.fromkeys(source.target)) if 'target' in source else ['Aegean_six_unlocated_patterns'];rr=RULES+(FABRIC if c=='Paphos' else [])
        for k in ([1,2] if c=='Paphos' else [1,2,3,5]):
            bm=np.empty((10000,len(ts),len(rr)));means=np.empty((len(ts),len(rr)))
            for ti,t in enumerate(ts):
                rd=d[(d.case==c)&(d.target==t)&(d.excluded==x)&(d.k==k)].sort_values('seed');random=rd.expected_random_budget.to_numpy();oracle=rd.oracle_budget.to_numpy()
                arr={r:(random if r=='Random' else array_for(source,t,k,r)) for r in rr}
                for j,r in enumerate(rr):
                    a=arr[r];boot=boot_mean(a);lo,hi=np.quantile(boot,[.025,.975]);mean=a.mean();means[ti,j]=mean;bm[:,ti,j]=boot
                    delta=a-random;db=boot_mean(delta);dl,dh=np.quantile(db,[.025,.975]);summaries.append(dict(case=c,target=t,excluded=x,k=k,rule=r,mean_budget=mean,CI_low=lo,CI_high=hi,random_mean=random.mean(),oracle_mean=oracle.mean(),oracle_excess=mean-oracle.mean(),random_regime='exact conditional expectation' if r=='Random' else 'archived nonrandom paths',orders=20 if r in FABRIC else 1))
                    contrasts.append(dict(case=c,target=t,excluded=x,k=k,rule=r,mean_delta=delta.mean(),CI_low=dl,CI_high=dh,delta_direction='rule minus exact conditional random expectation',orders=20 if r in FABRIC else 1))
                    aa=a.mean(axis=0) if a.ndim==2 else a
                    perstart.extend(dict(case=c,target=t,excluded=x,k=k,rule=r,seed=s,budget=b,exact_random=er,delta=b-er,oracle_budget=ob) for s,b,er,ob in zip(SEEDS,aa,random,oracle))
                for r1,r2 in [('PQMM','Proportional'),('Updated MU','Frozen MU'),('Updated DWU','Frozen DWU')]+([('Cross-stratified','APDC')] if c=='Paphos' else []):
                    delta=arr[r1]-arr[r2];boot=boot_mean(delta);lo,hi=np.quantile(boot,[.025,.975]);paired.append(dict(case=c,target=t,excluded=x,k=k,rule_A=r1,rule_B=r2,mean_delta=delta.mean(),CI_low=lo,CI_high=hi))
                if k==2:compact.append(dict(case=c,target=t,excluded=x,exact_random_mean=random.mean(),oracle_mean=oracle.mean(),minimum_rule_budget=means[ti].min(),maximum_rule_budget=means[ti].max(),minimum_rule=rr[means[ti].argmin()],maximum_rule=rr[means[ti].argmax()],minimum_oracle_excess=means[ti].min()-oracle.mean(),maximum_oracle_excess=means[ti].max()-oracle.mean()))
            for regime,count in [('shared_eight',8)]+([('including_fabric',10)] if c=='Paphos' else []):
                a=means[:,:count];b=bm[:,:,:count];best=a.min(axis=1,keepdims=True);bestb=b.min(axis=2,keepdims=True);ab=a-best;abb=b-bestb;rel=ab/best;relb=abb/bestb
                for metric,value,boot in [('maximum_absolute',ab.max(axis=0),abb.max(axis=1)),('mean_absolute',ab.mean(axis=0),abb.mean(axis=1)),('maximum_relative',rel.max(axis=0),relb.max(axis=1))]:
                    ties=np.isclose(boot,boot.min(axis=1,keepdims=True),atol=1e-10,rtol=0);rank_share=(ties/ties.sum(axis=1,keepdims=True)).mean(axis=0)
                    for j,r in enumerate(rr[:count]):
                        lo,hi=np.quantile(boot[:,j],[.025,.975]);regrets.append(dict(case=c,excluded=x,k=k,rule_set=regime,metric=metric,rule=r,estimate=value[j],CI_low=lo,CI_high=hi,point_minimum_rule=rr[value.argmin()],bootstrap_minimum_fraction=rank_share[j]))
                    if metric=='maximum_absolute':
                        for r1,r2 in [('PQMM','Updated MU'),('PQMM','Random'),('Updated DWU','Random')]:
                            j1,j2=rr.index(r1),rr.index(r2);lo,hi=np.quantile(boot[:,j1]-boot[:,j2],[.025,.975]);rcontr.append(dict(case=c,excluded=x,k=k,rule_set=regime,rule_A=r1,rule_B=r2,mean_delta=value[j1]-value[j2],CI_low=lo,CI_high=hi))
    for n,x in [('primary_budget_summary.csv',summaries),('rule_minus_exact_random.csv',contrasts),('paired_rule_comparisons.csv',paired),('conditional_random_regret.csv',regrets),('regret_contrasts.csv',rcontr),('rule_differences_by_start.csv',perstart),('S50_compact_summary.csv',compact)]:save(n,x)
def cluster():
    a=read('additional_sensitivity_endpoints_v15.csv');a=a[(a.dataset=='Maya')&a.run_set.isin(['clusters5','clusters20'])].copy();a['clusters']=a.run_set.str.replace('clusters','').astype(int)
    p=ev[(ev.case=='Maya')&ev.rule.isin(['PQMM','Proportional'])].copy();p['clusters']=10
    allc=pd.concat([a[['clusters','seed','rule','target','k','budget']],p[['clusters','seed','rule','target','k','budget']]])
    sums=[];contr=[];values=[]
    for (r,t,k),g in allc.groupby(['rule','target','k']):
        f=g.pivot(index='seed',columns='clusters',values='budget').reindex(index=SEEDS)
        for cl in [5,10,20]:
            b=f[cl].to_numpy();lo,hi=np.quantile(S@b,[.025,.975]);sums.append(dict(rule=r,target=t,k=k,clusters=cl,mean=b.mean(),CI_low=lo,CI_high=hi))
        for ca,cb in [(20,10),(5,10),(20,5)]:
            delta=(f[ca]-f[cb]).to_numpy();lo,hi=np.quantile(S@delta,[.025,.975]);contr.append(dict(rule=r,target=t,k=k,clusters_A=ca,clusters_B=cb,mean_delta=delta.mean(),CI_low=lo,CI_high=hi,n_starts=100))
            values.extend(dict(rule=r,target=t,k=k,clusters_A=ca,clusters_B=cb,seed=s,delta=v) for s,v in zip(SEEDS,delta))
    # Independently rescore all saved 5/20-cluster paths, checking their shared starts.
    import gzip
    with gzip.open(ROOT.parent/'Analysis/data/acquisition_paths.json.gz','rt',encoding='utf8') as f: archived=json.load(f)
    path={}
    for pid,seq in archived.items():
        case,setting,seed,rule=pid.split('|')
        if case=='Maya' and setting in ['clusters5','clusters20']:
            path.setdefault(setting.replace('clusters',''),{}).setdefault(seed,{})[rule]=seq
    checks=0
    for cl,se in path.items():
        for s,rr in se.items():
            for r,seq in rr.items():
                ss=list(map(str,seq));assert len(ss)==183 and set(ss)==pools['Maya'] and set(ss[:15])==initial['Maya',int(s)]
                rank={j:max(15,i+1) for i,j in enumerate(ss)}
                for t in ['main','terminal']:
                    for k in [1,2,3,5]:
                        v=max(sorted(rank[j] for j in m)[k-1] for m in units['Maya',t].values());old=allc[(allc.clusters==int(cl))&(allc.seed==int(s))&(allc.rule==r)&(allc.target==t)&(allc.k==k)].budget
                        assert len(old)==1 and v==int(old.iloc[0]);checks+=1
    save('cluster_sensitivity_summary.csv',sums);save('cluster_sensitivity_paired.csv',contr);save('cluster_sensitivity_paired_by_start.csv',values)
    dump('cluster_path_validation.json',{'status':'PASS','matched_endpoints':checks,'new_paths_generated':0,'initial_sets_unchanged':True})
if __name__=='__main__':
    exhaustive_tests();d=calculate();analyse(d);cluster()
    print(pd.read_csv(R/'random_continuation_validation.csv').query("excluded=='none' and k==2").round(5).to_string(index=False),flush=True)
    print(pd.read_csv(R/'cluster_sensitivity_paired.csv').query("rule=='PQMM' and k==2 and clusters_A==20 and clusters_B==10").round(5).to_string(index=False),flush=True)
    print('Exact-reference analyses complete; model fits 0',flush=True)
