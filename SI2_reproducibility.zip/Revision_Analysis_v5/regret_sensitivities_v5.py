"""Compute regret sensitivities using the exact conditional random reference."""
import analyse_v5 as a
import numpy as np,pandas as pd
d=pd.read_csv(a.R/'conditional_random_by_start.csv');extra=a.read('additional_sensitivity_endpoints_v15.csv');rows=[]
def calc(case,label,k,source,fabric_order=None):
    ts=list(dict.fromkeys(source.target));rules=a.RULES+(a.FABRIC if fabric_order is not None else []);means=np.zeros((len(ts),len(rules)));boots=np.zeros((10000,len(ts),len(rules)))
    for i,t in enumerate(ts):
        for j,r in enumerate(rules):
            if r=='Random':b=d[(d.case==case)&(d.target==t)&(d.k==k)&(d.excluded=='none')].sort_values('seed').expected_random_budget.to_numpy()
            elif r in a.FABRIC:b=source[(source.target==t)&(source.k==k)&(source.rule==r)&(source.order==fabric_order)].sort_values('seed').budget.to_numpy()
            else:b=source[(source.target==t)&(source.k==k)&(source.rule==r)].sort_values('seed').budget.to_numpy()
            assert len(b)==100;means[i,j]=b.mean();boots[:,i,j]=a.S@b
    ar=means-means.min(axis=1,keepdims=True);br=boots-boots.min(axis=2,keepdims=True)
    for metric,est,boot in [('maximum_absolute',ar.max(axis=0),br.max(axis=1)),('maximum_relative',(ar/means.min(axis=1,keepdims=True)).max(axis=0),(br/boots.min(axis=2,keepdims=True)).max(axis=1))]:
        for j,r in enumerate(rules):
            lo,hi=np.quantile(boot[:,j],[.025,.975]);rows.append(dict(case=case,setting=label,k=k,metric=metric,rule=r,estimate=est[j],CI_low=lo,CI_high=hi,minimum_rule=rules[est.argmin()]))
primary=a.ev
# Three fixed forest seeds plus their within-start mean, all preserve paired starts.
base=primary[(primary.case=='Paphos')&(~primary.rule.str.contains('MU|DWU'))&(primary.order=='archived')]
fs=extra[(extra.dataset=='Paphos')&extra.run_set.str.startswith('forest_seed')]
for setting,g in fs.groupby('run_set'):calc('Paphos',setting,2,pd.concat([base,g],ignore_index=True))
avg=fs.groupby(['seed','rule','target','k']).budget.mean().reset_index();calc('Paphos','fixed_seed_average',2,pd.concat([base,avg],ignore_index=True))
# Maya broader response affects forests only; random reference remains the same.
base=primary[(primary.case=='Maya')&(~primary.rule.str.contains('MU|DWU'))]
y15=extra[(extra.dataset=='Maya')&(extra.run_set=='y15')]
for k in [1,2]:calc('Maya','y15_response',k,pd.concat([base,y15],ignore_index=True))
# Each shared AMG order is a setting, not an independent assemblage.
nonfab=primary[(primary.case=='Paphos')&(~primary.rule.isin(a.FABRIC))&(primary.order=='archived')]
for order in [f'random_{i:02d}' for i in range(1,21)]:
    pp=primary[(primary.case=='Paphos')&(primary.order==order)]
    for k in [1,2]:calc('Paphos',order,k,pd.concat([nonfab,pp],ignore_index=True),order)
a.save('regret_sensitivity_summary.csv',rows)
print(pd.DataFrame(rows).query("rule==minimum_rule and k==2").round(4).to_string(index=False))
