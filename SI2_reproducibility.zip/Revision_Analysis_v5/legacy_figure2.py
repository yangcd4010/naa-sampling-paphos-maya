from pathlib import Path
import sys,json,shutil,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.transforms import ScaledTranslation
ROOT=Path(__file__).resolve().parent;R=ROOT/'results';I=ROOT.parent/'Analysis/inputs';F=ROOT/'figures'
sys.path.insert(0,str(ROOT/'tools'))
from audit_panel_alignment import require_matplotlib_panel_alignment
plt.rcParams.update({'font.family':'Arial','font.size':8,'axes.labelsize':8,'axes.titlesize':9,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,'lines.linewidth':1.1,'pdf.fonttype':42,'svg.fonttype':'none','savefig.dpi':600})
names=['Random','Proportional-representative','PQMM','Cross-stratified','APDC','Conditional max-min','Model-uncertainty','Density-weighted uncertainty','Frozen MU','Frozen DWU']
display={'Proportional-representative':'Proportional','Conditional max-min':'Max-min','Model-uncertainty':'Updated MU','Density-weighted uncertainty':'Updated DWU'}
targets=['Paphian_AMG48_vs_AMG21B','Kourion_five_patterns','IMPA_Koan_Thassian_subdivision','CYPB_Paphian_Kourion_separation','Sicily_cross_cluster_correction','Aegean_six_unlocated_patterns']
short=['Paphian','Five\nKourion','Koan–\nThassian','CYP-B','Sicilian','Six\nAegean']
colors={'Random':'#555555','Proportional':'#999999','PQMM':'#397B60','Max-min':'#326AA5','Updated MU':'#BB703B','Updated DWU':'#985475','Frozen MU':'#C99F7D','Frozen DWU':'#BFA0B8','APDC':'#BB703B','Cross-stratified':'#326AA5'}
def read(p):return pd.read_csv(p,keep_default_na=False)
def label(ax,s):
    ax.set_label(s);ax.text(0,1,s,transform=ax.transAxes+ScaledTranslation(-20/72,8/72,ax.figure.dpi_scale_trans),weight='bold',size=10,va='bottom')
def export(fig,name,exclude=None):
    fig.canvas.draw();require_matplotlib_panel_alignment(fig,json_out=F/f'{name}.alignment.json',exclude_axes=exclude or [],strict=True)
    fig.savefig(F/f'{name}.pdf');fig.savefig(F/f'{name}.svg');fig.savefig(F/f'{name}.png',dpi=300);fig.savefig(F/f'{name}.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)


def fig2():
    meta=read(I/'paphos'/'pre_naa_metadata.csv').set_index('fragment_id');refs=read(ROOT.parent/'Revision_Analysis_v5/inputs/paphos_reference_labels.csv').set_index('sample_id')
    dst=I/'paphos'/'naa_oracle_clr.csv'
    assert dst.exists()
    naa=read(dst).set_index('fragment_id');cols=[c for c in naa if c.startswith('clr_') and c not in ['clr_As','clr_Lu']];assert len(cols)==29
    Y=naa[cols].subtract(naa.clr_Lu,axis=0)
    ids1=refs[refs.published_2021_group=='SICILY'].sort_values('naa_id').index.tolist()
    ids2=refs[refs.published_2021_pxrf_cluster=='CYP-B'].sort_values('naa_id').index.tolist()
    assert len(ids1)==5 and len(ids2)==8
    pairdata=[];allids=ids1+ids2
    distance=np.sqrt(((Y.loc[allids].to_numpy()[:,None]-Y.loc[allids].to_numpy()[None,:])**2).sum(axis=2));vmax=distance.max()
    fig,axs=plt.subplots(3,2,figsize=(7.09,7.95),gridspec_kw={'height_ratios':[.95,1,1]})
    fig.subplots_adjust(left=.12,right=.90,top=.94,bottom=.09,wspace=.40,hspace=.65)
    for j,(ids,title) in enumerate([(ids1,'Sicilian cross-cluster link'),(ids2,'Chemical separation within CYP-B')]):
        ax=axs[0,j];ax.set_axis_off();label(ax,'ab'[j]);ax.set_title(title,pad=12)
        xx=[0,.24,.45,.73];headers=['Paph17/','AMG','pXRF','NAA']
        for x,h in zip(xx,headers):ax.text(x,.98,h,transform=ax.transAxes,size=7.3,weight='bold',va='top')
        for n,s in enumerate(ids):
            rr=refs.loc[s];mm=meta.loc[s];texts=[rr.naa_id.split('/')[1],mm.amg_key or '—',rr.published_2021_pxrf_cluster,rr.published_2021_group or 'loner']
            for x,t in zip(xx,texts):ax.text(x,.84-n*.105,t,transform=ax.transAxes,size=7.0,va='top')
        ax=axs[1,j];label(ax,'cd'[j]);yy=Y.loc[ids].to_numpy();dd=np.sqrt(((yy[:,None]-yy[None,:])**2).sum(axis=2))
        im=ax.imshow(dd,aspect='auto',cmap='Blues',vmin=0,vmax=vmax);labs=[refs.loc[s].naa_id.split('/')[1] for s in ids]
        ax.set_xticks(range(len(ids)),labs);ax.set_yticks(range(len(ids)),labs);ax.tick_params(length=0);ax.set_title('Measured NAA log-ratio distances',pad=9);ax.set_xlabel('Paph17/');ax.set_ylabel('Paph17/')
        for a,s in enumerate(ids):
            for b,t in enumerate(ids):pairdata.append(dict(case=title,sample_a=s,sample_b=t,distance=dd[a,b],elements=29))
        ax=axs[2,j];label(ax,'ef'[j]);target=targets[4] if j==0 else targets[3]
        df=read(R/'Paphos_random_order_curves.csv');df=df[df.target==target]
        for method in ['Random','PQMM','Updated DWU','APDC','Cross-stratified']:
            aa=df[df.rule==method].sort_values('budget');name=method;color=colors[name]
            ax.plot(aa.budget,aa['mean'],label=('Exact random' if method=='Random' else name),color=color,linestyle='--' if method=='Random' else '-',linewidth=1.25)
            ax.fill_between(aa.budget,aa.low,aa.high,color=color,alpha=.09,linewidth=0)
        ax.set_xlim(15,97);ax.set_ylim(-.025,1.025);ax.set_xticks([15,35,55,75,97]);ax.set_yticks([0,.5,1]);ax.set_xlabel('NAA budget');ax.set_ylabel('Target attainment');ax.grid(axis='y',alpha=.12)
    cax=fig.add_axes([.93,.40,.014,.19]);fig.colorbar(im,cax=cax);cax.tick_params(labelsize=6.5);cax.set_ylabel('Euclidean distance',size=7)
    handles,labels=axs[2,0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.51,.001),ncol=3,fontsize=7,frameon=False)
    read(R/'Paphos_random_order_curves.csv').to_csv(F/'Figure2_acquisition_source.csv',index=False)
    pd.DataFrame(pairdata).to_csv(F/'Figure2_distances_source.csv',index=False)
    pd.DataFrame([dict(sample_id=s,naa_id=refs.loc[s].naa_id,amg=meta.loc[s].amg_key,pxrf=refs.loc[s].published_2021_pxrf_cluster,reference=refs.loc[s].published_2021_group or 'loner') for s in allids]).to_csv(F/'Figure2_metadata_source.csv',index=False)
    export(fig,'Figure2',[cax]);(F/'Figure2_input_hash.json').write_text(json.dumps({'input':'inputs/paphos/naa_oracle_clr.csv','sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'transform':'29 natural log ratios to Lu; remove As and Lu from 31 CLR numerator coordinates; no coordinate standardisation; no dimension reduction'},indent=2))

