"""Fixed-forest-seed sensitivity, using only selected NAA responses.

Input matrices must be recreated from the original provider and stay local.
"""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
from pathlib import Path
import sys, json, argparse, time, gzip, hashlib
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'Analysis/selector'))
import maya_selection_core as core
SEEDS=(202610041,202610042,202610043)
RULES=('Updated MU','Frozen MU','Updated DWU','Frozen DWU')

def read_inputs(matrix):
    a=np.load(matrix,allow_pickle=False)
    ids=a['ids']; x=a['x']; y=a['y8']; clusters=a['clusters10']
    refs=json.loads((ROOT/'Analysis/inputs/maya/reference_for_evaluation.json').read_text())
    assert ids.tolist()==[r['ANID'] for r in refs]
    assert x.shape==(183,11) and y.shape==(183,8)
    assert np.isfinite(x).all() and np.isfinite(y).all()
    starts=json.loads((ROOT/'Analysis/inputs/maya/initial_sets.json').read_text())
    return ids,x,y,clusters,starts

def smoke(matrix,out):
    import csv
    ids,x,y,clusters,starts=read_inputs(matrix)
    geom=core.geometry(x,clusters)
    with gzip.open(ROOT/'Analysis/data/acquisition_paths.json.gz','rt') as f:paths=json.load(f)
    with (ROOT/'Analysis/data/path_metadata.csv').open(newline='',encoding='utf-8-sig') as f:meta=list(csv.DictReader(f))
    records=[]
    for start in (1001,1050,1100):
        init=starts[str(start)]
        for rule in RULES:
            path,_=core.make_path(rule,ids,x,lambda ii:y[ii],clusters,init,start,'y8',geom)
            expected=next(r['path_id'] for r in meta if r['dataset']=='Maya' and r['run_set']=='primary_y8' and r['rule']==rule and int(r['replay_id'])==start)
            matches=path==paths[expected]
            records.append({'initial_set':start,'rule':rule,'matches_archived':matches})
            assert matches,(start,rule,'Original scheduling reproduction failed')
        print(json.dumps({'smoke_initial_set':start,'status':'PASS'}),flush=True)
    # Information-access check: the callback rejects every unselected response.
    init=starts['1001']; allowed=set(init); calls=[]
    def reveal(ii):
        assert set(map(int,ii))<=allowed
        calls.append(list(map(int,ii)))
        return y[ii]
    first={}
    for rule in RULES:
        path,_=core.make_path(rule,ids,x,reveal,clusters,init,1001,'y8',geom,maximum=16,fixed_forest_seed=SEEDS[0])
        first[rule]=int(path[-1])
    assert first['Updated MU']==first['Frozen MU']
    assert first['Updated DWU']==first['Frozen DWU']
    report={'status':'PASS','original_path_checks':records,'selected_only_callback_checks':len(calls),'matrix_sha256':hashlib.sha256(Path(matrix).read_bytes()).hexdigest()}
    out.mkdir(parents=True,exist_ok=True)
    (out/'smoke_checks.json').write_text(json.dumps(report,indent=2))

def job(matrix,destination,forest_seed,start):
    destination=Path(destination);dest=destination/f'rf_{forest_seed}_init_{start}.json'
    if dest.exists():
        obj=json.loads(dest.read_text());assert len(obj['paths'])==4
        return {'forest_seed':forest_seed,'initial_set':start,'cached':True}
    ids,x,y,clusters,starts=read_inputs(matrix);init=starts[str(start)];geom=core.geometry(x,clusters)
    t0=time.monotonic();paths={}
    # Identical initial model can serve all arms; later updated selected sets are independent.
    initial_scores,_=core.uncertainty(x[init],y[init],x,start,15,'y8',forest_seed)
    kernel=geom[1]
    for rule in RULES:
        selected=list(map(int,init));mask=np.ones(len(ids),bool);mask[selected]=False
        while len(selected)<len(ids):
            remain=np.flatnonzero(mask)
            if len(remain)==1:choice=int(remain[0])
            else:
                if rule.startswith('Frozen') or len(selected)==15:scores=initial_scores[remain].copy()
                else:scores,_=core.uncertainty(x[selected],y[selected],x[remain],start,len(selected),'y8',forest_seed)
                if rule.endswith('DWU'):scores*=kernel[np.ix_(remain,remain)].sum(axis=1)/max(len(remain)-1,1)
                choice=core.argbest(remain,scores,ids)
            assert mask[choice];selected.append(choice);mask[choice]=False
        assert len(selected)==len(set(selected))==183
        paths[rule]=selected
    assert paths['Updated MU'][:16]==paths['Frozen MU'][:16]
    assert paths['Updated DWU'][:16]==paths['Frozen DWU'][:16]
    obj={'forest_seed':forest_seed,'initial_set':start,'paths':paths,'seconds':time.monotonic()-t0}
    temp=dest.with_suffix('.tmp');temp.write_text(json.dumps(obj));temp.replace(dest)
    return {k:v for k,v in obj.items() if k!='paths'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--matrix',type=Path,required=True);p.add_argument('--output',type=Path,default=ROOT/'Targeted_Analyses/checkpoints');p.add_argument('--smoke',action='store_true');p.add_argument('--workers',type=int,default=8)
    args=p.parse_args()
    if args.smoke:smoke(args.matrix,args.output);return
    assert (args.output/'smoke_checks.json').exists(),'Run the archived-path smoke check first'
    args.output.mkdir(exist_ok=True,parents=True);t0=time.monotonic();done=0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(job,str(args.matrix),str(args.output),s,i) for i in range(1001,1101) for s in SEEDS]
        for f in as_completed(futures):
            result=f.result();done+=1
            if done%3==0:print(json.dumps({'completed_jobs':done,'total_jobs':300,'logical_paths':done*4,'seconds':round(time.monotonic()-t0,1),'latest_seconds':result.get('seconds')}),flush=True)
    print(json.dumps({'status':'COMPLETE','paths':1200,'seconds':time.monotonic()-t0}),flush=True)
if __name__=='__main__':main()
