"""Score fixed-seed paths and report paired contrasts without selecting a seed."""
from pathlib import Path
import sys,json,gzip,hashlib,argparse
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'Targeted_Analyses/results'

def main():
    p=argparse.ArgumentParser();p.add_argument('--checkpoints',type=Path);args=p.parse_args()
    if args.checkpoints is not None:
        files=sorted(args.checkpoints.glob('rf_*_init_*.json'));assert len(files)==300,len(files)
        objects=[json.loads(file.read_text()) for file in files]
        smoke_checks=json.loads((args.checkpoints/'smoke_checks.json').read_text())
    else:
        # Score the public paths directly; no provider matrix or private checkpoint is needed.
        with gzip.open(ROOT/'Analysis/data/acquisition_paths.json.gz','rt') as f:published=json.load(f)
        meta=pd.read_csv(ROOT/'Analysis/data/path_metadata.csv',keep_default_na=False)
        meta=meta[(meta.dataset=='Maya')&meta.run_set.str.match(r'forest_seed_\d+$')]
        objects=[]
        for (run,start),g in meta.groupby(['run_set','replay_id']):
            objects.append({'forest_seed':int(run.split('_')[-1]),'initial_set':int(start),'paths':{r.rule:published[r.path_id] for r in g.itertuples()}})
        assert len(objects)==300
        smoke_checks=json.loads((OUT/'maya_fixed_seed_checks.json').read_text())['smoke_checks']
    refs=json.loads((ROOT/'Analysis/inputs/maya/reference_for_evaluation.json').read_text())
    starts=json.loads((ROOT/'Analysis/inputs/maya/initial_sets.json').read_text())
    sets={target:{str(j):set(i for i,r in enumerate(refs) if str(r[field])==str(j)) for j in sorted({r[field] for r in refs})} for target,field in [('main','main'),('terminal','terminal')]}
    draws=np.load(ROOT/'Submission_Tables/archived_Maya_bootstrap_seed20261004.npz')['initial_sets']
    counts=np.stack([np.bincount(v,minlength=100) for v in draws])/100
    allpaths={};metadata=[];endpoints=[];paired=0;seen_jobs=set()
    for obj in objects:
        seed=int(obj['forest_seed']);start=int(obj['initial_set'])
        assert seed in (202610041,202610042,202610043) and start in range(1001,1101)
        assert (seed,start) not in seen_jobs
        seen_jobs.add((seed,start))
        pp=obj['paths']
        assert set(pp)=={'Updated MU','Frozen MU','Updated DWU','Frozen DWU'}
        for arm in ['MU','DWU']:
            assert pp['Updated '+arm][:16]==pp['Frozen '+arm][:16];paired+=1
        for rule,seq in pp.items():
            assert len(seq)==len(set(seq))==183 and seq[:15]==starts[str(start)]
            pid=f'Maya|forest_seed_{seed}|{start}|{rule}';assert pid not in allpaths;allpaths[pid]=seq
            # Hash convention is self-described and independent of internal path IDs.
            sha=hashlib.sha256(json.dumps(seq).encode()).hexdigest()
            metadata.append(dict(path_id=pid,dataset='Maya',rule=rule,replay_id=start,run_set=f'forest_seed_{seed}',response_panel='y8',screening_partition='10',forest_seed=seed,amg_order_id='',path_sha256=sha))
            rank={x:i+1 for i,x in enumerate(seq)}
            for target,groups in sets.items():
                for k in [2,3,5]:
                    b=max(15,max(sorted(rank[x] for x in members)[k-1] for members in groups.values()))
                    hit=np.stack([np.cumsum([int(x in members) for x in seq]) for members in groups.values()])
                    independent=max(15,int(np.flatnonzero((hit>=k).all(axis=0))[0])+1)
                    assert b==independent
                    endpoints.append(dict(case='Maya',forest_seed=seed,start=start,rule=rule,target=target,k=k,budget=b))
    assert seen_jobs=={(s,i) for s in (202610041,202610042,202610043) for i in range(1001,1101)}
    data=pd.DataFrame(endpoints);contrasts=[];budgets=[]
    def append_contrast(g,seed,target,k,arm):
        p=g.pivot(index='start',columns='rule',values='budget').sort_index()
        diff=(p['Updated '+arm]-p['Frozen '+arm]).to_numpy();sim=counts@diff;lo,hi=np.quantile(sim,[.025,.975])
        contrasts.append(dict(case='Maya',forest_seed=seed,target=target,k=int(k),contrast=f'Updated {arm} minus Frozen {arm}',start_count=100,mean_difference=float(diff.mean()),interval_low=float(lo),interval_high=float(hi),earlier_fraction=float((diff<0).mean()),tied_fraction=float((diff==0).mean()),later_fraction=float((diff>0).mean())))
    for (seed,target,k),g in data.groupby(['forest_seed','target','k']):
        for arm in ['MU','DWU']:append_contrast(g,seed,target,k,arm)
    averaged=data.groupby(['start','rule','target','k'],as_index=False).budget.mean()
    for (target,k),g in averaged.groupby(['target','k']):
        for arm in ['MU','DWU']:append_contrast(g,'three-seed mean',target,k,arm)
    for source,seed in [(data[data.forest_seed==s],s) for s in [202610041,202610042,202610043]]+[(averaged,'three-seed mean')]:
        for (target,k,rule),g in source.groupby(['target','k','rule']):
            vals=g.sort_values('start').budget.to_numpy();lo,hi=np.quantile(counts@vals,[.025,.975])
            budgets.append(dict(case='Maya',forest_seed=seed,target=target,k=int(k),rule=rule,mean_budget=float(vals.mean()),interval_low=float(lo),interval_high=float(hi)))
    OUT.mkdir(exist_ok=True,parents=True)
    data.to_csv(OUT/'maya_fixed_seed_endpoints.csv',index=False)
    pd.DataFrame(contrasts).to_csv(OUT/'maya_fixed_seed_contrasts.csv',index=False,float_format='%.12g')
    pd.DataFrame(budgets).to_csv(OUT/'maya_fixed_seed_budget_summary.csv',index=False,float_format='%.12g')
    # Keep a single path archive; new checkpoints are local execution artifacts.
    archive=ROOT/'Analysis/data/acquisition_paths.json.gz'
    with gzip.open(archive,'rt') as f:old=json.load(f)
    assert all(old[pid]==allpaths[pid] for pid in set(old)&set(allpaths));old.update(allpaths)
    with archive.open('wb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as f:f.write(json.dumps(old,separators=(',',':')).encode())
    m=pd.read_csv(ROOT/'Analysis/data/path_metadata.csv',keep_default_na=False)
    pd.concat([m[~m.path_id.isin(allpaths)],pd.DataFrame(metadata)],ignore_index=True).to_csv(ROOT/'Analysis/data/path_metadata.csv',index=False)
    report={'status':'PASS','new_paths':len(allpaths),'new_endpoints':len(data),'independent_endpoint_checks':len(data),'paired_first_selection_checks':paired,'total_archive_paths':len(old),'all_fixed_seeds_retained':[202610041,202610042,202610043],'path_hash_convention':'SHA256 JSON integer-index path using default separators','smoke_checks':smoke_checks}
    (OUT/'maya_fixed_seed_checks.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report))
if __name__=='__main__':main()
