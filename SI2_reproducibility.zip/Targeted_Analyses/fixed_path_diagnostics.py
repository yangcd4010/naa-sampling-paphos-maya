"""Fixed-budget evidence and constraint dependence from the archived primary paths."""
from pathlib import Path
import gzip,json,hashlib
import numpy as np
import pandas as pd
from scipy.stats import hypergeom
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'Targeted_Analyses/results'
FABRIC={'APDC','Cross-stratified'}

def load():
    with gzip.open(ROOT/'Analysis/data/acquisition_paths.json.gz','rt') as f:paths=json.load(f)
    meta=pd.read_csv(ROOT/'Analysis/data/path_metadata.csv',keep_default_na=False)
    meta=meta[((meta.dataset=='Maya')&(meta.run_set=='primary_y8'))|((meta.dataset=='Paphos')&(((meta.run_set=='archived')&(~meta.rule.isin(FABRIC)))|meta.run_set.str.match(r'random_\d\d$')))]
    refs=pd.read_csv(ROOT/'Revision_Analysis_v5/inputs/reference_membership.csv',dtype={'object_id':str,'set_id':str})
    refs=refs[refs.eligible]
    units={(c,t):{j:set(g.object_id) for j,g in h.groupby('set_id')} for (c,t),h in refs.groupby(['dataset','target_id'])}
    initial=pd.read_csv(ROOT/'Revision_Analysis_v5/inputs/initial_sets.csv',dtype={'object_id':str})
    starts={(c,int(s)):set(g.object_id) for (c,s),g in initial.groupby(['dataset','replay_id'])}
    draws=np.load(ROOT/'Revision_Analysis_v5/inputs/bootstrap_indices.npz')
    maya=np.load(ROOT/'Submission_Tables/archived_Maya_bootstrap_seed20261004.npz')['initial_sets']
    def counts(a,n):return np.stack([np.bincount(row,minlength=n) for row in a])/a.shape[1]
    return paths,meta,units,starts,{'Paphos':counts(draws['initial_sets'],100),'Maya':counts(maya,100),'orders':counts(draws['orders'],20)}

def interval(a,case,boots):
    if a.ndim==1:sim=boots[case]@a
    else:sim=np.einsum('bi,ij,bj->b',boots[case],a,boots['orders'],optimize=True)
    return np.quantile(sim,[.025,.975]).tolist()

def matrix(g,column):
    h=g.pivot(index='start',columns='order',values=column).sort_index().sort_index(axis=1)
    assert len(h)==100 and not h.isna().any().any()
    return h.to_numpy().ravel() if h.shape[1]==1 else h.to_numpy()

def snapshots(paths,meta,units,starts,boots):
    cdf=pd.read_csv(ROOT/'Revision_Analysis_v5/results/conditional_random_cdf_by_start.csv.gz')
    cdf=cdf[(cdf['case']=='Paphos')&(cdf.excluded=='none')&(cdf.k==2)&cdf.budget.isin([35,55,75])]
    raw=[]
    for m in meta.itertuples():
        if m.dataset!='Paphos':continue
        path=paths[m.path_id];assert len(path)==len(set(path))==97
        order=int(m.run_set[-2:]) if m.rule in FABRIC else 0
        for (case,target),sets in units.items():
            if case!=m.dataset:continue
            for b in [35,55,75]:
                seen=set(path[:b]);n=sum(len(seen&s)>=2 for s in sets.values())
                raw.append(dict(case=case,target=target,rule=('Archived random' if m.rule=='Random' else m.rule),start=int(m.replay_id),order=order,total_budget=b,completion=float(n==len(sets)),completed_sets=n,required_set_count=len(sets)))
    for (case,target),sets in units.items():
        if case!='Paphos':continue
        for s in range(1001,1101):
            selected=starts[case,s]
            for b in [35,55,75]:
                complete=float(cdf.loc[(cdf.target==target)&(cdf.seed==s)&(cdf.budget==b),'completion_probability'].iloc[0])
                n=0.
                for members in sets.values():
                    deficit=max(0,2-len(selected&members));remaining=len(members-selected)
                    n+=1. if deficit==0 else float(hypergeom.sf(deficit-1,82,remaining,b-15))
                raw.append(dict(case=case,target=target,rule='Random',start=s,order=0,total_budget=b,completion=complete,completed_sets=n,required_set_count=len(sets)))
    frame=pd.DataFrame(raw);result=[]
    source_hash=hashlib.sha256((ROOT/'Analysis/data/acquisition_paths.json.gz').read_bytes()).hexdigest()
    for (target,b,rule),g in frame.groupby(['target','total_budget','rule']):
        a=matrix(g,'completion');n=matrix(g,'completed_sets');lo,hi=interval(a,'Paphos',boots)
        nlo,nhi=interval(n,'Paphos',boots)
        result.append(dict(case='Paphos',target=target,k=2,total_budget=int(b),rule=rule,reference_convention=('exact conditional completion probability' if rule=='Random' else 'archived continuation' if rule=='Archived random' else 'primary archived selection path'),start_count=100,order_count=(20 if rule in FABRIC else 1),completion_fraction=float(a.mean()),mean_completed_sets=float(n.mean()),required_set_count=int(g.required_set_count.iloc[0]),interval_low=lo,interval_high=hi,mean_completed_sets_interval_low=nlo,mean_completed_sets_interval_high=nhi,source_hash=source_hash))
    frame.to_csv(OUT/'fixed_budget_by_start.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    pd.DataFrame(result).to_csv(OUT/'fixed_budget_evidence_snapshot.csv',index=False,float_format='%.12g')
    # Established S43 reported values are checked, not used as new calculations.
    q=pd.DataFrame(result);checks={}
    for r,v in [('Cross-stratified',(1,.19)),('APDC',(1,.19)),('Updated DWU',(.51,.84))]:
        got=[float(q.loc[(q.rule==r)&(q.total_budget==55)&(q.target==t),'completion_fraction'].iloc[0]) for t in ['Sicily_cross_cluster_correction','CYPB_Paphian_Kourion_separation']]
        assert np.allclose(got,v,atol=.005),(r,got,v)
        checks[r]=got
    return checks

def dependence(paths,meta,units,starts,boots):
    records=[];member_records=[]
    for m in meta.itertuples():
        seq=list(map(str,paths[m.path_id]));rank={x:i+1 for i,x in enumerate(seq)}
        assert set(seq[:15])==starts[m.dataset,int(m.replay_id)]
        rule='Archived random' if m.rule=='Random' else m.rule
        order=int(m.run_set[-2:]) if m.rule in FABRIC else 0
        for (case,target),sets in units.items():
            if case!=m.dataset:continue
            times={j:max(15,sorted(rank[x] for x in s)[1]) for j,s in sets.items()}
            b=max(times.values());initial=b==15
            tied=[j for j,t in times.items() if t==b] if not initial else []
            for j,members in sets.items():
                acquired=sorted(rank[x] for x in members)
                relaxed=max([15]+[t for other,t in times.items() if other!=j]);w=b-relaxed
                assert w>=0
                records.append(dict(case=case,target=target,rule=rule,start=int(m.replay_id),order=order,set_id=j,set_size=len(members),k=2,exhausts_set=len(members)==2,first_position=acquired[0],second_position=acquired[1],attainment_budget=times[j],target_budget=b,initially_complete=initial,last_completed=j in tied,tied_last=len(tied)>1,relaxed_budget=relaxed,additional_wait=w))
                if case=='Paphos' and len(members)==2:
                    for x in sorted(members):
                        replacement=max(15,max(rank[y] for y in members if y!=x))
                        bminus=max([15,replacement]+[t for other,t in times.items() if other!=j])
                        member_records.append(dict(case=case,target=target,rule=rule,start=int(m.replay_id),order=order,set_id=j,object_id=x,object_position=rank[x],target_budget=b,relaxed_budget=bminus,additional_wait=b-bminus))
    frame=pd.DataFrame(records);summary=[]
    for (case,target,rule,j),g in frame.groupby(['case','target','rule','set_id']):
        w=matrix(g,'additional_wait');lo,hi=interval(w,case,boots)
        late=g[~g.initially_complete]
        summary.append(dict(case=case,target=target,rule=rule,set_id=j,set_size=int(g.set_size.iloc[0]),exhausts_set=bool(g.exhausts_set.iloc[0]),configuration_count=len(g),initial_complete_fraction=float(g.initially_complete.mean()),mean_first_position=float(g.first_position.mean()),mean_second_position=float(g.second_position.mean()),mean_attainment_budget=float(g.attainment_budget.mean()),unfinished_configuration_count=len(late),last_completed_fraction=(float(late.last_completed.mean()) if len(late) else 0.),tied_last_fraction=(float(late.tied_last.mean()) if len(late) else 0.),mean_additional_wait=float(w.mean()),interval_low=lo,interval_high=hi))
    frame.to_csv(OUT/'fixed_path_set_dependence.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    pd.DataFrame(summary).to_csv(OUT/'fixed_path_set_dependence_summary.csv',index=False,float_format='%.12g')
    members=pd.DataFrame(member_records)
    members.to_csv(OUT/'fixed_path_member_dependence.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    members.groupby(['case','target','rule','set_id','object_id']).agg(mean_object_position=('object_position','mean'),mean_additional_wait=('additional_wait','mean'),max_additional_wait=('additional_wait','max')).reset_index().to_csv(OUT/'fixed_path_member_dependence_summary.csv',index=False,float_format='%.12g')
    return {'set_records':len(frame),'member_records':len(members),'paphos_set_instances':sum(len(v) for (c,t),v in units.items() if c=='Paphos'),'maya_set_instances':sum(len(v) for (c,t),v in units.items() if c=='Maya')}

def main():
    OUT.mkdir(exist_ok=True,parents=True)
    paths,meta,units,starts,boots=load()
    report={'fixed_budget':snapshots(paths,meta,units,starts,boots),'dependence':dependence(paths,meta,units,starts,boots),'status':'PASS','new_model_fits':0}
    (OUT/'fixed_path_checks.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report))
if __name__=='__main__':main()
