"""Export submission tables from saved unrounded summaries; no model fitting."""
from pathlib import Path
import pandas as pd,json
HERE=Path(__file__).resolve().parent; ROOT=HERE.parent; R=ROOT/'Revision_Analysis_v5/results'
base=json.loads((HERE/'table_records.json').read_text(encoding='utf8'))
p=pd.read_csv(R/'paired_rule_comparisons.csv'); d=pd.read_csv(R/'rule_minus_exact_random.csv')
targets={'Paphian':'Paphian_AMG48_vs_AMG21B','Five Kourion':'Kourion_five_patterns','Koan–Thassian':'IMPA_Koan_Thassian_subdivision','CYP-B':'CYPB_Paphian_Kourion_separation','Sicilian':'Sicily_cross_cluster_correction','Six Aegean':'Aegean_six_unlocated_patterns'}
def fmt(x):return f'{x:.2f}'.replace('-','−')
def match(c,t,k,a,b):
 x=p[(p.case==c)&(p.target==t)&(p.k==k)&(p.excluded=='none')&(p.rule_A==a)&(p.rule_B==b)]; assert len(x)==1; return x.iloc[0]
for name,rows in base.items():
 for r in rows[1:]:
  if name in ['S14','S15']:
   x=match('Paphos',targets[r[0]],2 if name=='S14' else 1,'Updated '+r[1],'Frozen '+r[1]); r[4]=fmt(x.mean_delta); r[5]=f'{fmt(x.CI_low)} to {fmt(x.CI_high)}'
  elif name=='S17' and r[0].startswith('PQMM'):
   x=match('Paphos',targets[r[1]],2,'PQMM','Proportional');r[4]=fmt(x.mean_delta);r[5]=f'{fmt(x.CI_low)} to {fmt(x.CI_high)}'
  elif name in ['S22','S28'] and r[0]=='y8':
   t='main' if r[2]=='4 groups' else 'terminal'; k=2 if name=='S22' else int(r[3]); col=3 if name=='S22' else 4
   if r[1].startswith('Max-min'):
    x=d[(d.case=='Maya')&(d.target==t)&(d.k==k)&(d.rule=='Max-min')&(d.excluded=='none')].iloc[0];r[1]='Max-min − exact random'
   else:
    a,b=('PQMM','Proportional') if r[1].startswith('PQMM') else (('Updated MU','Frozen MU') if r[1].startswith('MU') or r[1].startswith('Updated MU') else ('Updated DWU','Frozen DWU'));x=match('Maya',t,k,a,b)
   r[col]=fmt(x.mean_delta);r[col+1]=f'{fmt(x.CI_low)} to {fmt(x.CI_high)}'
 for r in rows:
  for i,s in enumerate(r):r[i]=s.replace('PQMM − prop.','PQMM − proportional-medoid').replace('PQMM − Proportional','PQMM − proportional-medoid').replace('PQMM − proportional','PQMM − proportional-medoid').replace('proportional-medoid-medoid','proportional-medoid')
 pd.DataFrame(rows[1:],columns=rows[0]).to_csv(HERE/(name+'.csv'),index=False,encoding='utf-8-sig')
for name in ['primary_budget_summary.csv','paired_rule_comparisons.csv','rule_minus_exact_random.csv']:
 pd.read_csv(R/name).to_csv(HERE/name,index=False,encoding='utf-8-sig',float_format='%.12g')
print('Exported S14, S15, S17, S22, S28 and complete primary summaries')
